/* Popup: scheduled entries, status line, settings, and requirements. */
(function () {
  "use strict";

  var paneEntries = document.getElementById("paneEntries");
  var paneSettings = document.getElementById("paneSettings");
  var paneReq = document.getElementById("paneReq");
  var tabEntries = document.getElementById("tabEntries");
  var tabSettings = document.getElementById("tabSettings");
  var tabReq = document.getElementById("tabReq");
  var statusLine = document.getElementById("statusLine");
  var statusCard = document.getElementById("statusCard");
  var setDelay = document.getElementById("setDelay");
  var setFilterSummary = document.getElementById("setFilterSummary");
  var setFilterList = document.getElementById("setFilterList");
  var filterReload = document.getElementById("filterReload");
  var filterNote = document.getElementById("filterNote");
  var settingsOrgId = ""; // org the Settings window fields edit
  var autofillBtn = document.getElementById("autofillBtn");
  var autofillNote = document.getElementById("autofillNote");
  var detectBanner = document.getElementById("detectBanner");
  var optAutoRegButtons = document.getElementById("optAutoRegButtons");
  var optOpensIndicator = document.getElementById("optOpensIndicator");
  var topOrg = document.getElementById("topOrg");
  var premFree = document.getElementById("premFree");
  var premActive = document.getElementById("premActive");
  var premUpgrade = document.getElementById("premUpgrade");
  var premKey = document.getElementById("premKey");
  var premActivate = document.getElementById("premActivate");
  var premToggleDeactivate = document.getElementById("premToggleDeactivate");
  var premDeactivateWrap = document.getElementById("premDeactivateWrap");
  var premDeactivate = document.getElementById("premDeactivate");
  var premNote = document.getElementById("premNote");
  var paneInit = document.getElementById("paneInit");
  var initNeedSite = document.getElementById("initNeedSite");
  var initWorking = document.getElementById("initWorking");
  var initWorkingNote = document.getElementById("initWorkingNote");
  var initDone = document.getElementById("initDone");
  var initDoneTitle = document.getElementById("initDoneTitle");
  var initDoneNote = document.getElementById("initDoneNote");
  var initOpenSite = document.getElementById("initOpenSite");
  var initContinue = document.getElementById("initContinue");

  // --- First-run auto-initialization -----------------------------------------
  // On the very first use (no organization learned yet) the init pane takes
  // over the whole popup. If no CourtReserve tab is open it asks the user to
  // open one; once a calendar/portal tab exists the background initializer
  // chain (initStart) runs automatically — finding the club, loading its
  // categories, and detecting the registration window — then the normal
  // Scheduled tab appears. Progress lives in chrome.storage.local.initState,
  // so closing the popup mid-run loses nothing: reopening shows progress.
  var INIT_STAGES = {
    "find-org": "Looking for CourtReserve… a tab opens if none is found — log in if asked.",
    categories: "Loading your club's calendar categories…",
    autofill: "Detecting the registration window… (takes a few seconds).",
  };
  var initAutoStarted = false; // fire initStart at most once per popup open
  var openAutoFired = false;   // fire openOrgCalendar at most once per popup open

  function showInitPane(mode) {
    document.querySelector(".tabs").style.display = "none";
    statusCard.style.display = "none";
    [paneEntries, paneSettings, paneReq].forEach(function (p) { p.style.display = "none"; });
    paneInit.style.display = "";
    initNeedSite.style.display = mode === "need-site" ? "" : "none";
    initWorking.style.display = mode === "working" ? "" : "none";
    initDone.style.display = mode === "done" ? "" : "none";
  }

  function hideInitPane() {
    paneInit.style.display = "none";
    document.querySelector(".tabs").style.display = "";
    activate(tabEntries);
  }

  function initPaneVisible() {
    return paneInit.style.display !== "none";
  }

  // Live progress from the background chain (storage events drive this).
  function renderInitProgress(st) {
    if (!st || !initPaneVisible()) return;
    if (st.running) {
      showInitPane("working");
      initWorkingNote.textContent = INIT_STAGES[st.stage] || "Working…";
      return;
    }
    if (st.stage === "done") {
      showInitPane("done");
      initDoneTitle.textContent = st.ok ? "Setup complete ✓" : "Setup needs attention";
      initDoneNote.innerHTML =
        '<span style="color:' + (st.ok ? "#15803d" : "#b91c1c") + ';">' + esc(st.message || "") + "</span>";
      if (st.ok && st.orgId) chrome.storage.local.set({ uiTopOrg: st.orgId });
    }
  }

  // --- Tab reuse ---------------------------------------------------------------
  // Every "open CourtReserve" affordance reuses an existing CourtReserve tab
  // (active first, then most recently active) instead of stacking duplicates.
  function sortTabsByRecency(tabs) {
    tabs.sort(function (a, b) {
      if (!!a.active !== !!b.active) return a.active ? -1 : 1;
      return (b.lastAccessed || 0) - (a.lastAccessed || 0);
    });
    return tabs;
  }
  function focusTab(t) {
    chrome.tabs.update(t.id, { active: true });
    chrome.windows.update(t.windowId, { focused: true });
  }
  /** Bring a matching existing tab forward; otherwise create `url`. */
  function openOrFocusCourtReserve(url, matchUrl) {
    chrome.tabs.query({ url: matchUrl || "https://app.courtreserve.com/*" }).then(function (tabs) {
      sortTabsByRecency(tabs);
      if (tabs.length) focusTab(tabs[0]);
      else chrome.tabs.create({ url: url, active: true });
    });
  }

  initOpenSite.addEventListener("click", function () {
    // The popup closes as the tab takes focus — the on-screen steps tell
    // the user to reopen the extension once the calendar is up.
    openOrFocusCourtReserve("https://app.courtreserve.com/");
  });

  initContinue.addEventListener("click", function () {
    hideInitPane();
    loadSettingsPane();
    render();
  });

  // --- Premium (Dodo Payments license) ---------------------------------------
  premUpgrade.href = CRLib.UPGRADE_URL;
  var premiumActive = false;

  function renderPremium() {
    chrome.runtime.sendMessage({ type: "licenseStatus" }, function (r) {
      if (!r || !r.ok) return;
      premiumActive = !!r.premium;
      premFree.style.display = premiumActive ? "none" : "";
      premActive.style.display = premiumActive ? "" : "none";
      if (premiumActive) {
        premDeactivateWrap.style.display = "none";
        premToggleDeactivate.textContent = "Deactivate…";
      }
      // The ⏰/🔒 calendar buttons can be hidden by anyone in Calendar options
      // (free users hide the 🔒 upgrade button; premium users hide ⏰).
    });
  }

  premActivate.addEventListener("click", function () {
    premActivate.disabled = true;
    premNote.textContent = "Activating…";
    chrome.runtime.sendMessage(
      { type: "licenseActivate", key: premKey.value.trim(), deviceName: "Chrome popup" },
      function (r) {
        premActivate.disabled = false;
        if (r && r.ok) {
          premNote.textContent = "";
          premKey.value = "";
          renderPremium();
        } else {
          premNote.textContent = "⚠ " + ((r && r.message) || "Activation failed.");
        }
      }
    );
  });

  premDeactivate.addEventListener("click", function () {
    premNote.textContent = "Deactivating…";
    chrome.runtime.sendMessage({ type: "licenseDeactivate" }, function () {
      premNote.textContent = "";
      renderPremium();
    });
  });

  premToggleDeactivate.addEventListener("click", function () {
    var showing = premDeactivateWrap.style.display !== "none";
    premDeactivateWrap.style.display = showing ? "none" : "";
    premToggleDeactivate.textContent = showing ? "Deactivate…" : "Hide";
  });

  var optsNote = document.getElementById("optsNote");
  var fullSettings = null; // complete settings object (defaults + per-org)
  var knownOrgs = [];      // [{ id, name, primary }] from CourtReserve visits

  function esc(s) {
    return String(s || "").replace(/[&<>"']/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
    });
  }

  // --- Tabs ------------------------------------------------------------------
  function activate(tab) {
    [tabEntries, tabSettings, tabReq].forEach(function (t) { t.classList.remove("active"); });
    [paneEntries, paneSettings, paneReq].forEach(function (p) { p.style.display = "none"; });
    tab.classList.add("active");
    // The LOG card belongs to the Scheduled panel only.
    statusCard.style.display = tab === tabEntries ? "" : "none";
    (tab === tabEntries ? paneEntries : tab === tabSettings ? paneSettings : paneReq).style.display = "";
  }
  tabEntries.addEventListener("click", function () { activate(tabEntries); });
  tabSettings.addEventListener("click", function () { activate(tabSettings); });
  tabReq.addEventListener("click", function () { activate(tabReq); });

  document.getElementById("verLine").textContent =
    "Court Helper Version: v" + chrome.runtime.getManifest().version;

  document.getElementById("openCal").addEventListener("click", function (ev) {
    ev.preventDefault();
    // Open the month calendar for the org selected at the top (fall back to
    // the Settings org) — not the generic portal page. With nothing known,
    // open the portal root and let CourtReserve route to the user's org.
    // Either way, reuse an existing tab rather than stacking another one.
    var orgId = (topOrg && topOrg.value) || settingsOrgId || "";
    if (orgId) {
      openOrFocusCourtReserve(
        "https://app.courtreserve.com/Online/Calendar/Events/" + orgId + "/Month",
        "https://app.courtreserve.com/Online/Calendar/Events/" + orgId + "/*"
      );
    } else {
      openOrFocusCourtReserve("https://app.courtreserve.com/");
    }
  });

  // --- Status line -------------------------------------------------------------
  function renderStatus(entries) {
    var now = Date.now();
    var upcoming = entries
      .filter(function (e) { return e.status === "scheduled" || e.status === "retrying"; })
      .sort(function (a, b) { return a.fireAt - b.fireAt; })[0];
    var lastFired = entries
      .filter(function (e) { return e.lastRun; })
      .sort(function (a, b) { return b.lastRun.at - a.lastRun.at; })[0];

    var html = "";
    if (upcoming) {
      html += '<span class="next">Next fire: ' + esc(CRLib.fmtDateTime(new Date(upcoming.fireAt))) +
        "</span> — " + esc(upcoming.event) + ", " + esc(CRLib.abbrevDate(upcoming.date)) +
        ' <span style="color:#78716c;">· ' + esc(orgDisplayName(upcoming.orgId)) + "</span>";
    } else {
      html += "Nothing scheduled.";
    }
    if (lastFired) {
      html += '<hr class="logsep">Last fired: <span class="' + (lastFired.lastRun.ok ? "ok" : "fail") + '">' +
        (lastFired.lastRun.ok ? "✓ " : "✗ ") + esc(CRLib.abbrevDate(lastFired.lastRun.message)) + "</span> — " +
        esc(CRLib.fmtDateTime(new Date(lastFired.lastRun.at)));
      if (now - lastFired.lastRun.at > 7 * 86400000) html += " <span class=\"fail\">(over a week ago)</span>";
    }
    statusLine.innerHTML = html;
  }

  // --- Entries list ------------------------------------------------------------
  // Each entry is headed by its organization name. The Organization dropdown
  // at the top filters the list; "All organizations" shows everything.
  function render() {
    Promise.all([CRLib.store.list(), CRLib.orgs.list()])
      .then(function (r) {
      var entries = r[0];
      knownOrgs = r[1];
      var filterOrg = topOrg.value || "";
      if (filterOrg) {
        entries = entries.filter(function (e) { return e.orgId === filterOrg; });
      }
      entries.sort(function (a, b) { return a.fireAt - b.fireAt; });
      renderStatus(entries);
      if (!entries.length) {
        paneEntries.innerHTML = filterOrg
          ? '<div class="empty">No auto-registrations scheduled for <b>' + esc(orgDisplayName(filterOrg)) + '</b>.<br>' +
            'Pick "All organizations" above to see everything.</div>'
          : '<div class="empty">No auto-registrations scheduled.<br>' +
            'Open the CourtReserve calendar and click <b>⏰ Auto-Register</b> ' +
            'on any event whose window has not opened yet.</div>';
        return;
      }
      paneEntries.innerHTML = entries.map(function (e) {
        var status = e.status || "scheduled";
        var html =
          '<div class="entry">' +
          '<div class="org">' + esc(orgDisplayName(e.orgId)) + "</div>" +
          '<div class="ev">' + esc(e.event) + '<span class="badge ' + esc(status) + '">' + esc(status) + "</span></div>" +
          '<div class="when">' + esc(CRLib.abbrevDate(e.date)) + " · " + esc(e.time) + "</div>" +
          '<div class="fires">Fires ' + esc(CRLib.fmtDateTime(new Date(e.fireAt))) + "</div>";
        if (e.lastRun) {
          html +=
            '<div class="lastrun ' + (e.lastRun.ok ? "ok" : "fail") + '">' +
            (e.lastRun.ok ? "✓ " : "✗ ") + esc(CRLib.abbrevDate(e.lastRun.message)) +
            " — " + esc(CRLib.fmtDateTime(new Date(e.lastRun.at))) + "</div>";
        }
        html +=
          '<div class="row">' +
          '<button data-act="run" data-id="' + esc(e.id) + '">Run now</button>' +
          '<button data-act="cancel" class="danger" data-id="' + esc(e.id) + '">Remove</button>' +
          "</div></div>";
        return html;
      }).join("");
    });
  }

  paneEntries.addEventListener("click", function (ev) {
    var btn = ev.target.closest("button[data-act]");
    if (!btn) return;
    var id = btn.getAttribute("data-id");
    if (btn.getAttribute("data-act") === "run") {
      btn.textContent = "Running…";
      chrome.runtime.sendMessage({ type: "runNow", id: id }, function (r) {
        if (r && r.premiumRequired) {
          alert("Run now is a Premium feature — activate your license in the Settings tab.");
        }
        render();
      });
    } else {
      chrome.runtime.sendMessage({ type: "cancel", id: id }, render);
    }
  });

  // --- Settings ---------------------------------------------------------------
  // The Organization is the primary key: every field below can be determined
  // per organization. Switching orgs happens only in the top dropdown (the
  // popup opens on the one the browser is viewing); the stored default rule
  // is the invisible fallback whose values fill the fields of an org that has
  // nothing determined yet — by Auto Fill or by saving here.
  function fmtOpenTime(openTime) {
    var parts = openTime.split(":").map(Number);
    var h = parts[0], m = parts[1];
    return (h % 12 || 12) + ":" + String(m).padStart(2, "0") + " " + (h >= 12 ? "PM" : "AM");
  }

  function orgDisplayName(id) {
    for (var i = 0; i < knownOrgs.length; i++) {
      if (knownOrgs[i].id === id && knownOrgs[i].name) return knownOrgs[i].name;
    }
    return "Org " + id;
  }

  /** All org ids seen anywhere: learned list, per-org settings, entries. */
  function collectOrgIds(entries, extraId) {
    var ids = {};
    knownOrgs.forEach(function (o) { ids[o.id] = true; });
    Object.keys((fullSettings && fullSettings.perOrg) || {}).forEach(function (id) { ids[id] = true; });
    (entries || []).forEach(function (e) { if (e.orgId) ids[e.orgId] = true; });
    if (extraId) ids[extraId] = true;
    return Object.keys(ids);
  }

  /** Survey open CourtReserve tabs (any window — first run often has the
      calendar in a non-active tab/window): how many, the org of any open
      CALENDAR page, and the org of any Online page at all.
      Several CourtReserve tabs are common (the post-purchase link opens a
      second calendar), so prefer the tab the user is actually looking at:
      active tabs first, then most recently active. */
  function detectBrowserTabs() {
    return chrome.tabs.query({ url: "https://app.courtreserve.com/Online/*" }).then(function (tabs) {
      tabs.sort(function (a, b) {
        if (!!a.active !== !!b.active) return a.active ? -1 : 1;
        return (b.lastAccessed || 0) - (a.lastAccessed || 0);
      });
      var anyOrg = "", calendarOrg = "";
      for (var i = 0; i < tabs.length; i++) {
        var url = tabs[i].url || "";
        if (!calendarOrg) {
          var mc = /\/Online\/Calendar\/Events\/(\d+)/.exec(url);
          if (mc) calendarOrg = mc[1];
        }
        if (!anyOrg) {
          var m =
            /\/Online\/(?:Calendar\/Events|Portal\/Index)\/(\d+)/.exec(url) ||
            /\/Online\/Events\/Details\/(\d+)\//.exec(url);
          if (m) anyOrg = m[1];
        }
      }
      return { count: tabs.length, anyOrg: anyOrg, calendarOrg: calendarOrg };
    }).catch(function () { return { count: 0, anyOrg: "", calendarOrg: "" }; });
  }

  /** Sort org ids: primary first, then alphabetical by display name. */
  function sortOrgIds(ids) {
    return ids.sort(function (a, b) {
      var pa = knownOrgs.find(function (o) { return o.id === a; });
      var pb = knownOrgs.find(function (o) { return o.id === b; });
      if (pa && pa.primary) return -1;
      if (pb && pb.primary) return 1;
      return orgDisplayName(a).localeCompare(orgDisplayName(b));
    });
  }

  /** Top-of-popup org selector: "All organizations" plus every known org. */
  function renderTopOrgSelect(entries, preselectOrg) {
    var prev = preselectOrg !== undefined ? preselectOrg : topOrg.value;
    var ids = sortOrgIds(collectOrgIds(entries, prev || undefined));
    topOrg.innerHTML = '<option value="">All organizations</option>' + ids.map(function (id) {
      return '<option value="' + esc(id) + '">' + esc(orgDisplayName(id)) + " (" + esc(id) + ")</option>";
    }).join("");
    topOrg.value = prev && ids.indexOf(prev) !== -1 ? prev : "";
  }

  /** Settings edits one org at a time — shown as a bold label, not a select.
      Switching happens in the top dropdown; this just follows it. */
  function setSettingsOrg(id, entries) {
    if (!id) {
      var ids = sortOrgIds(collectOrgIds(entries));
      id = ids[0] || ""; // nothing learned yet — fields edit the default rule
    }
    settingsOrgId = id;
  }

  /** Fill the fields with the effective values for the selected org. */
  function fillFields() {
    if (!fullSettings) return;
    var orgId = settingsOrgId;
    var s = CRLib.settings.mergeOrg(fullSettings, orgId);
    setDelay.value = String(s.fireDelayMinutes !== undefined ? s.fireDelayMinutes : 5);
    fillFilterOptions(s, orgId);
    optAutoRegButtons.checked = fullSettings.showAutoRegButtons !== false;
    optOpensIndicator.checked = fullSettings.showOpensIndicator === true;
  }

  // --- Category filter dropdown ------------------------------------------------
  // The calendar's FILTER categories come from the page's own FILTER panel
  // (the complete list — always in the DOM, unlike the scheduler's dataSource
  // which only holds the currently loaded month's events). Each category is
  // stored with its color: the site colors every event by category, so the
  // content script matches cells by background color — exact, no fuzzy text.
  var filterCategories = {}; // orgId -> [{name, color}] — memory cache over the persisted orgCategories store

  /** Persist non-empty category lists per org so switching orgs is instant. */
  function persistCategories() {
    var out = {};
    Object.keys(filterCategories).forEach(function (id) {
      if (filterCategories[id] && filterCategories[id].length) out[id] = filterCategories[id];
    });
    chrome.storage.local.set({ orgCategories: out });
  }

  // Runs in the calendar page's MAIN world. Must be fully self-contained.
  function readCalendarCategories() {
    try {
      var rows = document.querySelectorAll(".custom-checkbox.rowCheckbox");
      if (!rows.length && typeof openLeftNav === "function") {
        openLeftNav(); // some org pages render the panel lazily
        rows = document.querySelectorAll(".custom-checkbox.rowCheckbox");
      }
      var out = [];
      for (var i = 0; i < rows.length; i++) {
        var label = rows[i].querySelector("label.k-checkbox-label");
        var swatch = rows[i].querySelector(".categ-line-color");
        if (!label) continue;
        out.push({ name: label.innerText.trim(), color: swatch ? swatch.style.backgroundColor : "" });
      }
      out.sort(function (a, b) { return a.name.localeCompare(b.name); });
      return out;
    } catch (e) {
      return [];
    }
  }

  /** Resolve when the tab finishes loading (or the timeout hits). */
  function waitForTabComplete(tabId, timeoutMs) {
    return new Promise(function (resolve) {
      var done = false;
      function finish(ok) {
        if (done) return;
        done = true;
        clearTimeout(timer);
        chrome.tabs.onUpdated.removeListener(listener);
        resolve(ok);
      }
      var timer = setTimeout(function () { finish(false); }, timeoutMs || 15000);
      function listener(id, info) { if (id === tabId && info.status === "complete") finish(true); }
      chrome.tabs.onUpdated.addListener(listener);
    });
  }

  // Fetch fresh categories from the org's open calendar tab. With openTab,
  // a missing calendar tab is opened in the background and read once loaded.
  // A non-empty result replaces the cache and is persisted; an empty result
  // keeps any stored list rather than wiping it.
  function loadFilterCategories(orgId, opts) {
    if (!orgId) return Promise.resolve([]);
    var readFrom = function (tabId) {
      return chrome.scripting
        .executeScript({ target: { tabId: tabId }, world: "MAIN", func: readCalendarCategories })
        .then(function (res) {
          var cats = (res && res[0] && res[0].result) || [];
          if (cats.length) { filterCategories[orgId] = cats; persistCategories(); }
          else { filterCategories[orgId] = filterCategories[orgId] || []; }
          return filterCategories[orgId];
        });
    };
    var keepCache = function () {
      filterCategories[orgId] = filterCategories[orgId] || [];
      return filterCategories[orgId];
    };
    return chrome.tabs
      .query({ url: "https://app.courtreserve.com/Online/Calendar/Events/" + orgId + "/*" })
      .then(function (tabs) {
        if (tabs.length) return readFrom(tabs[0].id).catch(keepCache);
        if (!(opts && opts.openTab)) return keepCache();
        // No calendar tab for this org — open one in the background and
        // read the FILTER panel once the page has loaded.
        return chrome.tabs
          .create({ url: "https://app.courtreserve.com/Online/Calendar/Events/" + orgId + "/Month", active: false })
          .then(function (tab) {
            return waitForTabComplete(tab.id).then(function () {
              // Give the page a beat to render the FILTER panel.
              return new Promise(function (r) { setTimeout(r, 1500); })
                .then(function () { return readFrom(tab.id).catch(keepCache); });
            });
          })
          .catch(keepCache);
      })
      .catch(keepCache);
  }

  /**
   * Populate the category list for an org: use the stored list when we have
   * one (instant, works with no calendar tab open); fetch from the org's
   * calendar tab otherwise. retry=true re-fetches once after a calendar
   * navigation has had time to load.
   */
  function ensureCategories(orgId, opts) {
    if (filterCategories[orgId] && filterCategories[orgId].length) {
      fillFields();
      return;
    }
    loadFilterCategories(orgId).then(fillFields);
    if (opts && opts.retry) {
      setTimeout(function () { loadFilterCategories(orgId).then(fillFields); }, 5000);
    }
  }

  /** Rebuild the filter checklist for the org, preserving the stored picks. */
  function fillFilterOptions(s, orgId) {
    var cats = filterCategories[orgId] || [];
    var pickedCats = s.eventFilterCategories || [];
    // Legacy single-category picks are migrated into eventFilterCategories by
    // crlib on load; a leftover text-mode value is shown as a custom row.
    var customText = s.eventFilterMode !== "category" && s.eventFilter ? s.eventFilter : "";

    var rows = cats.map(function (c) {
      return { kind: "category", name: c.name, color: c.color,
        checked: pickedCats.some(function (p) { return p.name === c.name; }) };
    });
    // A picked category missing from the page's current list still shows —
    // the stored pick keeps working (color match needs no page data).
    pickedCats.forEach(function (p) {
      if (!rows.some(function (r) { return r.name === p.name; })) {
        rows.push({ kind: "category", name: p.name, color: p.color, checked: true, stale: true });
      }
    });
    if (customText) rows.push({ kind: "text", name: customText, color: "", checked: true });

    setFilterList.innerHTML = rows.length
      ? rows.map(function (r) {
          var label = r.kind === "text" ? 'Custom text: "' + r.name + '"' : r.name + (r.stale ? " (not on this month's calendar)" : "");
          // Per-category window rule detected by Auto Fill, when known; a
          // remembered "no countdown" verdict shows as a muted tag instead.
          var win = r.kind === "category" && s.categoryWindows && s.categoryWindows[r.name];
          var noCd = r.kind === "category" && (s.noCountdownCategories || []).indexOf(r.name) !== -1;
          var ruleTag = win
            ? '<span class="cat-rule">' + win.daysBefore + "d @ " + esc(fmtOpenTime(win.openTime)) + "</span>"
            : (noCd ? '<span class="cat-rule missing">no countdown</span>' : "");
          return '<label>' +
            '<input type="checkbox" data-kind="' + r.kind + '" data-name="' + esc(r.name) + '" data-color="' + esc(r.color) + '"' +
            (r.checked ? " checked" : "") + ">" +
            '<span class="swatch" style="background:' + (r.color ? esc(r.color) : "transparent") + '"></span>' +
            '<span class="cat-name">' + esc(label) + "</span>" + ruleTag + "</label>";
        }).join("")
      : '<div class="hint">No categories loaded yet.</div>';

    // Guidance under the dropdown depends on what was loaded.
    updateFilterNote(orgId);
  }

  // Guidance under the dropdown depends on what was loaded.
  function updateFilterNote(orgId) {
    var cats = filterCategories[orgId] || [];
    if (!(orgId in filterCategories)) {
      filterNote.textContent = "Loading this organization's calendar categories…";
    } else if (cats.length) {
      filterNote.textContent =
        orgDisplayName(orgId) + "'s categories (the FILTER list). " +
        "Matching uses the event's category — its calendar color — not its title. " +
        "Nothing checked = no ⏰ buttons. Checking a category auto-detects its opening rule.";
    } else {
      filterNote.textContent =
        "No categories loaded — open this organization's calendar, then click ↻ Refresh Categories. Stored selections still work.";
    }
  }

  // Runs in the calendar page's MAIN world. Must be fully self-contained.
  // Applies `names` (extension category selections) to the CourtReserve
  // FILTER panel: checks exactly those categories, unchecks the rest,
  // clicks the panel's Filter button, then closes the drawer. An empty
  // `names` array clears the filter entirely (all events shown).
  function applyCalendarCategories(names) {
    try {
      var rows = document.querySelectorAll(".custom-checkbox.rowCheckbox");
      if (!rows.length && typeof openLeftNav === "function") {
        openLeftNav(); // some org pages render the panel lazily
        rows = document.querySelectorAll(".custom-checkbox.rowCheckbox");
      }
      if (!rows.length) return { ok: false, error: "FILTER panel not found on this page." };
      var changed = 0;
      for (var i = 0; i < rows.length; i++) {
        var label = rows[i].querySelector("label.k-checkbox-label");
        var box = rows[i].querySelector("input.category-chk");
        if (!label || !box) continue;
        var want = names.indexOf(label.innerText.trim()) >= 0;
        if (box.checked !== want) { box.click(); changed++; }
      }
      // Checkbox changes apply to the calendar immediately (verified) — no
      // Filter-button click needed. Close the drawer so the user sees the
      // filtered calendar right away.
      var nav = document.querySelector(".left-filter-nav");
      var closeBtn = nav ? nav.querySelector(".closebtn") : null;
      if (closeBtn) closeBtn.click();
      return { ok: true, changed: changed };
    } catch (e) {
      return { ok: false, error: String(e) };
    }
  }

  /** Apply the Settings category picks to the CourtReserve FILTER panel. */
  function applyCategoriesToCalendar(orgId) {
    var names = readFilterSelection().categories.map(function (c) { return c.name; });
    var note = document.getElementById("applyFilterNote");
    var defaultNote = "Checks the same categories in CourtReserve's FILTER panel — one click instead of re-picking them there.";
    function flash(msg) {
      note.textContent = msg;
      setTimeout(function () { note.textContent = defaultNote; }, 4000);
    }
    function applyTo(tabId) {
      return chrome.scripting
        .executeScript({ target: { tabId: tabId }, world: "MAIN", func: applyCalendarCategories, args: [names] })
        .then(function (res) {
          var r = res && res[0] && res[0].result;
          if (r && r.ok) {
            flash(names.length
              ? "Applied " + names.length + " categor" + (names.length === 1 ? "y" : "ies") + " to the calendar FILTER ✓"
              : "Cleared the calendar FILTER — all events shown ✓");
          } else {
            flash("Couldn't apply: " + ((r && r.error) || "no response from the calendar tab."));
          }
        })
        .catch(function (e) { flash("Couldn't apply: " + e); });
    }
    flash("Applying to the calendar FILTER…");
    return chrome.tabs
      .query({ url: "https://app.courtreserve.com/Online/Calendar/Events/" + orgId + "/*" })
      .then(function (tabs) {
        if (tabs.length) return applyTo(tabs[0].id);
        return chrome.tabs
          .create({ url: "https://app.courtreserve.com/Online/Calendar/Events/" + orgId + "/Month", active: false })
          .then(function (tab) {
            return waitForTabComplete(tab.id).then(function () {
              return new Promise(function (r) { setTimeout(r, 1500); })
                .then(function () { return applyTo(tab.id); });
            });
          });
      })
      .catch(function (e) { flash("Couldn't apply: " + e); });
  }

  // The category list is fixed-height (4 rows) and scrollable — every
  // category always shows, checked or not.
  filterReload.addEventListener("click", function (ev) {
    ev.stopPropagation();
    filterNote.textContent = "Refreshing categories — opening the calendar if needed…";
    loadFilterCategories(settingsOrgId, { openTab: true }).then(fillFields);
  });

  document.getElementById("optApplyFilter").addEventListener("click", function () {
    applyCategoriesToCalendar(settingsOrgId);
  });

  /** Read the checked filter rows as settings fields. */
  function readFilterSelection() {
    var checked = setFilterList.querySelectorAll("input[type=checkbox]:checked");
    var cats = [];
    var custom = "";
    for (var i = 0; i < checked.length; i++) {
      var kind = checked[i].getAttribute("data-kind");
      if (kind === "text") custom = checked[i].getAttribute("data-name") || "";
      else cats.push({ name: checked[i].getAttribute("data-name") || "", color: checked[i].getAttribute("data-color") || "" });
    }
    return { categories: cats, customText: custom };
  }

  /**
   * Build a full settings object: start from the last saved state and apply
   * the window's field values, org-scoped when the Settings window edits a
   * specific org.
   */
  function buildSettings(daysBefore, openTime, sel, fireDelayMinutes) {
    var s = {
      daysBefore: fullSettings.daysBefore,
      openTime: fullSettings.openTime,
      eventFilter: fullSettings.eventFilter,
      eventFilterMode: fullSettings.eventFilterMode,
      eventFilterColor: fullSettings.eventFilterColor,
      eventFilterCategories: fullSettings.eventFilterCategories,
      perOrg: fullSettings.perOrg || {},
      fireDelayMinutes: fullSettings.fireDelayMinutes,
      showAutoRegButtons: optAutoRegButtons.checked,
      showOpensIndicator: optOpensIndicator.checked,
    };
    var orgId = settingsOrgId;
    if (orgId) {
      var perOrg = {};
      Object.keys(s.perOrg).forEach(function (k) { perOrg[k] = s.perOrg[k]; });
      // Spread the existing override: per-category window rules
      // (categoryWindows, set by Auto Fill) must survive a save here.
      var existing = perOrg[orgId] || {};
      perOrg[orgId] = { ...existing, daysBefore: daysBefore, openTime: openTime, eventFilter: sel.customText, eventFilterMode: "text", eventFilterColor: "", eventFilterCategories: sel.categories, fireDelayMinutes: fireDelayMinutes };
      s.perOrg = perOrg;
    } else {
      s.daysBefore = daysBefore;
      s.openTime = openTime;
      s.eventFilter = sel.customText;
      s.eventFilterMode = "text";
      s.eventFilterColor = "";
      s.eventFilterCategories = sel.categories;
      s.fireDelayMinutes = fireDelayMinutes;
    }
    return s;
  }

  function loadSettingsPane() {
    return Promise.all([CRLib.settings.load(), CRLib.orgs.list(), CRLib.store.list(), detectBrowserTabs(), chrome.storage.local.get(["uiTopOrg", "orgCategories", "initState", "lruOrg"])]).then(function (r) {
      fullSettings = r[0];
      knownOrgs = r[1];
      var tabs = r[3]; // { count, anyOrg, calendarOrg }
      var browserOrg = tabs.anyOrg;
      var saved = r[4] || {};

      // First run = nothing learned about any organization yet. The init pane
      // owns the popup until the background chain has finished once.
      var firstRun = knownOrgs.length === 0 &&
        Object.keys(fullSettings.perOrg || {}).length === 0;
      if (firstRun) {
        var init = saved.initState;
        if (init && init.running && Date.now() - (init.at || 0) < 6 * 60 * 1000) {
          // Chain already going (popup reopened mid-run) — just watch.
          showInitPane("working");
          initWorkingNote.textContent = INIT_STAGES[init.stage] || "Working…";
          return;
        }
        if (!browserOrg) {
          // No CourtReserve tab anywhere — ask the user to open one.
          showInitPane("need-site");
          return;
        }
        if (!initAutoStarted) {
          // CourtReserve is up — run the initializer once, then keep loading.
          initAutoStarted = true;
          showInitPane("working");
          initWorkingNote.textContent = INIT_STAGES["find-org"];
          chrome.runtime.sendMessage({ type: "initStart" }, function () {});
        }
      }

      // Seed the in-memory category cache with the persisted per-org lists.
      var storedCats = saved.orgCategories || {};
      Object.keys(storedCats).forEach(function (id) { filterCategories[id] = storedCats[id]; });
      if (browserOrg) {
        // Persist it so the dropdown shows a name once one is learned, and
        // preselect it — the popup opens on the org being viewed.
        CRLib.orgs.learn([{ id: browserOrg, name: "" }]);
        if (!knownOrgs.some(function (o) { return o.id === browserOrg; })) {
          knownOrgs.push({ id: browserOrg, name: "", primary: false });
        }
      }

      // --- Open-on organization sync --------------------------------------
      // A CourtReserve CALENDAR page open anywhere wins over the persisted
      // dropdown pick: the popup switches to that org exactly as if the user
      // picked it in the top dropdown (persisted selection, retargeted
      // Settings fields, fresh categories) — except the browser is NOT
      // navigated, since the user is already on that org's calendar — and
      // the org becomes the LRU (least recently used) organization.
      var syncedOrg = "";
      if (!firstRun && tabs.calendarOrg) {
        syncedOrg = tabs.calendarOrg;
        chrome.storage.local.set({ uiTopOrg: syncedOrg, lruOrg: { id: syncedOrg, at: Date.now() } });
      }
      // No CourtReserve page open at all → open the LRU org's calendar page
      // (falling back to the persisted pick, then the Primary/first learned
      // org). The background owns the tab: if CourtReserve detours to its
      // sign-in page, the user lands on the calendar after signing in, and
      // the org's categories are loaded there. The new active tab closes
      // this popup — syncing the selection first covers the brief overlap.
      if (!firstRun && tabs.count === 0 && !openAutoFired) {
        var lru = saved.lruOrg && /^\d+$/.test(String(saved.lruOrg.id || "")) ? String(saved.lruOrg.id) : "";
        var primary = knownOrgs.filter(function (o) { return o.primary; })[0] || knownOrgs[0];
        var fallback = (saved.uiTopOrg && /^\d+$/.test(String(saved.uiTopOrg)) && String(saved.uiTopOrg)) ||
          (primary && /^\d+$/.test(String(primary.id)) ? String(primary.id) : "");
        var openOrg = lru || fallback;
        if (openOrg) {
          openAutoFired = true;
          chrome.runtime.sendMessage({ type: "openOrgCalendar", orgId: openOrg }, function () {});
          syncedOrg = openOrg; // background persists lruOrg; keep the UI in step
          chrome.storage.local.set({ uiTopOrg: openOrg });
        }
      }

      // Top dropdown: a synced org wins; otherwise a persisted pick (even
      // "All"); otherwise default to the org being viewed, matching the old
      // limit-to-current-org default.
      var ids = collectOrgIds(r[2], (syncedOrg || browserOrg) || undefined);
      var hasSaved = Object.prototype.hasOwnProperty.call(saved, "uiTopOrg");
      var topSel = syncedOrg ||
        (hasSaved
          ? (saved.uiTopOrg && ids.indexOf(saved.uiTopOrg) !== -1 ? saved.uiTopOrg : "")
          : (browserOrg || ""));
      renderTopOrgSelect(r[2], topSel);
      setSettingsOrg(topSel || browserOrg, r[2]);
      fillFields();
      // Stored categories show instantly; fetch only when this org has none
      // (retry once after a sync — the same setup the dropdown switch does).
      ensureCategories(settingsOrgId, syncedOrg ? { retry: true } : undefined);
      // The popup opened on (or synced to) an org — investigate any selected
      // category still missing a detected rule (guards keep this cheap).
      scheduleRuleCheck();
      render(); // apply the org filter to the Scheduled list
    });
  }

  // The top Organization dropdown is the only org switcher — shared by both
  // panels: it filters the Scheduled list, retargets the Settings fields,
  // and drives the browser to that org's calendar so everything stays in sync.
  topOrg.addEventListener("change", function () {
    chrome.storage.local.set({ uiTopOrg: topOrg.value });
    // An explicit switch makes the org the LRU ("All organizations" doesn't).
    if (topOrg.value) chrome.storage.local.set({ lruOrg: { id: topOrg.value, at: Date.now() } });
    if (topOrg.value && settingsOrgId !== topOrg.value) {
      setSettingsOrg(topOrg.value);
      fillFields();
      // Categories differ per org — stored lists show instantly; otherwise
      // fetch, retrying once while the navigation below loads the tab.
      ensureCategories(topOrg.value, { retry: true });
      // Org switched — investigate any selected category missing a rule.
      scheduleRuleCheck();
      // Navigate the browser to this org's calendar — from either panel.
      var url = "https://app.courtreserve.com/Online/Calendar/Events/" + topOrg.value + "/Month";
      chrome.tabs.query({ active: true, currentWindow: true }).then(function (tabs) {
        var t = tabs[0];
        if (t && /^https:\/\/app\.courtreserve\.com\//.test(t.url || "")) {
          chrome.tabs.update(t.id, { url: url });
        } else {
          chrome.tabs.create({ url: url, active: true });
        }
      });
    }
    render();
  });

  // Calendar display options are global and take effect immediately — no
  // Save needed; the calendar re-renders on the settings change.
  function saveDisplayPrefs() {
    if (!fullSettings) return;
    var s = {
      daysBefore: fullSettings.daysBefore,
      openTime: fullSettings.openTime,
      eventFilter: fullSettings.eventFilter,
      eventFilterMode: fullSettings.eventFilterMode,
      eventFilterColor: fullSettings.eventFilterColor,
      eventFilterCategories: fullSettings.eventFilterCategories,
      perOrg: fullSettings.perOrg || {},
      fireDelayMinutes: fullSettings.fireDelayMinutes,
      showAutoRegButtons: optAutoRegButtons.checked,
      showOpensIndicator: optOpensIndicator.checked,
    };
    CRLib.settings.save(s).then(function () {
      fullSettings = s;
      optsNote.textContent = "Saved ✓";
      setTimeout(function () { optsNote.textContent = "Apply to all organizations, effective immediately."; }, 1500);
    });
  }
  optAutoRegButtons.addEventListener("change", saveDisplayPrefs);
  optOpensIndicator.addEventListener("change", saveDisplayPrefs);

  // --- Auto-investigate window rules -----------------------------------------
  // Hover information must be ACCURATE, never estimated: selecting a category
  // that has no detected rule automatically kicks off an Auto Fill run for
  // this org (which walks every selected category still missing a rule).
  // Debounced: several quick picks fold into ONE run a few seconds after the
  // last click, so selecting categories never storms the browser with tabs.
  var ruleCheckTimer = null;
  function scheduleRuleCheck() {
    if (!settingsOrgId) return;
    clearTimeout(ruleCheckTimer);
    ruleCheckTimer = setTimeout(function () {
      if (!fullSettings) return;
      var eff = CRLib.settings.mergeOrg(fullSettings, settingsOrgId);
      var wins = eff.categoryWindows || {};
      var noCd = eff.noCountdownCategories || [];
      var missing = (eff.eventFilterCategories || []).some(function (c) { return !wins[c.name] && noCd.indexOf(c.name) === -1; });
      if (!missing) return; // every selected category already has a real rule
      chrome.storage.local.get(["pendingAutofill", "autofillResult"]).then(function (d) {
        if (d.pendingAutofill) return; // a run is already in flight
        // A run that just failed (e.g. no not-yet-open events to read) isn't
        // retried immediately — the next selection change can trigger it.
        if (d.autofillResult && d.autofillResult.ok === false &&
            Date.now() - (d.autofillResult.at || 0) < 2 * 60 * 1000) return;
        autofillNote.textContent = "Detecting… a calendar tab opens in the background (takes a few seconds).";
        chrome.runtime.sendMessage({ type: "autofillStart", orgId: settingsOrgId }, function () {});
      });
    }, 6000);
  }

  // Category picks take effect immediately — no "Save settings" click needed.
  // Days/time/delay are not touched here: the effective (last saved) values
  // are re-applied as-is.
  setFilterList.addEventListener("change", function () {
    if (!fullSettings) return;
    var sel = readFilterSelection();
    var eff = CRLib.settings.mergeOrg(fullSettings, settingsOrgId);
    var s = buildSettings(eff.daysBefore, eff.openTime, sel, eff.fireDelayMinutes);
    CRLib.settings.save(s).then(function () {
      fullSettings = s;
      filterNote.textContent = "Saved ✓";
      setTimeout(function () { updateFilterNote(settingsOrgId); }, 1500);
      scheduleRuleCheck(); // new picks without a detected rule get investigated
    });
  });

  // Auto-save the fire delay when it changes. Days/opening-time are no longer
  // user-editable fields — Auto Fill detects them per category; the stored
  // org-level values stay as the silent fallback.
  function autoSaveSettings() {
    if (!fullSettings) return;
    var fireDelayMinutes = parseInt(setDelay.value, 10);
    if (!Number.isInteger(fireDelayMinutes) || fireDelayMinutes < 0) fireDelayMinutes = 0;
    else if (fireDelayMinutes > 30) fireDelayMinutes = 30;
    setDelay.value = String(fireDelayMinutes);

    var sel = readFilterSelection();
    var eff = CRLib.settings.mergeOrg(fullSettings, settingsOrgId);
    var s = buildSettings(eff.daysBefore, eff.openTime, sel, fireDelayMinutes);
    CRLib.settings.save(s).then(function () {
      fullSettings = s;
    });
  }
  setDelay.addEventListener("change", autoSaveSettings);

  // --- Auto Fill --------------------------------------------------------------
  function showAutofillResult(r) {
    autofillNote.innerHTML =
      '<span style="color:' + (r.ok ? "#15803d" : "#b91c1c") + ';">' +
      (r.ok ? "✓ " : "✗ ") + esc(r.message) + "</span>";
  }

  autofillBtn.addEventListener("click", function () {
    autofillBtn.disabled = true;
    autofillNote.textContent = "Detecting… a calendar tab opens in the background (takes a few seconds).";
    // A manual click is an explicit retry: forget any "no countdown" verdicts
    // remembered for this org so those categories are investigated again.
    var start = function () {
      chrome.runtime.sendMessage({ type: "autofillStart", orgId: settingsOrgId }, function () {
        setTimeout(function () { autofillBtn.disabled = false; }, 3000);
      });
    };
    var ex = (fullSettings && fullSettings.perOrg && fullSettings.perOrg[settingsOrgId]) || {};
    if (settingsOrgId && (ex.noCountdownCategories || []).length) {
      var perOrg = {};
      Object.keys(fullSettings.perOrg).forEach(function (k) { perOrg[k] = fullSettings.perOrg[k]; });
      var cleared = {};
      Object.keys(ex).forEach(function (k) { if (k !== "noCountdownCategories") cleared[k] = ex[k]; });
      perOrg[settingsOrgId] = cleared;
      var sel = readFilterSelection();
      var s = buildSettings(ex.daysBefore !== undefined ? ex.daysBefore : fullSettings.daysBefore,
        ex.openTime !== undefined ? ex.openTime : fullSettings.openTime, sel,
        ex.fireDelayMinutes !== undefined ? ex.fireDelayMinutes : fullSettings.fireDelayMinutes);
      s.perOrg = perOrg;
      CRLib.settings.save(s).then(function () { fullSettings = s; start(); });
    } else {
      start();
    }
  });

  function loadAutofillState() {
    chrome.storage.local.get(["pendingAutofill", "autofillResult"]).then(function (data) {
      updateDetectBanner(data.pendingAutofill || null);
      if (data.pendingAutofill) {
        autofillNote.textContent = "Detecting… a calendar tab opens in the background (takes a few seconds).";
      } else if (data.autofillResult && Date.now() - data.autofillResult.at < 30 * 60 * 1000) {
        showAutofillResult(data.autofillResult);
      }
    });
  }

  /** Top-of-popup progress while an Auto Fill run works in the background —
      visible from every pane so the pause never reads as buggy. */
  function updateDetectBanner(pa) {
    if (!pa) {
      detectBanner.style.display = "none";
      return;
    }
    var done = (pa.saves || []).length;
    var club = orgDisplayName(pa.orgId || "");
    detectBanner.textContent = "⏳ Detecting registration rules for " + club +
      " — a background tab reads each selected category's countdown." +
      (done ? " " + done + " done so far…" : "");
    detectBanner.style.display = "block";
  }

  chrome.storage.onChanged.addListener(function (changes, area) {
    if (area === "local" && changes.entries) render();
    if (area === "local" && changes.settings) loadSettingsPane();
    if (area === "local" && changes.orgs) loadSettingsPane(); // org names learned
    if (area === "local" && changes.autofillResult && changes.autofillResult.newValue) {
      showAutofillResult(changes.autofillResult.newValue);
      loadSettingsPane(); // fields refresh with the detected rule
    }
    if (area === "local" && changes.pendingAutofill) loadAutofillState();
    if (area === "local" && changes.initState) renderInitProgress(changes.initState.newValue);
    if (area === "local" && changes.orgCategories) loadSettingsPane(); // init loaded categories
    if (area === "local" && changes.license) renderPremium();
  });

  render();
  renderPremium();
  loadSettingsPane();
  loadAutofillState();
})();
