/* Popup: scheduled entries, status line, settings, and requirements. */
(function () {
  "use strict";

  var paneEntries = document.getElementById("paneEntries");
  var paneSettings = document.getElementById("paneSettings");
  var paneReq = document.getElementById("paneReq");
  var paneLog = document.getElementById("paneLog");
  var tabEntries = document.getElementById("tabEntries");
  var tabSettings = document.getElementById("tabSettings");
  var tabReq = document.getElementById("tabReq");
  var tabLog = document.getElementById("tabLog");
  var statusLine = document.getElementById("statusLine");
  var statusCard = document.getElementById("statusCard");
  var setDelaySecs = document.getElementById("setDelaySecs");
  var setFilterSummary = document.getElementById("setFilterSummary");
  var setFilterList = document.getElementById("setFilterList");
  var filterReload = document.getElementById("filterReload");
  var filterNote = document.getElementById("filterNote");
  var settingsOrgId = ""; // org the Settings window fields edit
  var autofillBtn = document.getElementById("autofillBtn");
  var autofillNote = document.getElementById("autofillNote");
  var detectBanner = document.getElementById("detectBanner");
  var optAutoRegButtons = document.getElementById("optAutoRegButtons");
  var optOpensIndicator = document.getElementById("optOpensIndicator");
  var profileLine = document.getElementById("profileLine");
  var topOrg = document.getElementById("topOrg");
  var premFree = document.getElementById("premFree");
  var premActive = document.getElementById("premActive");
  var premUpgrade = document.getElementById("premUpgrade");
  var premKey = document.getElementById("premKey");
  var premActivate = document.getElementById("premActivate");
  var premToggleDeactivate = document.getElementById("premToggleDeactivate");
  var premDeactivateWrap = document.getElementById("premDeactivateWrap");
  var premDeactivate = document.getElementById("premDeactivate");
  var premNote = document.getElementById("premNote");
  var paneInit = document.getElementById("paneInit");
  var initNeedSite = document.getElementById("initNeedSite");
  var initWorking = document.getElementById("initWorking");
  var initStep = document.getElementById("initStep");
  var initWorkingNote = document.getElementById("initWorkingNote");
  var initDone = document.getElementById("initDone");
  var initDoneTitle = document.getElementById("initDoneTitle");
  var initDoneNote = document.getElementById("initDoneNote");
  var initOpenSite = document.getElementById("initOpenSite");
  var initContinue = document.getElementById("initContinue");

  // --- First-run auto-initialization -----------------------------------------
  // On the very first use (no organization learned yet) the init pane takes
  // over the whole popup. If no CourtReserve tab is open it asks the user to
  // open one; once a calendar/portal tab exists the background initializer
  // chain (initStart) runs automatically — finding the club, loading its
  // categories, and detecting the registration window — then the normal
  // Scheduled tab appears. Progress lives in chrome.storage.local.initState,
  // so closing the popup mid-run loses nothing: reopening shows progress.
  var INIT_STAGES = {
    "find-org": "Setting up — looking for your CourtReserve club… (a tab opens if needed — log in if asked).",
    categories: "Setting up — reading the calendar's categories…",
    profile: "Setting up — checking your profile (Gender and Rating)…",
    autofill: "Setting up — learning when registration opens for your categories…",
  };
  var initAutoStarted = false; // fire initStart at most once per popup open
  var openAutoFired = false;   // fire openOrgCalendar at most once per popup open
  var initFailDismissed = false; // user clicked Continue past a failed setup

  function showInitPane(mode) {
    document.querySelector(".tabs").style.display = "none";
    statusCard.style.display = "none";
    [paneEntries, paneSettings, paneReq, paneLog].forEach(function (p) { p.style.display = "none"; });
    paneInit.style.display = "";
    initNeedSite.style.display = mode === "need-site" ? "" : "none";
    initWorking.style.display = mode === "working" ? "" : "none";
    initDone.style.display = mode === "done" ? "" : "none";
  }

  function hideInitPane() {
    paneInit.style.display = "none";
    document.querySelector(".tabs").style.display = "";
    activate(tabEntries);
  }

  function initPaneVisible() {
    return paneInit.style.display !== "none";
  }

  // Live progress from the background chain (storage events drive this).
  function renderInitProgress(st) {
    if (!st || !initPaneVisible()) return;
    if (st.running) {
      showInitPane("working");
      initStep.textContent = INIT_STAGES[st.stage] || "Working…";
      if (st.stage === "autofill") {
        chrome.storage.local.get("pendingAutofill").then(function (d) {
          updateInitInspect(d.pendingAutofill || null);
        });
      } else {
        initWorkingNote.textContent = "Working…";
      }
      return;
    }
    if (st.stage === "done") {
      showInitPane("done");
      initDoneTitle.textContent = st.ok ? "Setup complete ✓" : "Setup needs attention";
      initDoneNote.innerHTML =
        '<span style="color:' + (st.ok ? "#15803d" : "#b91c1c") + ';">' + esc(st.message || "") + "</span>";
      if (st.ok && st.orgId) chrome.storage.local.set({ uiTopOrg: st.orgId });
      if (st.ok) {
        // Setup succeeded — tell the user, then close the popup so the next
        // open lands on the normal tabs with everything filtered and filled.
        initDoneNote.innerHTML += '<div style="margin-top:6px;color:#78716c;">All set — this window will close. Reopen the extension to see your schedule and settings.</div>';
        setTimeout(function () { window.close(); }, 2000);
      }
    }
  }

  /** Front-and-center line while the autofill run works: which category is
      being inspected right now. (v1.5.24: targeted visits only — the full
      category sweep and its "n of N" counter are gone.) */
  function updateInitInspect(pa) {
    if (!initPaneVisible() || !initStep) return;
    if (!pa) return; // keep the stage line
    if (pa.stage === "details" && pa.category) {
      initStep.textContent = 'Inspecting: "Category: ' + pa.category + '"';
    } else {
      initStep.textContent = INIT_STAGES.autofill;
    }
    initWorkingNote.textContent = "Working…";
  }

  // --- Tab reuse ---------------------------------------------------------------
  // Every "open CourtReserve" affordance reuses an existing CourtReserve tab
  // (active first, then most recently active) instead of stacking duplicates.
  function sortTabsByRecency(tabs) {
    tabs.sort(function (a, b) {
      if (!!a.active !== !!b.active) return a.active ? -1 : 1;
      return (b.lastAccessed || 0) - (a.lastAccessed || 0);
    });
    return tabs;
  }
  function focusTab(t) {
    chrome.tabs.update(t.id, { active: true });
    chrome.windows.update(t.windowId, { focused: true });
  }
  /** Bring a matching existing tab forward; otherwise create `url`.
      Automation (quarantine-window) tabs are never user targets — a tab the
      extension opened for background work must not be focused (v1.6.0). */
  function openOrFocusCourtReserve(url, matchUrl) {
    Promise.all([
      chrome.storage.local.get("crAutomationWindowId"),
      chrome.tabs.query({ url: matchUrl || "https://app.courtreserve.com/*" }),
    ]).then(function (r) {
      var qw = r[0] && r[0].crAutomationWindowId;
      var tabs = (r[1] || []).filter(function (t) { return t.windowId !== qw; });
      sortTabsByRecency(tabs);
      if (tabs.length) focusTab(tabs[0]);
      else chrome.tabs.create({ url: url, active: true });
    });
  }

  initOpenSite.addEventListener("click", function () {
    // The popup closes as the tab takes focus — the on-screen steps tell
    // the user to reopen the extension once the calendar is up.
    openOrFocusCourtReserve("https://app.courtreserve.com/");
  });

  initContinue.addEventListener("click", function () {
    initFailDismissed = true; // don't let loadSettingsPane re-show the failed pane
    hideInitPane();
    loadSettingsPane();
    render();
  });

  // --- Premium (Dodo Payments license + 14-day trial) -------------------------
  premUpgrade.href = CRLib.UPGRADE_URL;
  var premiumActive = false;
  var premiumPaid = false;
  var lastLicense = null;
  var premFreeNote = document.getElementById("premFreeNote");

  function renderPremium() {
    chrome.runtime.sendMessage({ type: "licenseStatus" }, function (r) {
      if (!r || !r.ok) return;
      var lic = r.license || null;
      lastLicense = lic;
      premiumActive = !!r.premium;
      premiumPaid = !!(lic && CRLib.license.isPaid(lic));
      premFree.style.display = premiumPaid ? "none" : "";
      premActive.style.display = premiumPaid ? "" : "none";
      if (premiumPaid) {
        premDeactivateWrap.style.display = "none";
        premToggleDeactivate.textContent = "Deactivate…";
      } else if (lic && lic.trialActive) {
        premFreeNote.innerHTML = "<b>Premium trial — " + lic.trialDaysLeft + " day" +
          (lic.trialDaysLeft === 1 ? "" : "s") + " left.</b> ⏰ Auto-Register and Run now are unlocked. " +
          "After the trial, registration reminders stay free forever.";
      } else if (lic && lic.trialStart) {
        premFreeNote.innerHTML = "<b>Your " + CRLib.license.TRIAL_DAYS + "-day Premium trial has ended.</b> " +
          "Upgrade to bring back ⏰ Auto-Register — the bold registration-opening dates are yours free forever.";
      }
      updateDisplayPrefChecks();
    });
  }

  // The buttons checkbox shows the EFFECTIVE value: explicit user choice when
  // set, otherwise the trial-aware default (on during trial/paid, off after).
  function updateDisplayPrefChecks() {
    if (!fullSettings) return;
    optAutoRegButtons.checked = fullSettings.showAutoRegButtons === null
      ? premiumActive
      : fullSettings.showAutoRegButtons === true;
    optOpensIndicator.checked = fullSettings.showOpensIndicator !== false;
  }

  premActivate.addEventListener("click", function () {
    premActivate.disabled = true;
    premNote.textContent = "Activating…";
    chrome.runtime.sendMessage(
      { type: "licenseActivate", key: premKey.value.trim(), deviceName: "Chrome popup" },
      function (r) {
        premActivate.disabled = false;
        if (r && r.ok) {
          premNote.textContent = "";
          premKey.value = "";
          renderPremium();
        } else {
          premNote.textContent = "⚠ " + ((r && r.message) || "Activation failed.");
        }
      }
    );
  });

  premDeactivate.addEventListener("click", function () {
    premNote.textContent = "Deactivating…";
    chrome.runtime.sendMessage({ type: "licenseDeactivate" }, function () {
      premNote.textContent = "";
      renderPremium();
    });
  });

  premToggleDeactivate.addEventListener("click", function () {
    var showing = premDeactivateWrap.style.display !== "none";
    premDeactivateWrap.style.display = showing ? "none" : "";
    premToggleDeactivate.textContent = showing ? "Deactivate…" : "Hide";
  });

  var optsNote = document.getElementById("optsNote");
  var fullSettings = null; // complete settings object (defaults + per-org)
  var knownOrgs = [];      // [{ id, name, primary }] from CourtReserve visits

  function esc(s) {
    return String(s || "").replace(/[&<>"']/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
    });
  }

  // --- Tabs ------------------------------------------------------------------
  function activate(tab) {
    [tabEntries, tabSettings, tabReq, tabLog].forEach(function (t) { t.classList.remove("active"); });
    [paneEntries, paneSettings, paneReq, paneLog].forEach(function (p) { p.style.display = "none"; });
    tab.classList.add("active");
    // The LOG card belongs to the Scheduled panel only.
    statusCard.style.display = tab === tabEntries ? "" : "none";
    (tab === tabEntries ? paneEntries : tab === tabSettings ? paneSettings : tab === tabReq ? paneReq : paneLog).style.display = "";
    if (tab === tabLog) renderLog();
  }
  tabEntries.addEventListener("click", function () { activate(tabEntries); });
  tabSettings.addEventListener("click", function () { activate(tabSettings); });
  tabReq.addEventListener("click", function () { activate(tabReq); });
  tabLog.addEventListener("click", function () { activate(tabLog); });

  // --- Activity log ------------------------------------------------------------
  function logStatusClass(status) {
    return { ok: "log-ok", fail: "log-fail", warn: "log-warn", info: "log-info", run: "log-run" }[status] || "log-info";
  }

  // Compact house-style time: "11pm", "10:15am" — no space, on-the-hour
  // times drop ":00".
  function fmtLogTime(d) {
    var h = d.getHours(), m = d.getMinutes();
    var ampm = h >= 12 ? "pm" : "am";
    h = h % 12 || 12;
    return m === 0 ? h + ampm : h + ":" + String(m).padStart(2, "0") + ampm;
  }

  // Compact times embedded in description text: "7:00 PM" -> "7pm",
  // "7:15 PM" -> "7:15pm".
  function compactTimes(text) {
    return String(text || "").replace(/(\d{1,2}):(\d{2})\s*([AaPp])\.?[Mm]\.?/g,
      function (_, h, m, ap) { return h + (m === "00" ? "" : ":" + m) + ap.toLowerCase() + "m"; });
  }

  // Outcome word for entries logged before the outcome field existed.
  var LEGACY_OUTCOME = { ok: "Success", fail: "Failed", warn: "Warning", info: "Note", run: "Started" };

  // Three columns: Date-Time (date, time on the next line), Action (what was
  // being done: "Auto-Register", "Set categories", …), Result (colored
  // outcome word — green/red/yellow — then the detail on the next line).
  function renderLog() {
    chrome.storage.local.get("activityLog", function (res) {
      var log = Array.isArray(res.activityLog) ? res.activityLog : [];
      if (!log.length) {
        paneLog.innerHTML = '<div class="empty">No events yet.</div>';
        return;
      }
      var rows = log.slice().reverse().map(function (e) {
        var d = new Date(e.at);
        var dateLine = CRLib.abbrevDate(
          d.toLocaleDateString("en-US", { weekday: "short", month: "short", day: "numeric" }));
        var outcome = e.outcome || LEGACY_OUTCOME[e.status] || "";
        return '<tr><td class="log-when">' + esc(dateLine) +
          '<span class="lt">' + esc(fmtLogTime(d)) + '</span></td>' +
          '<td class="log-event">' + esc(e.event) + '</td>' +
          '<td class="log-desc">' +
            (outcome
              ? '<div class="log-outcome ' + logStatusClass(e.status) + '">' + esc(outcome) + '</div>'
              : '') +
            '<div class="log-detail">' + esc(compactTimes(e.desc)) + '</div>' +
          '</td></tr>';
      }).join("");
      paneLog.innerHTML = '<div class="req"><table class="log-table"><thead><tr>' +
        '<th>Date-Time</th><th>Action</th><th>Result</th>' +
        '</tr></thead><tbody>' + rows + '</tbody></table></div>';
    });
  }

  document.getElementById("verLine").textContent =
    "Court Helper Version: v" + chrome.runtime.getManifest().version;

  document.getElementById("openCal").addEventListener("click", function (ev) {
    ev.preventDefault();
    // Open the month calendar for the org selected at the top (fall back to
    // the Settings org) — not the generic portal page. With nothing known,
    // open the portal root and let CourtReserve route to the user's org.
    // Either way, reuse an existing tab rather than stacking another one.
    var orgId = (topOrg && topOrg.value) || settingsOrgId || "";
    if (orgId) {
      openOrFocusCourtReserve(
        "https://app.courtreserve.com/Online/Calendar/Events/" + orgId + "/Month",
        "https://app.courtreserve.com/Online/Calendar/Events/" + orgId + "/*"
      );
    } else {
      openOrFocusCourtReserve("https://app.courtreserve.com/");
    }
  });

  // --- Status line -------------------------------------------------------------
  function renderStatus(entries) {
    var now = Date.now();
    var upcoming = entries
      .filter(function (e) { return e.status === "scheduled" || e.status === "retrying"; })
      .sort(function (a, b) { return a.fireAt - b.fireAt; })[0];
    var lastFired = entries
      .filter(function (e) { return e.lastRun; })
      .sort(function (a, b) { return b.lastRun.at - a.lastRun.at; })[0];

    var html = "";
    if (upcoming) {
      html += '<span class="next">Next fire: ' + esc(CRLib.fmtDateTime(new Date(upcoming.fireAt))) +
        "</span> — " + esc(upcoming.event) + ", " + esc(CRLib.abbrevDate(upcoming.date)) +
        ' <span style="color:#78716c;">· ' + esc(orgDisplayName(upcoming.orgId)) + "</span>";
    } else {
      html += "Nothing scheduled.";
    }
    if (lastFired) {
      html += '<hr class="logsep">Last fired: <span class="' + (lastFired.lastRun.ok ? "ok" : "fail") + '">' +
        (lastFired.lastRun.ok ? "✓ " : "✗ ") + esc(CRLib.abbrevDate(lastFired.lastRun.message)) + "</span> — " +
        esc(CRLib.fmtDateTime(new Date(lastFired.lastRun.at)));
      if (now - lastFired.lastRun.at > 7 * 86400000) html += " <span class=\"fail\">(over a week ago)</span>";
    }
    statusLine.innerHTML = html;
  }

  // --- Entries list ------------------------------------------------------------
  // Each entry is headed by its organization name. The Organization dropdown
  // at the top filters the list; "All organizations" shows everything.
  function render() {
    Promise.all([CRLib.store.list(), CRLib.orgs.list()])
      .then(function (r) {
      var entries = r[0];
      knownOrgs = r[1];
      var filterOrg = topOrg.value || "";
      if (filterOrg) {
        entries = entries.filter(function (e) { return e.orgId === filterOrg; });
      }
      entries.sort(function (a, b) { return a.fireAt - b.fireAt; });
      renderStatus(entries);
      if (!entries.length) {
        paneEntries.innerHTML = filterOrg
          ? '<div class="empty">No auto-registrations scheduled for <b>' + esc(orgDisplayName(filterOrg)) + '</b>.<br>' +
            'Pick "All organizations" above to see everything.</div>'
          : '<div class="empty">No auto-registrations scheduled.<br>' +
            'Open the CourtReserve calendar and click <b>⏰ Auto-Register</b> ' +
            'on any event whose window has not opened yet.</div>';
        return;
      }
      paneEntries.innerHTML = entries.map(function (e) {
        var status = e.status || "scheduled";
        var html =
          '<div class="entry">' +
          '<div class="org">' + esc(orgDisplayName(e.orgId)) + "</div>" +
          '<div class="ev">' + esc(e.event) + '<span class="badge ' + esc(status) + '">' + esc(status) + "</span></div>" +
          '<div class="when">' + esc(CRLib.abbrevDate(e.date)) + " · " + esc(e.time) + "</div>" +
          '<div class="fires">Fires ' + esc(CRLib.fmtDateTime(new Date(e.fireAt))) + "</div>";
        if (e.lastRun) {
          html +=
            '<div class="lastrun ' + (e.lastRun.ok ? "ok" : "fail") + '">' +
            (e.lastRun.ok ? "✓ " : "✗ ") + esc(CRLib.abbrevDate(e.lastRun.message)) +
            " — " + esc(CRLib.fmtDateTime(new Date(e.lastRun.at))) + "</div>";
        }
        html +=
          '<div class="row">' +
          '<button data-act="run" data-id="' + esc(e.id) + '">Run now</button>' +
          '<button data-act="cancel" class="danger" data-id="' + esc(e.id) + '">Remove</button>' +
          "</div></div>";
        return html;
      }).join("");
    });
  }

  paneEntries.addEventListener("click", function (ev) {
    var btn = ev.target.closest("button[data-act]");
    if (!btn) return;
    var id = btn.getAttribute("data-id");
    if (btn.getAttribute("data-act") === "run") {
      btn.textContent = "Running…";
      chrome.runtime.sendMessage({ type: "runNow", id: id }, function (r) {
        if (r && r.premiumRequired) {
          alert("Run now is a Premium feature — activate your license in the Settings tab.");
        }
        render();
      });
    } else {
      chrome.runtime.sendMessage({ type: "cancel", id: id }, render);
    }
  });

  // --- Settings ---------------------------------------------------------------
  // The Organization is the primary key: every field below can be determined
  // per organization. Switching orgs happens only in the top dropdown (the
  // popup opens on the one the browser is viewing); the stored default rule
  // is the invisible fallback whose values fill the fields of an org that has
  // nothing determined yet — by Auto Fill or by saving here.
  function fmtOpenTime(openTime) {
    var parts = openTime.split(":").map(Number);
    var h = parts[0], m = parts[1];
    return (h % 12 || 12) + ":" + String(m).padStart(2, "0") + " " + (h >= 12 ? "PM" : "AM");
  }

  function orgDisplayName(id) {
    for (var i = 0; i < knownOrgs.length; i++) {
      if (knownOrgs[i].id === id && knownOrgs[i].name) return knownOrgs[i].name;
    }
    return "Org " + id;
  }

  /** All org ids seen anywhere: learned list, per-org settings, entries. */
  function collectOrgIds(entries, extraId) {
    var ids = {};
    knownOrgs.forEach(function (o) { ids[o.id] = true; });
    Object.keys((fullSettings && fullSettings.perOrg) || {}).forEach(function (id) { ids[id] = true; });
    (entries || []).forEach(function (e) { if (e.orgId) ids[e.orgId] = true; });
    if (extraId) ids[extraId] = true;
    return Object.keys(ids);
  }

  /** Survey open CourtReserve tabs: how many, the org of any open CALENDAR
      page, and the org of any Online page at all. The window the popup was
      opened from WINS outright — its active tab is what the user is looking
      at right now. (v1.5.28: cross-window recency used to let a stale
      automation-opened calendar tab outrank it — e.g. an openOrgCalendar
      tab, which is focused and fresh — so the popup kept syncing to the
      wrong org and re-poisoning uiTopOrg/lruOrg on every open.) Only when
      the current window has no CourtReserve page do we fall back to a
      recency survey across windows (first run often has the calendar in a
      non-active tab/window). */
  function detectBrowserTabs() {
    var parse = function (tabs) {
      var anyOrg = "", calendarOrg = "";
      for (var i = 0; i < tabs.length; i++) {
        var url = tabs[i].url || "";
        if (!calendarOrg) {
          var mc = /\/Online\/Calendar\/Events\/(\d+)/.exec(url);
          if (mc) calendarOrg = mc[1];
        }
        if (!anyOrg) {
          var m =
            /\/Online\/(?:Calendar\/Events|Portal\/Index)\/(\d+)/.exec(url) ||
            /\/Online\/Events\/Details\/(\d+)\//.exec(url);
          if (m) anyOrg = m[1];
        }
      }
      return { anyOrg: anyOrg, calendarOrg: calendarOrg };
    };
    return Promise.all([
      chrome.storage.local.get("crAutomationWindowId"),
      chrome.tabs.query({ active: true, currentWindow: true }),
      chrome.tabs.query({ url: "https://app.courtreserve.com/Online/*" }),
    ]).then(function (r) {
      var qw = r[0] && r[0].crAutomationWindowId;
      var activeTab = r[1] && r[1][0];
      // v1.6.0: automation work lives in a dedicated unfocused window — its
      // tabs are never evidence of what the user is looking at.
      var tabs = (r[2] || []).filter(function (t) { return t.windowId !== qw; });
      if (activeTab && /^https:\/\/app\.courtreserve\.com\/Online\//.test(activeTab.url || "")) {
        var one = parse([activeTab]);
        return { count: Math.max(tabs.length, 1), anyOrg: one.anyOrg, calendarOrg: one.calendarOrg };
      }
      sortTabsByRecency(tabs);
      var all = parse(tabs);
      return { count: tabs.length, anyOrg: all.anyOrg, calendarOrg: all.calendarOrg };
    }).catch(function () { return { count: 0, anyOrg: "", calendarOrg: "" }; });
  }

  /** Sort org ids: primary first, then alphabetical by display name. */
  function sortOrgIds(ids) {
    return ids.sort(function (a, b) {
      var pa = knownOrgs.find(function (o) { return o.id === a; });
      var pb = knownOrgs.find(function (o) { return o.id === b; });
      if (pa && pa.primary) return -1;
      if (pb && pb.primary) return 1;
      return orgDisplayName(a).localeCompare(orgDisplayName(b));
    });
  }

  /** Top-of-popup org selector: "All organizations" plus every known org. */
  function renderTopOrgSelect(entries, preselectOrg) {
    var prev = preselectOrg !== undefined ? preselectOrg : topOrg.value;
    var ids = sortOrgIds(collectOrgIds(entries, prev || undefined));
    topOrg.innerHTML = '<option value="">All organizations</option>' + ids.map(function (id) {
      return '<option value="' + esc(id) + '">' + esc(orgDisplayName(id)) + " (" + esc(id) + ")</option>";
    }).join("");
    topOrg.value = prev && ids.indexOf(prev) !== -1 ? prev : "";
  }

  /** Settings edits one org at a time — shown as a bold label, not a select.
      Switching happens in the top dropdown; this just follows it. */
  function setSettingsOrg(id, entries) {
    if (!id) {
      var ids = sortOrgIds(collectOrgIds(entries));
      id = ids[0] || ""; // nothing learned yet — fields edit the default rule
    }
    settingsOrgId = id;
  }

  /** Fill the fields with the effective values for the selected org. */
  function fillFields() {
    if (!fullSettings) return;
    var orgId = settingsOrgId;
    var s = CRLib.settings.mergeOrg(fullSettings, orgId);
    setDelaySecs.value = String(s.fireDelaySeconds !== undefined ? s.fireDelaySeconds : 15);
    fillFilterOptions(s, orgId);
    updateDisplayPrefChecks();
  }

  // --- Category filter dropdown ------------------------------------------------
  // The calendar's FILTER categories come from the page's own FILTER panel
  // (the complete list — always in the DOM, unlike the scheduler's dataSource
  // which only holds the currently loaded month's events). Each category is
  // stored with its color: the site colors every event by category, so the
  // content script matches cells by background color — exact, no fuzzy text.
  var filterCategories = {}; // orgId -> [{name, color}] — memory cache over the persisted orgCategories store
  // (persistence is owned by the background's readCategoriesForOrg; the popup
  // only reads the store and mirrors it into this cache).

  // The FILTER-category READER lives in background.js (readCategoriesForOrg):
  // reading may open background tabs (calendar / Events → List), and a popup
  // promise chain dies the moment the popup closes — stranding those tabs
  // half-read (v1.5.29). The popup only asks via the "readCategories"
  // message; results arrive through the orgCategories storage change.

  /** Resolve when the tab finishes loading (or the timeout hits). */
  function waitForTabComplete(tabId, timeoutMs) {
    return new Promise(function (resolve) {
      var done = false;
      function finish(ok) {
        if (done) return;
        done = true;
        clearTimeout(timer);
        chrome.tabs.onUpdated.removeListener(listener);
        resolve(ok);
      }
      var timer = setTimeout(function () { finish(false); }, timeoutMs || 15000);
      function listener(id, info) { if (id === tabId && info.status === "complete") finish(true); }
      chrome.tabs.onUpdated.addListener(listener);
    });
  }

  /** Ask the background to (re)read an org's FILTER categories. */
  function requestCategoryRead(orgId, openTab) {
    chrome.runtime.sendMessage({ type: "readCategories", orgId: orgId, openTab: !!openTab }, function () {
      void chrome.runtime.lastError; // popup may close before the read ends — fine
      reloadStoredCategories(orgId);
    });
  }

  /** Mirror a freshly persisted list from storage into the live fields. */
  function reloadStoredCategories(orgId) {
    chrome.storage.local.get(["orgCategories"]).then(function (data) {
      var cats = (data && data.orgCategories || {})[orgId];
      if (cats && cats.length) { filterCategories[orgId] = cats; fillFields(); }
    });
  }

  /**
   * Populate the category list for an org: use the stored list when we have
   * one (instant, works with no calendar tab open); ask the background to
   * read the org's calendar otherwise. retry=true re-reads once after a
   * calendar navigation has had time to load.
   */
  function ensureCategories(orgId, opts) {
    if (filterCategories[orgId] && filterCategories[orgId].length) {
      fillFields();
      return;
    }
    requestCategoryRead(orgId, false);
    if (opts && opts.retry) {
      setTimeout(function () { requestCategoryRead(orgId, false); }, 5000);
    }
  }

  /** Rebuild the filter checklist for the org, preserving the stored picks. */
  var hiddenRestricted = []; // categories hidden by eligibility (v1.5.18)
  function fillFilterOptions(s, orgId) {
    var cats = filterCategories[orgId] || [];
    var pickedCats = s.eventFilterCategories || [];
    var eligMap = s.categoryEligibility || {};
    hiddenRestricted = [];
    var isRestricted = function (name) {
      var ce = eligMap[name];
      return ce && ce.eligible === false;
    };
    // Legacy single-category picks are migrated into eventFilterCategories by
    // crlib on load; a leftover text-mode value is shown as a custom row.
    var customText = s.eventFilterMode !== "category" && s.eventFilter ? s.eventFilter : "";

    // Categories whose Rating/Gender Restriction excludes the user's profile
    // are HIDDEN from the list — the user can't play them, so following them
    // would only produce registrations CourtReserve rejects.
    var rows = [];
    cats.forEach(function (c) {
      if (isRestricted(c.name)) {
        hiddenRestricted.push({ name: c.name, reason: (eligMap[c.name].reason || "restricted for you") });
        return;
      }
      rows.push({ kind: "category", name: c.name, color: c.color,
        checked: pickedCats.some(function (p) { return p.name === c.name; }) });
    });
    // A picked category missing from the page's current list still shows —
    // the stored pick keeps working (color match needs no page data).
    pickedCats.forEach(function (p) {
      if (isRestricted(p.name)) {
        hiddenRestricted.push({ name: p.name, reason: (eligMap[p.name].reason || "restricted for you") });
        return;
      }
      if (!rows.some(function (r) { return r.name === p.name; })) {
        rows.push({ kind: "category", name: p.name, color: p.color, checked: true, stale: true });
      }
    });
    if (customText) rows.push({ kind: "text", name: customText, color: "", checked: true });

    setFilterList.innerHTML = rows.length
      ? rows.map(function (r) {
          var label = r.kind === "text" ? 'Custom text: "' + r.name + '"' : r.name + (r.stale ? " (not on this month's calendar)" : "");
          // Per-category window rule detected by Auto Fill, when known; a
          // remembered "no countdown" verdict shows as a muted tag instead.
          var win = r.kind === "category" && s.categoryWindows && s.categoryWindows[r.name];
          var noCd = r.kind === "category" && (s.noCountdownCategories || []).indexOf(r.name) !== -1;
          var ruleTag = win
            ? '<span class="cat-rule">' + win.daysBefore + "d @ " + esc(fmtOpenTime(win.openTime)) + "</span>"
            : (noCd ? '<span class="cat-rule missing">no countdown</span>' : "");
          return '<label>' +
            '<input type="checkbox" data-kind="' + r.kind + '" data-name="' + esc(r.name) + '" data-color="' + esc(r.color) + '"' +
            (r.checked ? " checked" : "") + ">" +
            '<span class="swatch" style="background:' + (r.color ? esc(r.color) : "transparent") + '"></span>' +
            '<span class="cat-name">' + esc(label) + "</span>" + ruleTag + "</label>";
        }).join("")
      : '<div class="hint">No categories loaded yet.</div>';

    // Guidance under the dropdown depends on what was loaded.
    updateFilterNote(orgId);
  }

  // Guidance under the dropdown depends on what was loaded.
  function updateFilterNote(orgId) {
    var cats = filterCategories[orgId] || [];
    var note;
    if (!(orgId in filterCategories)) {
      note = "Loading this organization's calendar categories…";
    } else if (cats.length) {
      note =
        orgDisplayName(orgId) + "'s categories (the FILTER list). " +
        "Matching uses the event's category — its calendar color — not its title. " +
        "Nothing checked = no ⏰ buttons. Checking a category auto-detects its opening rule.";
    } else {
      note =
        "No categories loaded — open this organization's calendar, then click ↻ Refresh club setup. Stored selections still work.";
    }
    if (hiddenRestricted.length) {
      note += " 🔒 Hidden — restricted for you: " +
        hiddenRestricted.map(function (h) { return h.name + " (" + h.reason + ")"; }).join(", ") + ".";
    }
    filterNote.textContent = note;
  }

  // Runs in the calendar page's MAIN world. Must be fully self-contained.
  // Applies `sel.want` (extension category selections) to the CourtReserve
  // FILTER panel: checks exactly those categories, unchecks the rest,
  // then closes the drawer. An empty `want` array clears the filter
  // entirely (all events shown). `sel.all` is the org's full known category
  // list — the new-UI drawer's rows are custom React elements with no
  // input[type=checkbox], so exact name text is the only reliable row
  // identity there. Async (v1.5.29): a lazy-rendered panel is opened and
  // polled instead of failing immediately, and the result reports how many
  // names actually matched a panel row so the popup can tell "applied" from
  // "nothing matched" honestly.
  async function applyCalendarCategories(sel) {
    var names = (sel && sel.want) || [];
    var allNames = (sel && sel.all && sel.all.length) ? sel.all : names;
    try {
      var rows = document.querySelectorAll(".custom-checkbox.rowCheckbox");
      if (!rows.length && typeof openLeftNav === "function") {
        openLeftNav(); // lazy-rendered panel — open the drawer, then wait for it
        var deadline = Date.now() + 5000;
        while (!rows.length && Date.now() < deadline) {
          await new Promise(function (r) { setTimeout(r, 400); });
          rows = document.querySelectorAll(".custom-checkbox.rowCheckbox");
        }
      }
      if (!rows.length) {
        // NEW React "Filter Events" drawer. Rows are custom React elements —
        // NOT input[type=checkbox] — so rows are identified by exact
        // category-name text. CRITICAL SCOPING (Sep 24, PZB org 2151): event
        // TITLES on the calendar can equal category names ("Lesson with
        // Raegan" is both); an unscoped document-wide match clicked event
        // cells and navigated to the event Details page instead of
        // filtering. Filter rows = exact-name elements NOT inside the
        // calendar grid containers.
        var sleep2 = function (ms) { return new Promise(function (r) { setTimeout(r, ms); }); };
        var textOf = function (el) { return (el && el.textContent || "").replace(/\s+/g, " ").trim(); };
        var CAL_SCOPE = '[data-testid*="events-calendar-page"], [data-testid*="calendar-page-inner"], .k-scheduler, [role="grid"], table';
        var inCalendar = function (el) { return !!(el.closest && el.closest(CAL_SCOPE)); };
        // Ensure the drawer is OPEN (the FILTER button toggles it — never
        // click blindly): a missing OR hidden categories header means the
        // drawer is closed.
        var hdr = document.querySelector('[data-testid*="filter-categories-header"]');
        if (!hdr || hdr.offsetParent === null) {
          var fbtn = null;
          var bc = document.querySelectorAll('button, a, [role="button"]');
          for (var f = 0; f < bc.length; f++) {
            var ft = (bc[f].textContent || "").trim();
            if (/^filters?$/i.test(ft) && bc[f].offsetParent !== null) { fbtn = bc[f]; break; }
          }
          if (fbtn) {
            fbtn.click();
            var d0 = Date.now() + 4000;
            while (Date.now() < d0) {
              hdr = document.querySelector('[data-testid*="filter-categories-header"]');
              if (hdr && hdr.offsetParent !== null) break;
              await sleep2(300);
            }
          }
        }
        if (!hdr || hdr.offsetParent === null) return { ok: false, error: "FILTER panel not found on this page." };
        // Deepest visible element whose whole text is exactly a known
        // category name = that category's name element.
        var findNameEls = function () {
          var map = {};
          var els = document.querySelectorAll("div, span, label, li, p, a");
          for (var i = 0; i < els.length; i++) {
            if (els[i].offsetParent === null) continue;
            var t = textOf(els[i]);
            if (allNames.indexOf(t) < 0) continue;
            if (inCalendar(els[i])) continue;
            if (!map[t] || map[t].contains(els[i])) map[t] = els[i];
          }
          return map;
        };
        // Expand the Categories dropdown ONLY when no rows are showing —
        // the header click toggles, so clicking an already-expanded
        // dropdown would collapse it.
        var map = findNameEls();
        if (Object.keys(map).length < 2) {
          hdr.click();
          var d2 = Date.now() + 5000;
          while (Date.now() < d2 && Object.keys(map).length < 2) {
            await sleep2(400);
            map = findNameEls();
          }
        }
        // Cascading reveal: "Show all (N)" — click while the matched-name
        // count keeps growing.
        for (var round = 0; round < 5; round++) {
          var reveal = null;
          var cands = document.querySelectorAll("button, a, span, div, p");
          for (var i2 = 0; i2 < cands.length; i2++) {
            if (/^show\s+all\s*\(\s*\d+\s*\)\s*$/i.test((cands[i2].textContent || "").trim()) &&
                cands[i2].offsetParent !== null && !inCalendar(cands[i2])) { reveal = cands[i2]; break; }
          }
          if (!reveal) break;
          var before = Object.keys(map).length;
          reveal.click();
          await sleep2(900);
          map = findNameEls();
          if (Object.keys(map).length <= before) break;
        }
        map = findNameEls();
        var found = Object.keys(map);
        if (!found.length) return { ok: false, error: "The Categories dropdown held no category rows." };
        // The row wrapper = the outermost ancestor whose text is still
        // exactly the category name (the checkbox square carries no text).
        var rowOf = function (nameEl) {
          var el = nameEl, nm = textOf(nameEl);
          while (el.parentElement && textOf(el.parentElement) === nm) el = el.parentElement;
          return el;
        };
        // Checked state: real input, aria-checked, then a checked-ish class
        // on the row or its children (absence = unchecked). known=false
        // when no signal exists.
        var stateOf = function (row) {
          var inp = row.querySelector('input[type="checkbox"]');
          if (inp) return { known: true, checked: !!inp.checked };
          var aria = (row.matches && row.matches('[aria-checked]')) ? row : row.querySelector('[aria-checked]');
          if (aria) return { known: true, checked: aria.getAttribute('aria-checked') === 'true' };
          var pool = [row];
          for (var c2 = 0; c2 < row.children.length; c2++) pool.push(row.children[c2]);
          for (var p2 = 0; p2 < pool.length; p2++) {
            if (/checked|selected|is-active/i.test(String(pool[p2].className || ""))) return { known: true, checked: true };
          }
          return { known: false, checked: false };
        };
        var clickRow = function (row) {
          var t = row.querySelector('input[type="checkbox"], [role="checkbox"]') || row;
          t.click();
        };
        var changed = 0, matched = 0;
        var sample = stateOf(rowOf(map[found[0]]));
        if (sample.known) {
          // Per-row mode: toggle exactly the mismatches.
          for (var m2 = 0; m2 < found.length; m2++) {
            var nm2 = found[m2];
            var row2 = rowOf(map[nm2]);
            var want2 = names.indexOf(nm2) >= 0;
            if (want2) matched++;
            var st = stateOf(row2);
            if (!st.known && want2) { clickRow(row2); changed++; } // assume unchecked
            else if (st.known && st.checked !== want2) { clickRow(row2); changed++; }
          }
        } else {
          // Clear mode: row state is unreadable, so hit the drawer's Clear
          // (the staged selection empties), then click exactly the wanted
          // rows. Clear/Apply are searched walking up from the header.
          var clearBtn = null, scope0 = hdr;
          for (var up0 = 0; up0 < 6 && scope0 && !clearBtn; up0++) {
            var bs0 = scope0.querySelectorAll("button");
            for (var b0 = 0; b0 < bs0.length; b0++) {
              if ((bs0[b0].textContent || "").trim() === "Clear" && bs0[b0].offsetParent !== null) { clearBtn = bs0[b0]; break; }
            }
            scope0 = scope0.parentElement;
          }
          if (clearBtn) { clearBtn.click(); await sleep2(400); }
          for (var m3 = 0; m3 < names.length; m3++) {
            if (!map[names[m3]]) continue;
            matched++;
            clickRow(rowOf(map[names[m3]]));
            changed++;
            await sleep2(120); // let React stage each toggle
          }
        }
        // Find the drawer's Apply button (walk up from the dropdown until a
        // container holds a visible exact-"Apply" button) and click it.
        var applyBtn = null, scope = hdr;
        for (var up = 0; up < 6 && scope && !applyBtn; up++) {
          var bs = scope.querySelectorAll("button");
          for (var b = 0; b < bs.length; b++) {
            if ((bs[b].textContent || "").trim() === "Apply" && bs[b].offsetParent !== null) { applyBtn = bs[b]; break; }
          }
          scope = scope.parentElement;
        }
        await sleep2(300); // let React enable the button after the toggles
        if (applyBtn) applyBtn.click();
        return { ok: true, changed: changed, matched: matched };
      }
      var changed = 0, matched = 0;
      for (var i = 0; i < rows.length; i++) {
        var label = rows[i].querySelector("label.k-checkbox-label");
        var box = rows[i].querySelector("input.category-chk");
        if (!label || !box) continue;
        var want = names.indexOf(label.innerText.trim()) >= 0;
        if (want) matched++;
        if (box.checked !== want) { box.click(); changed++; }
      }
      // Checkbox changes apply to the calendar immediately (verified) — no
      // Filter-button click needed. Close the drawer so the user sees the
      // filtered calendar right away.
      var nav = document.querySelector(".left-filter-nav");
      var closeBtn = nav ? nav.querySelector(".closebtn") : null;
      if (closeBtn) closeBtn.click();
      return { ok: true, changed: changed, matched: matched };
    } catch (e) {
      return { ok: false, error: String(e) };
    }
  }

  /** Apply the Settings category picks to the CourtReserve FILTER panel. */
  function applyCategoriesToCalendar(orgId) {
    var names = readFilterSelection().categories.map(function (c) { return c.name; });
    // The new-UI drawer identifies rows by exact name text, so send the
    // org's full known list as the row dictionary, not just the selection.
    var all = (filterCategories[orgId] || []).map(function (c) { return c.name; });
    var sel = { want: names, all: all.length ? all : names };
    var note = document.getElementById("applyFilterNote");
    var defaultNote = "Checks the same categories in CourtReserve's FILTER panel — one click instead of re-picking them there.";
    function flash(msg) {
      note.textContent = msg;
      setTimeout(function () { note.textContent = defaultNote; }, 4000);
    }
    function applyTo(tabId) {
      return chrome.scripting
        .executeScript({ target: { tabId: tabId }, world: "MAIN", func: applyCalendarCategories, args: [sel] })
        .then(function (res) {
          var r = res && res[0] && res[0].result;
          if (r && r.ok) {
            if (names.length && !r.matched) {
              flash("None of your selected categories were found in this club's FILTER panel — refresh categories and try again.");
              CRLib.log("warn", "Apply categories", "None of the selected categories were found in this club's FILTER panel.", "Not found");
            } else if (names.length && !r.changed) {
              flash("Already applied ✓ — the calendar FILTER matches your selection.");
              CRLib.log("ok", "Apply categories", "The calendar FILTER already matched the selection.", "No change");
            } else {
              flash(names.length
                ? "Applied " + names.length + " categor" + (names.length === 1 ? "y" : "ies") + " to the calendar FILTER ✓"
                : "Cleared the calendar FILTER — all events shown ✓");
              CRLib.log("ok", "Apply categories",
                names.length ? names.join(", ") : "Cleared — all events shown.", "Applied");
            }
          } else {
            flash("Couldn't apply: " + ((r && r.error) || "no response from the calendar tab."));
            CRLib.log("fail", "Apply categories", (r && r.error) || "No response from the calendar tab.", "Failed");
          }
        })
        .catch(function (e) {
          flash("Couldn't apply: " + e);
          CRLib.log("fail", "Apply categories", String(e), "Failed");
        });
    }
    flash("Applying to the calendar FILTER…");
    // Target the tab the user is actually looking at first (the same
    // current-window rule as the org sync, v1.5.28) — a stale automation
    // calendar tab in another window must never receive the filter instead.
    // v1.6.0: the cross-window fallback also skips quarantine-window tabs,
    // and a tab this flow opens itself is closed after the apply.
    var calMatch = "https://app.courtreserve.com/Online/Calendar/Events/" + orgId + "/*";
    return chrome.tabs
      .query({ url: calMatch, active: true, currentWindow: true })
      .then(function (act) {
        if (act && act.length) return applyTo(act[0].id);
        return Promise.all([
          chrome.storage.local.get("crAutomationWindowId"),
          chrome.tabs.query({ url: calMatch }),
        ]).then(function (r) {
          var qw = r[0] && r[0].crAutomationWindowId;
          var tabs = (r[1] || []).filter(function (t) { return t.windowId !== qw; });
          sortTabsByRecency(tabs);
          if (tabs.length) return applyTo(tabs[0].id);
          return chrome.tabs
            .create({ url: "https://app.courtreserve.com/Online/Calendar/Events/" + orgId + "/Month", active: false })
            .then(function (tab) {
              return waitForTabComplete(tab.id).then(function () {
                return new Promise(function (r2) { setTimeout(r2, 1500); })
                  .then(function () { return applyTo(tab.id); })
                  .then(function () { chrome.tabs.remove(tab.id, function () { void chrome.runtime.lastError; }); });
              });
            });
        });
      })
      .catch(function (e) { flash("Couldn't apply: " + e); });
  }

  // The category list is fixed-height (4 rows) and scrollable — every
  // category always shows, checked or not.
  filterReload.addEventListener("click", function (ev) {
    ev.stopPropagation();
    // v1.6.0: this button now runs the FOREGROUND club-setup pass — profile +
    // categories in a CourtReserve tab the user watches, narrated by an
    // on-page overlay (hidden background reads of these pages were the
    // focus-stealing failure mode). This popup usually closes as the tab
    // takes focus; results land in storage and on the Log tab.
    if (!settingsOrgId) {
      filterNote.textContent = "Open your club's CourtReserve calendar first, then refresh.";
      return;
    }
    filterNote.textContent = "Refreshing club setup — watch the CourtReserve tab; it walks through the steps.";
    chrome.runtime.sendMessage({ type: "clubSetup", orgId: settingsOrgId }, function (resp) {
      void chrome.runtime.lastError; // popup may close as the tab takes focus — fine
      chrome.storage.local.get(["orgCategories"]).then(function (data) {
        var cats = (data && data.orgCategories || {})[settingsOrgId];
        if (cats && cats.length) {
          filterCategories[settingsOrgId] = cats;
          fillFields();
        } else if (resp && resp.ok) {
          filterNote.textContent =
            "No categories found on this organization's calendar page — let it finish loading (log in if asked), then refresh again. Details are on the Log tab.";
        } else if (resp && resp.error) {
          filterNote.textContent = "Refresh failed: " + resp.error + " — details are on the Log tab.";
        }
      });
    });
  });

  document.getElementById("optApplyFilter").addEventListener("click", function () {
    CRLib.log("run", "Apply categories", "Pushing the selected categories to the open calendar tab.", "Started");
    applyCategoriesToCalendar(settingsOrgId);
  });

  // Same action, second home: the duplicate link inside Settings → Options.
  document.getElementById("optApplyFilter2").addEventListener("click", function () {
    CRLib.log("run", "Apply categories", "Pushing the selected categories to the open calendar tab.", "Started");
    applyCategoriesToCalendar(settingsOrgId);
  });

  /** Read the checked filter rows as settings fields. */
  function readFilterSelection() {
    var checked = setFilterList.querySelectorAll("input[type=checkbox]:checked");
    var cats = [];
    var custom = "";
    for (var i = 0; i < checked.length; i++) {
      var kind = checked[i].getAttribute("data-kind");
      if (kind === "text") custom = checked[i].getAttribute("data-name") || "";
      else cats.push({ name: checked[i].getAttribute("data-name") || "", color: checked[i].getAttribute("data-color") || "" });
    }
    return { categories: cats, customText: custom };
  }

  /**
   * Build a full settings object: start from the last saved state and apply
   * the window's field values, org-scoped when the Settings window edits a
   * specific org.
   */
  function buildSettings(daysBefore, openTime, sel, fireDelaySeconds) {
    var s = {
      daysBefore: fullSettings.daysBefore,
      openTime: fullSettings.openTime,
      eventFilter: fullSettings.eventFilter,
      eventFilterMode: fullSettings.eventFilterMode,
      eventFilterColor: fullSettings.eventFilterColor,
      eventFilterCategories: fullSettings.eventFilterCategories,
      perOrg: fullSettings.perOrg || {},
      fireDelaySeconds: fullSettings.fireDelaySeconds,
      showAutoRegButtons: fullSettings.showAutoRegButtons,
      showOpensIndicator: fullSettings.showOpensIndicator,
    };
    var orgId = settingsOrgId;
    if (orgId) {
      var perOrg = {};
      Object.keys(s.perOrg).forEach(function (k) { perOrg[k] = s.perOrg[k]; });
      // Spread the existing override: per-category window rules
      // (categoryWindows, set by Auto Fill) must survive a save here.
      var existing = perOrg[orgId] || {};
      perOrg[orgId] = { ...existing, daysBefore: daysBefore, openTime: openTime, eventFilter: sel.customText, eventFilterMode: "text", eventFilterColor: "", eventFilterCategories: sel.categories, fireDelaySeconds: fireDelaySeconds };
      s.perOrg = perOrg;
    } else {
      s.daysBefore = daysBefore;
      s.openTime = openTime;
      s.eventFilter = sel.customText;
      s.eventFilterMode = "text";
      s.eventFilterColor = "";
      s.eventFilterCategories = sel.categories;
      s.fireDelaySeconds = fireDelaySeconds;
    }
    return s;
  }

  function loadSettingsPane() {
    return Promise.all([CRLib.settings.load(), CRLib.orgs.list(), CRLib.store.list(), detectBrowserTabs(), chrome.storage.local.get(["uiTopOrg", "orgCategories", "initState", "lruOrg"])]).then(function (r) {
      fullSettings = r[0];
      knownOrgs = r[1];
      var tabs = r[3]; // { count, anyOrg, calendarOrg }
      var browserOrg = tabs.anyOrg;
      var saved = r[4] || {};

      // First run = setup has never COMPLETED successfully. (Not "no orgs
      // learned": the calendar content script learns orgs from the "My
      // Clubs" menu within seconds of the page loading, which defeated the
      // old heuristic and skipped setup entirely.) initState is the durable
      // record — the init pane owns the popup until the chain finishes once.
      var init = saved.initState;
      var setupDone = init && init.stage === "done" && init.ok;
      // A dismissed failure behaves as non-first-run for this popup session:
      // the normal tabs load, org sync runs, and the pane stays hidden.
      var firstRun = !setupDone && !initFailDismissed;
      if (firstRun) {
        if (init && init.running && Date.now() - (init.at || 0) < 6 * 60 * 1000) {
          // Chain already going (popup reopened mid-run) — just watch.
          showInitPane("working");
          initStep.textContent = INIT_STAGES[init.stage] || "Working…";
          return;
        }
        if (init && init.stage === "done" && !init.ok) {
          // Last attempt failed — show the reason; Continue lets the user
          // through (the Setup tab can retry). No silent auto-retry loop.
          showInitPane("done");
          renderInitProgress(init);
          return;
        }
        if (!browserOrg) {
          // No CourtReserve tab anywhere — ask the user to open one.
          showInitPane("need-site");
          return;
        }
        if (!initAutoStarted) {
          // CourtReserve is up — run the initializer once, then keep loading.
          initAutoStarted = true;
          showInitPane("working");
          initStep.textContent = INIT_STAGES["find-org"];
          chrome.runtime.sendMessage({ type: "initStart" }, function () {});
        }
      }

      // Seed the in-memory category cache with the persisted per-org lists.
      var storedCats = saved.orgCategories || {};
      Object.keys(storedCats).forEach(function (id) { filterCategories[id] = storedCats[id]; });
      if (browserOrg) {
        // Persist it so the dropdown shows a name once one is learned, and
        // preselect it — the popup opens on the org being viewed.
        CRLib.orgs.learn([{ id: browserOrg, name: "" }]);
        if (!knownOrgs.some(function (o) { return o.id === browserOrg; })) {
          knownOrgs.push({ id: browserOrg, name: "", primary: false });
        }
      }

      // --- Open-on organization sync --------------------------------------
      // A CourtReserve CALENDAR page open anywhere wins over the persisted
      // dropdown pick: the popup switches to that org exactly as if the user
      // picked it in the top dropdown (persisted selection, retargeted
      // Settings fields, fresh categories) — except the browser is NOT
      // navigated, since the user is already on that org's calendar — and
      // the org becomes the LRU (least recently used) organization.
      var syncedOrg = "";
      if (!firstRun && tabs.calendarOrg) {
        syncedOrg = tabs.calendarOrg;
        chrome.storage.local.set({ uiTopOrg: syncedOrg, lruOrg: { id: syncedOrg, at: Date.now() } });
      }
      // No CourtReserve page open at all → open the LRU org's calendar page
      // (falling back to the persisted pick, then the Primary/first learned
      // org). The background owns the tab: if CourtReserve detours to its
      // sign-in page, the user lands on the calendar after signing in, and
      // the org's categories are loaded there. The new active tab closes
      // this popup — syncing the selection first covers the brief overlap.
      if (!firstRun && tabs.count === 0 && !openAutoFired) {
        var lru = saved.lruOrg && /^\d+$/.test(String(saved.lruOrg.id || "")) ? String(saved.lruOrg.id) : "";
        var primary = knownOrgs.filter(function (o) { return o.primary; })[0] || knownOrgs[0];
        var fallback = (saved.uiTopOrg && /^\d+$/.test(String(saved.uiTopOrg)) && String(saved.uiTopOrg)) ||
          (primary && /^\d+$/.test(String(primary.id)) ? String(primary.id) : "");
        var openOrg = lru || fallback;
        if (openOrg) {
          openAutoFired = true;
          chrome.runtime.sendMessage({ type: "openOrgCalendar", orgId: openOrg }, function () {});
          syncedOrg = openOrg; // background persists lruOrg; keep the UI in step
          chrome.storage.local.set({ uiTopOrg: openOrg });
        }
      }

      // Top dropdown: a synced org wins; otherwise a persisted pick (even
      // "All"); otherwise default to the org being viewed, matching the old
      // limit-to-current-org default.
      var ids = collectOrgIds(r[2], (syncedOrg || browserOrg) || undefined);
      var hasSaved = Object.prototype.hasOwnProperty.call(saved, "uiTopOrg");
      var topSel = syncedOrg ||
        (hasSaved
          ? (saved.uiTopOrg && ids.indexOf(saved.uiTopOrg) !== -1 ? saved.uiTopOrg : "")
          : (browserOrg || ""));
      renderTopOrgSelect(r[2], topSel);
      setSettingsOrg(topSel || browserOrg, r[2]);
      fillFields();
      renderProfileLine();
      // Learn the player's Gender + rating(s) for this org in the background
      // when none is stored yet — drives eligibility filtering (throttled).
      if (settingsOrgId) {
        CRLib.profiles.get(settingsOrgId).then(function (p) {
          if (!p) chrome.runtime.sendMessage({ type: "ensureProfile", orgId: settingsOrgId }, function () {});
        });
      }
      // Stored categories show instantly; fetch only when this org has none
      // (retry once after a sync — the same setup the dropdown switch does).
      ensureCategories(settingsOrgId, syncedOrg ? { retry: true } : undefined);
      // The popup opened on (or synced to) an org — investigate any selected
      // category still missing a detected rule (guards keep this cheap).
      scheduleRuleCheck();
      render(); // apply the org filter to the Scheduled list
    });
  }

  // The top Organization dropdown is the only org switcher — shared by both
  // panels: it filters the Scheduled list, retargets the Settings fields,
  // and drives the browser to that org's calendar so everything stays in sync.
  topOrg.addEventListener("change", function () {
    chrome.storage.local.set({ uiTopOrg: topOrg.value });
    // An explicit switch makes the org the LRU ("All organizations" doesn't).
    if (topOrg.value) chrome.storage.local.set({ lruOrg: { id: topOrg.value, at: Date.now() } });
    if (topOrg.value && settingsOrgId !== topOrg.value) {
      setSettingsOrg(topOrg.value);
      fillFields();
      renderProfileLine();
      // Org switched — fetch the player's profile for it if never learned.
      CRLib.profiles.get(topOrg.value).then(function (p) {
        if (!p) chrome.runtime.sendMessage({ type: "ensureProfile", orgId: topOrg.value }, function () {});
      });
      // Categories differ per org — stored lists show instantly; otherwise
      // fetch, retrying once while the navigation below loads the tab.
      ensureCategories(topOrg.value, { retry: true });
      // Org switched — investigate any selected category missing a rule.
      scheduleRuleCheck();
      // Navigate the browser to this org's calendar — via the background,
      // whose landing watcher reroutes any CourtReserve portal bounce. (A
      // raw tab update could strand the tab on a non-calendar page, and the
      // next popup open would then fall back to stale state — part of the
      // "selection doesn't stick" bug fixed in v1.5.28.)
      chrome.runtime.sendMessage({ type: "openOrgCalendar", orgId: topOrg.value }, function () {});
    }
    render();
  });

  // Calendar display options are global and take effect immediately — no
  // Save needed; the calendar re-renders on the settings change.
  // Calendar display options are global and take effect immediately — no
  // Save needed; the calendar re-renders on the settings change. Only the
  // checkbox that actually changed becomes an explicit choice — the other
  // keeps its raw value (null = trial-aware default for the buttons toggle).
  function saveDisplayPrefs(changed) {
    if (!fullSettings) return;
    var s = {
      daysBefore: fullSettings.daysBefore,
      openTime: fullSettings.openTime,
      eventFilter: fullSettings.eventFilter,
      eventFilterMode: fullSettings.eventFilterMode,
      eventFilterColor: fullSettings.eventFilterColor,
      eventFilterCategories: fullSettings.eventFilterCategories,
      perOrg: fullSettings.perOrg || {},
      fireDelaySeconds: fullSettings.fireDelaySeconds,
      showAutoRegButtons: changed === "autoreg" ? optAutoRegButtons.checked : fullSettings.showAutoRegButtons,
      showOpensIndicator: changed === "opens" ? optOpensIndicator.checked : fullSettings.showOpensIndicator,
    };
    CRLib.settings.save(s).then(function () {
      fullSettings = s;
      optsNote.textContent = "Saved ✓";
      setTimeout(function () { optsNote.textContent = "Apply to all organizations, effective immediately."; }, 1500);
      CRLib.log("ok", "Calendar options",
        changed === "autoreg"
          ? "Auto-Register buttons " + (optAutoRegButtons.checked ? "shown" : "hidden") + " on the calendar."
          : "Bold open-date indicator " + (optOpensIndicator.checked ? "on" : "off") + ".",
        "Saved");
    });
  }
  optAutoRegButtons.addEventListener("change", function () { saveDisplayPrefs("autoreg"); });
  optOpensIndicator.addEventListener("change", function () { saveDisplayPrefs("opens"); });

  /** One-line summary of the learned My Profile data for the org being
      viewed — the yardstick used for Rating/Gender eligibility filtering. */
  function renderProfileLine() {
    if (!profileLine) return;
    if (!settingsOrgId) { profileLine.textContent = ""; return; }
    CRLib.profiles.get(settingsOrgId).then(function (p) {
      if (!settingsOrgId) { profileLine.textContent = ""; return; }
      if (p && (p.gender || (p.ratings || []).length)) {
        profileLine.innerHTML =
          "Gender: <b>" + esc(p.gender || "—") + "</b> and Rating: <b>" +
          esc((p.ratings || []).join(", ") || "—") + "</b>";
      } else {
        profileLine.textContent = "Gender/Rating: not learned yet — open My Profile on CourtReserve once.";
      }
    });
  }

  // --- Auto-investigate window rules -----------------------------------------
  // Hover information must be ACCURATE, never estimated: selecting a category
  // that has no detected rule automatically kicks off an Auto Fill run for
  // this org (which walks every selected category still missing a rule).
  // Debounced: several quick picks fold into ONE run a few seconds after the
  // last click, so selecting categories never storms the browser with tabs.
  var ruleCheckTimer = null;
  function scheduleRuleCheck() {
    if (!settingsOrgId) return;
    clearTimeout(ruleCheckTimer);
    ruleCheckTimer = setTimeout(function () {
      if (!fullSettings) return;
      var eff = CRLib.settings.mergeOrg(fullSettings, settingsOrgId);
      var wins = eff.categoryWindows || {};
      var noCd = eff.noCountdownCategories || [];
      var missing = (eff.eventFilterCategories || []).some(function (c) {
        return !wins[c.name] && noCd.indexOf(c.name) === -1;
      });
      if (!missing) return; // every selected category already has a real rule
      chrome.storage.local.get(["pendingAutofill", "autofillResult"]).then(function (d) {
        if (d.pendingAutofill) return; // a run is already in flight
        // A run that just failed (e.g. no not-yet-open events to read) isn't
        // retried immediately — the next selection change can trigger it.
        if (d.autofillResult && d.autofillResult.ok === false &&
            Date.now() - (d.autofillResult.at || 0) < 2 * 60 * 1000) return;
        autofillNote.textContent = "Detecting… a calendar tab opens in the background (takes a few seconds).";
        chrome.runtime.sendMessage({ type: "autofillStart", orgId: settingsOrgId }, function () {});
      });
    }, 6000);
  }

  // Category picks take effect immediately — no "Save settings" click needed.
  // Days/time/delay are not touched here: the effective (last saved) values
  // are re-applied as-is.
  setFilterList.addEventListener("change", function () {
    if (!fullSettings) return;
    var sel = readFilterSelection();
    var eff = CRLib.settings.mergeOrg(fullSettings, settingsOrgId);
    var s = buildSettings(eff.daysBefore, eff.openTime, sel, eff.fireDelaySeconds);
    CRLib.settings.save(s).then(function () {
      fullSettings = s;
      filterNote.textContent = "Saved ✓";
      setTimeout(function () { updateFilterNote(settingsOrgId); }, 1500);
      var names = sel.categories.map(function (c) { return c.name; });
      CRLib.log("ok", "Set categories",
        names.length ? names.join(", ") : "None selected — no ⏰ buttons.", "Saved");
      scheduleRuleCheck(); // new picks without a detected rule get investigated
    });
  });

  // Auto-save the fire delay (seconds dropdown) when it changes.
  // Days/opening-time are not user-editable — detection sets them per
  // category; the stored org-level values stay as the silent fallback.
  var FIRE_DELAY_CHOICES = [0, 15, 30, 45, 60, 90, 120, 180];
  function autoSaveSettings() {
    if (!fullSettings) return;
    var fireDelaySeconds = parseInt(setDelaySecs.value, 10);
    if (FIRE_DELAY_CHOICES.indexOf(fireDelaySeconds) === -1) fireDelaySeconds = 15;
    setDelaySecs.value = String(fireDelaySeconds);

    var sel = readFilterSelection();
    var eff = CRLib.settings.mergeOrg(fullSettings, settingsOrgId);
    var s = buildSettings(eff.daysBefore, eff.openTime, sel, fireDelaySeconds);
    CRLib.settings.save(s).then(function () {
      fullSettings = s;
      CRLib.log("ok", "Set fire timing",
        fireDelaySeconds === 0
          ? "Fires the moment registration opens."
          : "Fires " + fireDelaySeconds + " seconds after registration opens.", "Saved");
      // Re-time every scheduled entry to the new delay and re-arm alarms.
      chrome.runtime.sendMessage({ type: "fireTimingChanged" }, function () { void chrome.runtime.lastError; });
    });
  }
  setDelaySecs.addEventListener("change", autoSaveSettings);

  // --- Auto Fill --------------------------------------------------------------
  function showAutofillResult(r) {
    autofillNote.innerHTML =
      '<span style="color:' + (r.ok ? "#15803d" : "#b91c1c") + ';">' +
      (r.ok ? "✓ " : "✗ ") + esc(r.message) + "</span>";
  }

  autofillBtn.addEventListener("click", function () {
    autofillBtn.disabled = true;
    autofillNote.textContent = "Detecting… a calendar tab opens in the background (takes a few seconds).";
    // A manual click is an explicit retry: forget any "no countdown" verdicts
    // remembered for this org so those categories are investigated again.
    var start = function () {
      // Targeted run: only the SELECTED categories still missing a rule get
      // investigated (eligibility is read opportunistically on those same
      // visits — no full category sweep, v1.5.24).
      chrome.runtime.sendMessage({ type: "autofillStart", orgId: settingsOrgId }, function () {
        setTimeout(function () { autofillBtn.disabled = false; }, 3000);
      });
    };
    var ex = (fullSettings && fullSettings.perOrg && fullSettings.perOrg[settingsOrgId]) || {};
    if (settingsOrgId && (ex.noCountdownCategories || []).length) {
      var perOrg = {};
      Object.keys(fullSettings.perOrg).forEach(function (k) { perOrg[k] = fullSettings.perOrg[k]; });
      var cleared = {};
      Object.keys(ex).forEach(function (k) { if (k !== "noCountdownCategories") cleared[k] = ex[k]; });
      perOrg[settingsOrgId] = cleared;
      var sel = readFilterSelection();
      var s = buildSettings(ex.daysBefore !== undefined ? ex.daysBefore : fullSettings.daysBefore,
        ex.openTime !== undefined ? ex.openTime : fullSettings.openTime, sel,
        ex.fireDelaySeconds !== undefined ? ex.fireDelaySeconds : fullSettings.fireDelaySeconds);
      s.perOrg = perOrg;
      CRLib.settings.save(s).then(function () { fullSettings = s; start(); });
    } else {
      start();
    }
  });

  function loadAutofillState() {
    chrome.storage.local.get(["pendingAutofill", "autofillResult"]).then(function (data) {
      updateDetectBanner(data.pendingAutofill || null);
      if (data.pendingAutofill) {
        autofillNote.textContent = "Detecting… a calendar tab opens in the background (takes a few seconds).";
      } else if (data.autofillResult && Date.now() - data.autofillResult.at < 30 * 60 * 1000) {
        showAutofillResult(data.autofillResult);
      }
    });
  }

  /** Top-of-popup progress while an Auto Fill run works in the background —
      visible from every pane so the pause never reads as buggy. */
  function updateDetectBanner(pa) {
    if (!pa) {
      detectBanner.style.display = "none";
      return;
    }
    var done = (pa.saves || []).length;
    var club = orgDisplayName(pa.orgId || "");
    detectBanner.textContent = "⏳ Detecting registration rules for " + club +
      " — a background tab reads each selected category's countdown." +
      (done ? " " + done + " done so far…" : "");
    detectBanner.style.display = "block";
  }

  chrome.storage.onChanged.addListener(function (changes, area) {
    if (area === "local" && changes.entries) render();
    if (area === "local" && changes.settings) loadSettingsPane();
    if (area === "local" && changes.orgs) loadSettingsPane(); // org names learned
    if (area === "local" && changes.profiles) renderProfileLine(); // My Profile learned
    if (area === "local" && changes.autofillResult && changes.autofillResult.newValue) {
      showAutofillResult(changes.autofillResult.newValue);
      loadSettingsPane(); // fields refresh with the detected rule
    }
    if (area === "local" && changes.pendingAutofill) {
      loadAutofillState();
      if (initPaneVisible()) {
        updateInitInspect(changes.pendingAutofill.newValue || null);
      }
    }
    if (area === "local" && changes.initState) renderInitProgress(changes.initState.newValue);
    if (area === "local" && changes.orgCategories) loadSettingsPane(); // init loaded categories
    if (area === "local" && changes.license) renderPremium();
    if (area === "local" && changes.activityLog && tabLog.classList.contains("active")) renderLog();
  });

  render();
  renderPremium();
  loadSettingsPane();
  loadAutofillState();
})();
