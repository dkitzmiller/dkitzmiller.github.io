/**
 * Content script: the post-purchase success page (dkitzmiller.github.io).
 *
 * The success page is static, so its "Open the CourtReserve calendar →"
 * button can only carry a FIXED org id (2319) as transport — and the
 * #crh-activate=<key> hash can be lost when that fixed-org page bounces
 * through a redirect (e.g. a club the buyer isn't a member of), killing both
 * the activation card and the calendar-side reroute. So this script:
 *
 *  1. Rewrites the button's href to the buyer's own club — the org of an
 *     open CourtReserve calendar tab, else the LRU org, else the Primary /
 *     first learned org (background 'calendarTarget') — preserving the hash.
 *     Covers middle-click / open-in-new-tab and acts as the fallback.
 *  2. Intercepts the plain click ('focusOrgCalendar') so the user lands on
 *     their EXISTING CourtReserve tab — focused and reloaded — instead of
 *     stacking another calendar tab.
 *
 * With no known org the default link is left untouched (the calendar-side
 * reroute remains as the fallback net).
 */
(function () {
  "use strict";

  var btn = document.getElementById("backBtn");
  if (!btn) return;

  var hash = "";
  try {
    hash = new URL(btn.href).hash || "";
  } catch (e) {
    return;
  }
  if (!/^#crh-activate/.test(hash)) return; // not an activation link — leave it

  var targetOrg = ""; // resolved asynchronously; empty = keep default behavior

  try {
    chrome.runtime.sendMessage({ type: "calendarTarget" }, function (r) {
      if (chrome.runtime.lastError) return;
      if (!r || !r.ok || !/^\d+$/.test(String(r.orgId || ""))) return;
      targetOrg = String(r.orgId);
      btn.href =
        "https://app.courtreserve.com/Online/Calendar/Events/" + targetOrg + "/Month" + hash;
    });
  } catch (e) {
    /* extension context invalidated — keep the default link */
  }

  btn.addEventListener("click", function (ev) {
    if (!targetOrg) return; // unresolved — let the default navigation happen
    ev.preventDefault();
    try {
      chrome.runtime.sendMessage(
        { type: "focusOrgCalendar", orgId: targetOrg, hash: hash },
        function () { void chrome.runtime.lastError; }
      );
    } catch (e) {
      location.assign(btn.href); // extension context gone — navigate directly
    }
  });
})();
