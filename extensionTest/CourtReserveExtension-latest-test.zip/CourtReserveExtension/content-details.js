/* Court Helper for CourtReserve — details page execution engine.
   Runs when the background worker opens a details URL at fire time.
   Handles the full flow: register (incl. finalize), join waitlist,
   already-registered detection, one reload-and-recheck. */

(() => {
  // v1.7.33: re-injection guard — the background injects this script
  // programmatically when Chrome skips automatic injection in the automation
  // window's tabs (Oct 22-23, org 2151 stalls). One eval per frame.
  // v1.7.41: version-stamped marker — see content-calendar.js.
  const CRX_VER = chrome.runtime.getManifest().version;
  if (window.__crxDetailsLoaded === CRX_VER) return;
  window.__crxDetailsLoaded = CRX_VER;
  const MAX_TASK_AGE = 5 * 60 * 1000;
  // CourtReserve blocks ineligible players with a rating popup / message.
  const RATING_RE = /not (allowed|eligible)[\s\S]{0,80}?rating|rating[\s\S]{0,40}(requirement|restricted|not met)|do(es)? not meet[\s\S]{0,40}(rating|eligibility)/i;
  const ratingBlocked = (body) => RATING_RE.test(body);

  function detect(body) {
    if (/edit registration/i.test(body)) return 'registered';
    if (/unsubscribe from waitlist/i.test(body) || /#\d+\s*on waitlist/i.test(body) || /waitlisted on:/i.test(body)) return 'waitlisted';
    return null;
  }

  async function confirmDialog() {
    const c = CRLib.findButton([/^confirm$/i, /^ok$/i, /^yes$/i, /^submit$/i]);
    if (c) { c.el.click(); await CRLib.sleep(800); }
  }

  async function pollFor(fn, timeout) {
    try { return await CRLib.waitFor(fn, timeout, 700); } catch { return null; }
  }

  /**
   * Like CRLib.findButton but skips `excludeEl`. Needed for the waitlist
   * confirmation: CourtReserve labels the confirm button "Join Waitlist"
   * AGAIN, and when that confirmation is a modal, the ORIGINAL button stays
   * in the DOM — findButton returns only the first match, so merely
   * rejecting a match would return the same excluded button forever and the
   * poll would time out (v1.7.5 bug). Skipping it keeps the scan moving to
   * the real confirm button.
   */
  function findConfirmButton(patterns, excludeEl) {
    const els = document.querySelectorAll('button, a, [role="button"], input[type="submit"], input[type="button"]');
    for (const el of els) {
      if (el === excludeEl) continue;
      const t = (el.textContent || el.value || '').replace(/\s+/g, ' ').trim();
      if (!t || t.length > 60) continue;
      if (el.offsetParent === null && !/^(input)$/i.test(el.tagName)) continue;
      if (patterns.some((p) => p.test(t))) return { el, text: t };
    }
    return null;
  }

  /**
   * The "Registration opens in …" countdown element. Old UI: a dedicated
   * span[data-testid="dropin-msg"]. New UI (Sep 25, PZB org 2151): a plain
   * leaf <div class="acss-…"> with NO testid — the old selector found
   * nothing, the run branded the category "no countdown" and failed. Fall
   * back to the deepest VISIBLE element carrying the text (deepest = no
   * child also matches, so we return the leaf, not a page-section
   * container whose extra text would pollute the parse).
   */
  function findCountdownEl() {
    const el = document.querySelector('span[data-testid="dropin-msg"]');
    if (el && /registration opens in/i.test(el.textContent || '')) return el;
    const all = document.querySelectorAll('div, span, p');
    for (let i = 0; i < all.length; i++) {
      const node = all[i];
      if (node.offsetParent === null) continue;
      if (!/registration opens in/i.test(node.textContent || '')) continue;
      let deeper = false;
      const kids = node.children;
      for (let j = 0; j < kids.length; j++) {
        if (/registration opens in/i.test(kids[j].textContent || '')) { deeper = true; break; }
      }
      if (!deeper) return node;
    }
    return null;
  }

  /**
   * The event's date as the DETAILS PAGE itself states it — ground truth,
   * used to correct calendar-cell dates misread at month boundaries.
   * New UI header: "Fri, Nov 6th 2:30p - 5p" (no year — pick the year whose
   * date is closest to today). Old UI: a full "Tuesday, October 6, 2026".
   * Only the page head is searched, so series/related-event dates further
   * down can't win.
   */
  function readPageEventDate() {
    const head = ((document.body && document.body.innerText) || '')
      .replace(/\s+/g, ' ').slice(0, 800);    const long = /(Monday|Tuesday|Wednesday|Thursday|Friday|Saturday|Sunday),\s+(January|February|March|April|May|June|July|August|September|October|November|December)\s+\d{1,2},\s+\d{4}/i.exec(head);
    if (long) return CRLib.parseLongDate(long[0]);
    const short = /(?:mon|tue|wed|thu|fri|sat|sun)[a-z]*,\s+(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\s+(\d{1,2})(?:st|nd|rd|th)?\b/i.exec(head);
    if (!short) return null;
    const month = ['jan','feb','mar','apr','may','jun','jul','aug','sep','oct','nov','dec']
      .indexOf(short[1].slice(0, 3).toLowerCase());
    const day = Number(short[2]);
    const now = new Date();
    let best = null;
    for (let y = now.getFullYear() - 1; y <= now.getFullYear() + 1; y++) {
      const d = new Date(y, month, day);
      if (!best || Math.abs(d - now) < Math.abs(best - now)) best = d;
    }
    return best;
  }

  /**
   * The event's START time as the DETAILS PAGE header states it — ground
   * truth for openAtEventStart rule derivation, independent of the calendar
   * cell's label (which can lose its time part on some calendar layouts).
   * Header forms: "Fri, Nov 6th 2:30p - 5p", "Friday, November 6, 2026
   * 10:00 AM - 12:00 PM". Returns minutes since midnight, or null.
   * Only the page head is searched; a time must be followed by a range
   * separator (- / – / to) so bare date numbers can't match.
   */
  function readPageStartMinutes() {
    const head = ((document.body && document.body.innerText) || '')
      .replace(/\s+/g, ' ').slice(0, 800);
    const m = /(\d{1,2})(?::(\d{2}))?\s*([ap])\.?m?\.?\s*(?:-|–|to)\s*\d{1,2}/i.exec(head);
    if (!m) return null;
    let h = Number(m[1]);
    const min = m[2] ? Number(m[2]) : 0;
    if (h < 1 || h > 12 || min > 59) return null;
    if (h === 12) h = 0;
    return (m[3].toLowerCase() === 'p' ? h + 12 : h) * 60 + min;
  }

  /** Minutes since midnight → "10:00 AM" (for derivation log lines). */
  function fmtMinOfDay(min) {
    return new Date(2000, 0, 1, Math.floor(min / 60), min % 60)
      .toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' });
  }

  /**
   * Read the event's Rating Restriction block (v1.5.18; rating-only since
   * v1.5.24 — clubs restrict by rating, gender turned out unused):
   *   <p class="restriction-value" data-testid="rating-names">3.0, 3.5</p>
   * Absent block = unrestricted. Returns null when the event has none.
   */
  function readRestrictions() {
    const n = document.querySelector('[data-testid="rating-names"]');
    if (!n) return null;
    const names = (n.textContent || '').split(',').map((s) => s.trim()).filter(Boolean);
    return names.length ? { genderRestriction: '', ratingNames: names } : null;
  }

  /** Verdict for the current page's restrictions vs the stored profile. */
  async function eligibilityHere(orgId) {
    const restrictions = readRestrictions();
    if (!restrictions) return { eligible: true };
    const profile = await CRLib.profiles.get(orgId);
    return CRLib.eligibilityVerdict(profile, restrictions); // null = unknown
  }

  async function run(task) {
    const { entryId } = task;

    // Heartbeat: tell the watchdog this run is alive (slow pages at the
    // exact opening minute must not look like a dead tab).
    task.progressAt = Date.now();
    try { await chrome.storage.local.set({ pendingTask: task }); } catch { /* best-effort */ }

    await CRLib.sleep(1200); // initial render grace
    await pollFor(() => (document.body && document.body.innerText.length > 200) ? true : null, 15000);

    const report = (ok, state, message) =>
      chrome.runtime.sendMessage({ type: 'taskResult', entryId, ok, state, message });

    // Login gate
    const body0 = CRLib.bodyText();
    if (/sign in|log in/i.test(body0) && !/log ?out/i.test(body0) && !detect(body0)) {
      return report(false, 'failed', 'Not logged in — log into CourtReserve in this browser and re-run.');
    }
    if (ratingBlocked(body0)) {
      return report(false, 'ineligible', 'Not eligible by rating — CourtReserve blocks registration for this event.');
    }

    // Eligibility pre-check (v1.5.18): if the page's Rating/Gender
    // Restriction blocks exclude the stored profile, don't even try —
    // report the precise reason instead of clicking into a wall.
    const verdict = await eligibilityHere(task.orgId);
    if (verdict && verdict.eligible === false) {
      return report(false, 'ineligible', 'Not eligible for this event — ' + verdict.reason + '.');
    }

    // Already there? If THIS run clicked through the editor (confirmClicked)
    // or already clicked and reloaded once (reloaded), the registration we're
    // seeing is our own — report it as the plain confirmation it is. The
    // "(already)" wording is reserved for arriving on an event the user was
    // registered for by something OTHER than this run.
    const ours = !!(task.confirmClicked || task.reloaded);
    const state0 = detect(body0);
    if (state0 === 'registered') {
      return report(true, 'registered', ours ? 'Registered ✓' : 'Already registered — nothing to do.');
    }
    if (state0 === 'waitlisted') {
      const m = body0.match(/#(\d+)\s*on waitlist/i);
      return report(true, 'waitlisted',
        `Waitlisted${m ? ' #' + m[1] : ''}${ours ? ' ✓' : ' — already on it, nothing to do.'}`);
    }

    // Try Register → Finalize
    const reg = CRLib.findButton([/^register$/i, /^register now$/i, /^register for event/i]);
    if (reg) {
      reg.el.click();
      task.progressAt = Date.now(); // heartbeat: Register clicked
      try { await chrome.storage.local.set({ pendingTask: task }); } catch { /* best-effort */ }
      // A rating popup may appear immediately after the click.
      await CRLib.sleep(1200);
      if (ratingBlocked(CRLib.bodyText())) {
        return report(false, 'ineligible', 'Not eligible by rating — CourtReserve blocked the registration.');
      }
      const fin = await pollFor(() =>
        CRLib.findButton([/^finalize registration$/i, /^complete registration$/i, /^save$/i, /^submit$/i]), 8000);
      if (fin) {
        fin.el.click();
        await CRLib.sleep(500);
        await confirmDialog();
      }
      const done = await pollFor(() => detect(CRLib.bodyText()), 12000);
      if (done === 'registered') return report(true, 'registered', 'Registered ✓');
      if (done === 'waitlisted') {
        const m = CRLib.bodyText().match(/#(\d+)\s*on waitlist/i);
        return report(true, 'waitlisted', `Waitlisted${m ? ' #' + m[1] : ''}`);
      }
      if (!task.reloaded) {
        task.reloaded = true;
        task.progressAt = Date.now(); // heartbeat: reloading to re-check
        await chrome.storage.local.set({ pendingTask: task });
        location.reload();
        return;
      }
      return report(false, 'failed', 'Clicked Register but registration did not confirm.');
    }

    // Try Join Waitlist → confirm. CourtReserve's waitlist confirmation
    // screen labels its confirm button "Join Waitlist" AGAIN (same text as
    // the button that opened it), so the confirm matcher must accept that
    // label too — but skip the button we already clicked: it can stay in
    // the DOM (modal-style confirmation) and would swallow every match.
    const wl = CRLib.findButton([/join( the)? waitlist/i]);
    if (wl) {
      wl.el.click();
      await CRLib.sleep(800); // let the confirmation screen/dialog render
      const save = await pollFor(() =>
        findConfirmButton(
          [/^save$/i, /^confirm$/i, /^ok$/i, /^yes$/i, /^submit$/i, /join( the)? waitlist/i],
          wl.el), 6000);
      if (save) { save.el.click(); await CRLib.sleep(600); await confirmDialog(); }
      const done = await pollFor(() => detect(CRLib.bodyText()), 10000);
      if (done === 'waitlisted') {
        const m = CRLib.bodyText().match(/#(\d+)\s*on waitlist/i);
        return report(true, 'waitlisted', `Waitlisted${m ? ' #' + m[1] : ''}`);
      }
      if (done === 'registered') return report(true, 'registered', 'Registered ✓');
      return report(false, 'failed', 'Clicked Join Waitlist but the waitlist confirmation did not go through.');
    }

    if (ratingBlocked(CRLib.bodyText())) {
      return report(false, 'ineligible', 'Not eligible by rating — CourtReserve blocks registration for this event.');
    }

    // Fire-time verify: no Register/Waitlist button, but a "Registration
    // opens in …" countdown IS showing — the stored window rule was wrong
    // (the club changed it, or it was never detected). Read the REAL opening
    // moment, reschedule the entry, and refresh the category's rule in one
    // pass instead of failing a registration that can still succeed.
    const cdEl = findCountdownEl();
    const cdText = cdEl ? (cdEl.textContent || '').replace(/\s+/g, ' ').trim() : '';
    const cdMinutes = CRLib.parseCountdownMinutes(cdText);
    if (cdMinutes != null && task.date) {
      const eventDate = CRLib.parseLongDate(task.date);
      const opens = new Date(Date.now() + cdMinutes * 60000);
      // Prefer the page's own header time (ground truth) over the calendar
      // label's time carried on the task.
      const taskStartMin = readPageStartMinutes() ?? CRLib.parseEventStartMinutes(task.time);
      const rule = eventDate ? CRLib.deriveWindowRule(eventDate, opens, taskStartMin) : null;
      const s = await CRLib.settings.forOrg(task.orgId);
      const delaySec = typeof s.fireDelaySeconds === 'number'
        ? s.fireDelaySeconds
        : (typeof s.fireDelayMinutes === 'number' ? s.fireDelayMinutes * 60 : 60);
      const newFireAt = (rule ? rule.opensAt.getTime() : opens.getTime()) + delaySec * 1000;
      if (newFireAt > Date.now() + 60 * 1000) { // still time to make it
        return chrome.runtime.sendMessage({
          type: 'taskResult', entryId, ok: false, state: 'rescheduled',
          message: 'The registration window moved — the event page still shows a countdown. ' +
            'Rescheduled to ' + CRLib.fmtDateTime(new Date(newFireAt)) + '.',
          newFireAt,
          rule: rule ? { daysBefore: rule.daysBefore, openTime: rule.openTime, openAtEventStart: rule.openAtEventStart === true } : null,
          category: task.category || '',
        });
      }
    }
    return report(false, 'failed', 'No Register or Join Waitlist button — the registration window may not be open yet.');
  }

  // --- Auto Fill: read the "Registration opens in …" countdown, derive the
  // window rule, and save it. Registration windows differ PER CATEGORY, so an
  // org-targeted run saves the rule under this event's category and bounces
  // back to the calendar for the next category that still needs one; the
  // calendar side reports the final summary when none remain. ---
  async function runAutofill(pa) {
    const instanceId = (pa.detailsUrl || '').split('/').pop().toUpperCase();
    if (instanceId && !location.pathname.toUpperCase().endsWith(instanceId)) {
      // v1.7.27: this guard used to return SILENTLY for every tab — if the
      // RUN's tab was redirected (login bounce, SPA reroute), the run hung
      // with no log line. But a USER browsing another event mid-run must
      // still stay silent, so only the run's own tab may report.
      try {
        const d = await chrome.storage.local.get('autofillTabId');
        if (d.autofillTabId) {
          const me = await chrome.runtime.sendMessage({ type: 'whoami' });
          if (me && me.tabId != null && me.tabId !== d.autofillTabId) return; // user browsing — not the run tab
        }
        chrome.runtime.sendMessage({
          type: 'autofillResult', ok: false, orgId: pa.orgId,
          message: 'The event details page redirected to an unexpected URL (' +
            location.pathname + ') before its countdown could be read — you may be logged out. Log in and run detection again.',
        });
      } catch { /* context gone — the watchdog reports */ }
      return;
    }

    // v1.7.24: heartbeat — the watchdog's stall message names this step.
    // v1.7.34: and log it — the popup-only stageNote was invisible in log-only
    // debugging (Oct 22-23 stalls).
    CRLib.log('info', 'Detect registration window',
      `On the details page for "${pa.event}" (${pa.date}) — reading the countdown.`, 'Step');
    chrome.storage.local.set({
      pendingAutofill: {
        ...pa, progressAt: Date.now(),
        stageNote: `On the details page for "${pa.event}" (${pa.date}) — reading the countdown…`,
      },
    }).catch(() => {});

    const backToCalendar = (extra) =>
      chrome.storage.local.set({
        pendingAutofill: { ...pa, stage: 'scan', ...extra },
      }).then(() => {
        location.assign(`https://app.courtreserve.com/Online/Calendar/Events/${pa.orgId}/Month`);
      });

    // Restriction blocks render with the SPA — do NOT read them yet. The
    // countdown poll below doubles as the page-settle wait; eligibility is
    // read right after it (used by both the countdown and no-countdown
    // paths).
    await CRLib.sleep(500);
    const span = await pollFor(findCountdownEl, 8000); // the countdown renders early when it exists; 8 s covers the new UI's data fetch without stalling long on countdown-less event types
    // Now that the page has settled: this event's Rating/Gender Restriction
    // blocks vs the stored profile (null = unknown: no profile learned yet).
    const eligibility = await eligibilityHere(pa.orgId);
    if (!span) {
      // No countdown here. CourtReserve only shows the countdown for some
      // event TYPES (lessons/special events never have one): ONE read per
      // category is enough — other events of the same type won't have one.
      const tried = (pa.tried || []).concat([instanceId]);
      const cat = pa.category || '';
      const catTried = (pa.catTried || []).slice();
      const s0 = await CRLib.settings.load();
      const ex0 = (s0.perOrg || {})[pa.orgId] || {};
      let dirty = false;
      let nc = ex0.noCountdownCategories || [];
      let ce = ex0.categoryEligibility || {};
      if (cat && catTried.indexOf(cat) === -1) {
        catTried.push(cat);
        // Remember the verdict: this event type shows no countdown, so don't
        // re-investigate it on every popup open. A manual "Get settings from
        // CourtReserve" click clears the verdict and retries.
        // Only brand a category "no countdown" when it has NO rule yet. A
        // category with an established rule that shows no countdown on one
        // read keeps its rule (and stays in the daily validation loop) —
        // the furthest-future event may simply have opened already.
        const hasRule = !!(ex0.categoryWindows && ex0.categoryWindows[cat]);
        if (!hasRule && nc.indexOf(cat) === -1) { nc = nc.concat([cat]); dirty = true; }
      }
      // Eligibility (Rating/Gender Restriction vs profile) is readable even
      // without a countdown — persist it whenever it is known and changed.
      if (cat && eligibility &&
          (!ce[cat] || ce[cat].eligible !== eligibility.eligible ||
           (ce[cat].reason || '') !== (eligibility.reason || ''))) {
        ce = { ...ce };
        ce[cat] = { eligible: eligibility.eligible, reason: eligibility.reason || '', at: Date.now() };
        dirty = true;
      }
      if (dirty) {
        // settings.update reloads fresh state and keeps every unrelated key
        // (v1.7.13 — hand-built literals here used to wipe popup options).
        await CRLib.settings.update((s) => {
          const perOrgU = {};
          Object.keys(s.perOrg || {}).forEach((k) => { perOrgU[k] = s.perOrg[k]; });
          const exU = perOrgU[pa.orgId] || {};
          perOrgU[pa.orgId] = { ...exU, noCountdownCategories: nc, categoryEligibility: ce };
          s.perOrg = perOrgU;
        });
      }
      if (tried.length < 6) return backToCalendar({ tried, catTried });
      const saves = pa.saves || [];
      return chrome.runtime.sendMessage({
        type: 'autofillResult', ok: saves.length > 0, orgId: pa.orgId,
        message: saves.length
          ? `Saved rules for ${saves.map((s) => s.category || 'events').join(', ')}, but "${pa.event}" on ${pa.date} showed no countdown — its registration may already be open.`
          : `Tried ${tried.length} events (latest: "${pa.event}" on ${pa.date}) but none showed a "Registration opens in …" countdown — their registration may already be open.`,
      });
    }

    const countdownText = (span.textContent || '').replace(/\s+/g, ' ').trim();
    const minutes = CRLib.parseCountdownMinutes(countdownText);
    let eventDate = CRLib.parseLongDate(pa.date);
    // Cross-check with the page's own date — the calendar cell's date can be
    // misread at a month boundary (a trailing next-month cell parsed as this
    // month). The details page is ground truth: this tab was navigated to the
    // event's real Details URL, so when the two disagree, trust the page.
    // (Oct 4: calendar said "Oct 6" for a trailing "Nov 6" CORE Lottery cell
    // and a perfectly good 12-day rule was rejected as implausible.)
    const pageDate = readPageEventDate();
    if (pageDate && (!eventDate || pageDate.getTime() !== eventDate.getTime())) {
      if (eventDate) {
        CRLib.log('warn', 'Detect registration window',
          `Calendar date "${pa.date}" disagrees with the details page (${pageDate.toDateString()}) — trusting the details page.`,
          'Corrected');
      }
      eventDate = pageDate;
    }
    if (minutes == null || !eventDate) {
      return chrome.runtime.sendMessage({
        type: 'autofillResult', ok: false, orgId: pa.orgId,
        message: `Could not parse the countdown text: "${countdownText}".`,
      });
    }

    const opens = new Date(Date.now() + minutes * 60000);
    // Prefer the details page's own header time (ground truth); the calendar
    // label's time (pa.time) is the fallback (v1.7.53 — Widgi Creek's label
    // time never reached here, silently defeating openAtEventStart).
    const startMin = readPageStartMinutes() ?? CRLib.parseEventStartMinutes(pa.time);
    const rule = CRLib.deriveWindowRule(eventDate, opens, startMin);
    if (rule) {
      // Record exactly what was derived and from what — a fixed-vs-event-start
      // misread is otherwise invisible until a fire lands at the wrong hour.
      CRLib.log('info', 'Detect registration window',
        `Countdown implies opening ${CRLib.fmtDateTime(opens)}; "${pa.event}" starts ` +
        (startMin != null ? fmtMinOfDay(startMin) : '(start time unknown)') +
        ` → rule: ${rule.daysBefore} day(s) before ` +
        (rule.openAtEventStart ? 'at each event\'s start time' : 'at ' + rule.openTime) + '.',
        'Derived');
    }
    if (!rule) {
      return chrome.runtime.sendMessage({
        type: 'autofillResult', ok: false, orgId: pa.orgId,
        message: `The countdown implies registration opens ${CRLib.fmtDateTime(opens)} for an event on ${pa.date} — that is not a plausible days-before rule, so nothing was saved.`,
      });
    }

    const s = await CRLib.settings.load();
    if (pa.saveAs === 'global') {
      // Plain Auto Fill (no Org ID typed): update the global rule shown in
      // the Registration window fields.
      await CRLib.settings.update((s) => {
        s.daysBefore = rule.daysBefore;
        s.openTime = rule.openTime;
      });
      return chrome.runtime.sendMessage({
        type: 'autofillResult', ok: true, orgId: pa.orgId,
        message: `Detected from "${pa.event}" on ${pa.date}: registration opens ${rule.daysBefore} day(s) before the event at ${rule.openTime} — saved as the global rule.`,
      });
    }

    // Targeted Auto Fill: save the rule under this event's CATEGORY (falling
    // back to the org-level rule for categories without their own). The merge
    // runs inside settings.update against FRESH state — keyword filter, fire
    // delay, popup options, and other category rules must survive an Auto
    // Fill (v1.7.13 — the hand-built literal here dropped them).
    // "changed" drives silent validations: only a rule that actually moved
    // triggers a notification and a re-heal of scheduled fire times.
    const prevRule = pa.category ? (((s.perOrg || {})[pa.orgId] || {}).categoryWindows || {})[pa.category] : null;
    const changed = !!pa.category &&
      (!prevRule || prevRule.daysBefore !== rule.daysBefore || prevRule.openTime !== rule.openTime ||
       (prevRule.openAtEventStart === true) !== (rule.openAtEventStart === true));
    await CRLib.settings.update((su) => {
      const perOrg = {};
      Object.keys(su.perOrg || {}).forEach((k) => { perOrg[k] = su.perOrg[k]; });
      const existing = perOrg[pa.orgId] || {};
      const categoryWindows = { ...(existing.categoryWindows || {}) };
      if (pa.category) {
        categoryWindows[pa.category] = {
          daysBefore: rule.daysBefore, openTime: rule.openTime,
          openAtEventStart: rule.openAtEventStart === true,
          validatedAt: Date.now(), // fresh read — resets the 24h staleness clock
        };
      }
      // Eligibility verdict from this event's restriction blocks (known or not).
      const categoryEligibility = { ...(existing.categoryEligibility || {}) };
      if (pa.category && eligibility) {
        categoryEligibility[pa.category] = {
          eligible: eligibility.eligible, reason: eligibility.reason || '', at: Date.now(),
        };
      }
      perOrg[pa.orgId] = {
        ...existing,
        // The org-level rule is only the fallback: set it from the first
        // derivation, never overwrite an established one.
        daysBefore: existing.daysBefore !== undefined ? existing.daysBefore : rule.daysBefore,
        openTime: existing.openTime !== undefined ? existing.openTime : rule.openTime,
        categoryWindows,
        categoryEligibility,
      };
      su.perOrg = perOrg;
    });
    const saves = (pa.saves || []).concat([{
      category: pa.category || '', daysBefore: rule.daysBefore, openTime: rule.openTime,
      openAtEventStart: rule.openAtEventStart === true, changed,
      eligible: eligibility ? eligibility.eligible : null,
      ineligibleReason: eligibility && eligibility.eligible === false ? (eligibility.reason || '') : '',
    }]);
    // Back to the calendar: derive the next category's rule, or finish there.
    return backToCalendar({ tried: (pa.tried || []).concat([instanceId]), saves });
  }

  (async () => {
    // Orphaned by an extension reload — stay silent until the page reloads.
    if (!CRLib.ctxAlive()) return;
    try {
      const data = await chrome.storage.local.get(['pendingTask', 'pendingAutofill']);
      const pa = data.pendingAutofill;
      if (pa && pa.stage === 'details' && Date.now() - pa.startedAt <= MAX_TASK_AGE) {
        await runAutofill(pa);
        return;
      }
      const task = data.pendingTask;
      if (!task) return;
      // Runs now start on the calendar page (stage 'calendar'); this script
      // acts only after content-calendar.js forwards the tab here. Older
      // in-flight tasks have no stage — treat them as ready.
      if (task.stage && task.stage !== 'details') return;
      if (Date.now() - task.startedAt > MAX_TASK_AGE) {
        await chrome.storage.local.remove('pendingTask');
        return;
      }
      const instanceId = task.detailsUrl.split('/').pop().toUpperCase();
      if (!location.pathname.toUpperCase().endsWith(instanceId)) return; // user browsing another event
      await run(task);
    } catch (err) {
      try {
        const data = await chrome.storage.local.get(['pendingTask', 'pendingAutofill']);
        // v1.7.27: a DETECTION run dying here used to be silent — this catch
        // only reported pendingTask failures, so a thrown runAutofill left
        // the run hanging until the (often delayed) watchdog.
        const pa = data.pendingAutofill;
        if (pa && pa.stage === 'details' && Date.now() - pa.startedAt <= MAX_TASK_AGE) {
          chrome.runtime.sendMessage({
            type: 'autofillResult', ok: false, orgId: pa.orgId,
            message: 'The detection run hit an unexpected error on the details page: ' +
              (err && err.message ? err.message : String(err)) +
              '. Please send this log line to the developer.',
          });
          return;
        }
        if (data.pendingTask) {
          chrome.runtime.sendMessage({
            type: 'taskResult', entryId: data.pendingTask.entryId,
            ok: false, state: 'failed', message: 'Execution error: ' + err.message,
          });
        }
      } catch { /* nothing more we can do */ }
    }
  })();
})();
