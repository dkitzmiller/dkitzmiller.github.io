/* Court Helper for CourtReserve — details page execution engine.
   Runs when the background worker opens a details URL at fire time.
   Handles the full flow: register (incl. finalize), join waitlist,
   already-registered detection, one reload-and-recheck. */

(() => {
  const MAX_TASK_AGE = 5 * 60 * 1000;
  // CourtReserve blocks ineligible players with a rating popup / message.
  const RATING_RE = /not (allowed|eligible)[\s\S]{0,80}?rating|rating[\s\S]{0,40}(requirement|restricted|not met)|do(es)? not meet[\s\S]{0,40}(rating|eligibility)/i;
  const ratingBlocked = (body) => RATING_RE.test(body);

  function detect(body) {
    if (/edit registration/i.test(body)) return 'registered';
    if (/unsubscribe from waitlist/i.test(body) || /#\d+\s*on waitlist/i.test(body) || /waitlisted on:/i.test(body)) return 'waitlisted';
    return null;
  }

  async function confirmDialog() {
    const c = CRLib.findButton([/^confirm$/i, /^ok$/i, /^yes$/i, /^submit$/i]);
    if (c) { c.el.click(); await CRLib.sleep(800); }
  }

  async function pollFor(fn, timeout) {
    try { return await CRLib.waitFor(fn, timeout, 700); } catch { return null; }
  }

  async function run(task) {
    const { entryId } = task;

    await CRLib.sleep(1200); // initial render grace
    await pollFor(() => (document.body && document.body.innerText.length > 200) ? true : null, 15000);

    const report = (ok, state, message) =>
      chrome.runtime.sendMessage({ type: 'taskResult', entryId, ok, state, message });

    // Login gate
    const body0 = CRLib.bodyText();
    if (/sign in|log in/i.test(body0) && !/log ?out/i.test(body0) && !detect(body0)) {
      return report(false, 'failed', 'Not logged in — log into CourtReserve in this browser and re-run.');
    }
    if (ratingBlocked(body0)) {
      return report(false, 'ineligible', 'Not eligible by rating — CourtReserve blocks registration for this event.');
    }

    // Already there?
    const state0 = detect(body0);
    if (state0 === 'registered') return report(true, 'registered', 'Registered (already registered).');
    if (state0 === 'waitlisted') {
      const m = body0.match(/#(\d+)\s*on waitlist/i);
      return report(true, 'waitlisted', `Waitlisted${m ? ' #' + m[1] : ''} (already).`);
    }

    // Try Register → Finalize
    const reg = CRLib.findButton([/^register$/i, /^register now$/i, /^register for event/i]);
    if (reg) {
      reg.el.click();
      // A rating popup may appear immediately after the click.
      await CRLib.sleep(1200);
      if (ratingBlocked(CRLib.bodyText())) {
        return report(false, 'ineligible', 'Not eligible by rating — CourtReserve blocked the registration.');
      }
      const fin = await pollFor(() =>
        CRLib.findButton([/^finalize registration$/i, /^complete registration$/i, /^save$/i, /^submit$/i]), 8000);
      if (fin) {
        fin.el.click();
        await CRLib.sleep(500);
        await confirmDialog();
      }
      const done = await pollFor(() => detect(CRLib.bodyText()), 12000);
      if (done === 'registered') return report(true, 'registered', 'Registered ✓');
      if (done === 'waitlisted') {
        const m = CRLib.bodyText().match(/#(\d+)\s*on waitlist/i);
        return report(true, 'waitlisted', `Waitlisted${m ? ' #' + m[1] : ''}`);
      }
      if (!task.reloaded) {
        task.reloaded = true;
        await chrome.storage.local.set({ pendingTask: task });
        location.reload();
        return;
      }
      return report(false, 'failed', 'Clicked Register but registration did not confirm.');
    }

    // Try Join Waitlist → Save
    const wl = CRLib.findButton([/join( the)? waitlist/i]);
    if (wl) {
      wl.el.click();
      const save = await pollFor(() =>
        CRLib.findButton([/^save$/i, /^confirm$/i, /^ok$/i, /^yes$/i, /^submit$/i]), 6000);
      if (save) { save.el.click(); await CRLib.sleep(600); }
      const done = await pollFor(() => detect(CRLib.bodyText()), 10000);
      if (done === 'waitlisted') {
        const m = CRLib.bodyText().match(/#(\d+)\s*on waitlist/i);
        return report(true, 'waitlisted', `Waitlisted${m ? ' #' + m[1] : ''}`);
      }
      if (done === 'registered') return report(true, 'registered', 'Registered ✓');
      return report(false, 'failed', 'Clicked Join Waitlist but membership did not confirm.');
    }

    if (ratingBlocked(CRLib.bodyText())) {
      return report(false, 'ineligible', 'Not eligible by rating — CourtReserve blocks registration for this event.');
    }
    return report(false, 'failed', 'No Register or Join Waitlist button — the registration window may not be open yet.');
  }

  // --- Auto Fill: read the "Registration opens in …" countdown, derive the
  // window rule, and save it. Registration windows differ PER CATEGORY, so an
  // org-targeted run saves the rule under this event's category and bounces
  // back to the calendar for the next category that still needs one; the
  // calendar side reports the final summary when none remain. ---
  async function runAutofill(pa) {
    const instanceId = (pa.detailsUrl || '').split('/').pop().toUpperCase();
    if (instanceId && !location.pathname.toUpperCase().endsWith(instanceId)) return;

    const backToCalendar = (extra) =>
      chrome.storage.local.set({
        pendingAutofill: { ...pa, stage: 'scan', ...extra },
      }).then(() => {
        location.assign(`https://app.courtreserve.com/Online/Calendar/Events/${pa.orgId}/Month`);
      });

    await CRLib.sleep(800);
    const span = await pollFor(() => {
      const el = document.querySelector('span[data-testid="dropin-msg"]');
      return el && /registration opens in/i.test(el.textContent || '') ? el : null;
    }, 5000); // the countdown span renders early when it exists — never wait long on pages that don't show one
    if (!span) {
      // No countdown here. CourtReserve only shows the countdown for some
      // event TYPES (lessons/special events never have one): ONE read per
      // category is enough — other events of the same type won't have one.
      const tried = (pa.tried || []).concat([instanceId]);
      const cat = pa.category || '';
      const catTried = (pa.catTried || []).slice();
      if (cat && catTried.indexOf(cat) === -1) {
        catTried.push(cat);
        // Remember the verdict: this event type shows no countdown, so don't
        // re-investigate it on every popup open. A manual "Get settings from
        // CourtReserve" click clears the verdict and retries.
        const s0 = await CRLib.settings.load();
        const perOrg0 = {};
        Object.keys(s0.perOrg || {}).forEach((k) => { perOrg0[k] = s0.perOrg[k]; });
        const ex0 = perOrg0[pa.orgId] || {};
        const nc = (ex0.noCountdownCategories || []).slice();
        if (nc.indexOf(cat) === -1) {
          nc.push(cat);
          perOrg0[pa.orgId] = { ...ex0, noCountdownCategories: nc };
          await CRLib.settings.save({
            daysBefore: s0.daysBefore, openTime: s0.openTime, eventFilter: s0.eventFilter,
            eventFilterMode: s0.eventFilterMode, eventFilterColor: s0.eventFilterColor,
            eventFilterCategories: s0.eventFilterCategories,
            perOrg: perOrg0, fireDelayMinutes: s0.fireDelayMinutes,
            showAutoRegButtons: s0.showAutoRegButtons,
            showOpensIndicator: s0.showOpensIndicator === true,
          });
        }
      }
      if (tried.length < 6) return backToCalendar({ tried, catTried });
      const saves = pa.saves || [];
      return chrome.runtime.sendMessage({
        type: 'autofillResult', ok: saves.length > 0, orgId: pa.orgId,
        message: saves.length
          ? `Saved rules for ${saves.map((s) => s.category || 'events').join(', ')}, but "${pa.event}" on ${pa.date} showed no countdown — its registration may already be open.`
          : `Tried ${tried.length} events (latest: "${pa.event}" on ${pa.date}) but none showed a "Registration opens in …" countdown — their registration may already be open.`,
      });
    }

    const countdownText = (span.textContent || '').replace(/\s+/g, ' ').trim();
    const minutes = CRLib.parseCountdownMinutes(countdownText);
    const eventDate = CRLib.parseLongDate(pa.date);
    if (minutes == null || !eventDate) {
      return chrome.runtime.sendMessage({
        type: 'autofillResult', ok: false, orgId: pa.orgId,
        message: `Could not parse the countdown text: "${countdownText}".`,
      });
    }

    const opens = new Date(Date.now() + minutes * 60000);
    const rule = CRLib.deriveWindowRule(eventDate, opens);
    if (!rule) {
      return chrome.runtime.sendMessage({
        type: 'autofillResult', ok: false, orgId: pa.orgId,
        message: `The countdown implies registration opens ${CRLib.fmtDateTime(opens)} for an event on ${pa.date} — that is not a plausible days-before rule, so nothing was saved.`,
      });
    }

    const s = await CRLib.settings.load();
    if (pa.saveAs === 'global') {
      // Plain Auto Fill (no Org ID typed): update the global rule shown in
      // the Registration window fields.
      await CRLib.settings.save({
        daysBefore: rule.daysBefore, openTime: rule.openTime, eventFilter: s.eventFilter,
        eventFilterMode: s.eventFilterMode, eventFilterColor: s.eventFilterColor,
        eventFilterCategories: s.eventFilterCategories,
        perOrg: s.perOrg, fireDelayMinutes: s.fireDelayMinutes,
        showAutoRegButtons: s.showAutoRegButtons,
        showOpensIndicator: s.showOpensIndicator === true,
      });
      return chrome.runtime.sendMessage({
        type: 'autofillResult', ok: true, orgId: pa.orgId,
        message: `Detected from "${pa.event}" on ${pa.date}: registration opens ${rule.daysBefore} day(s) before the event at ${rule.openTime} — saved as the global rule.`,
      });
    }

    // Targeted Auto Fill: save the rule under this event's CATEGORY (falling
    // back to the org-level rule for categories without their own). Merge into
    // any existing override — keyword filter, fire delay, and other category
    // rules must survive an Auto Fill.
    const perOrg = {};
    Object.keys(s.perOrg || {}).forEach((k) => { perOrg[k] = s.perOrg[k]; });
    const existing = perOrg[pa.orgId] || {};
    const categoryWindows = { ...(existing.categoryWindows || {}) };
    if (pa.category) categoryWindows[pa.category] = { daysBefore: rule.daysBefore, openTime: rule.openTime };
    perOrg[pa.orgId] = {
      ...existing,
      // The org-level rule is only the fallback: set it from the first
      // derivation, never overwrite an established one.
      daysBefore: existing.daysBefore !== undefined ? existing.daysBefore : rule.daysBefore,
      openTime: existing.openTime !== undefined ? existing.openTime : rule.openTime,
      categoryWindows,
    };
    await CRLib.settings.save({
      daysBefore: s.daysBefore, openTime: s.openTime, eventFilter: s.eventFilter,
      eventFilterMode: s.eventFilterMode, eventFilterColor: s.eventFilterColor,
      eventFilterCategories: s.eventFilterCategories,
      perOrg, fireDelayMinutes: s.fireDelayMinutes,
      showAutoRegButtons: s.showAutoRegButtons,
      showOpensIndicator: s.showOpensIndicator === true,
    });
    const saves = (pa.saves || []).concat([{
      category: pa.category || '', daysBefore: rule.daysBefore, openTime: rule.openTime,
    }]);
    // Back to the calendar: derive the next category's rule, or finish there.
    return backToCalendar({ tried: (pa.tried || []).concat([instanceId]), saves });
  }

  (async () => {
    // Orphaned by an extension reload — stay silent until the page reloads.
    if (!CRLib.ctxAlive()) return;
    try {
      const data = await chrome.storage.local.get(['pendingTask', 'pendingAutofill']);
      const pa = data.pendingAutofill;
      if (pa && pa.stage === 'details' && Date.now() - pa.startedAt <= MAX_TASK_AGE) {
        await runAutofill(pa);
        return;
      }
      const task = data.pendingTask;
      if (!task) return;
      // Runs now start on the calendar page (stage 'calendar'); this script
      // acts only after content-calendar.js forwards the tab here. Older
      // in-flight tasks have no stage — treat them as ready.
      if (task.stage && task.stage !== 'details') return;
      if (Date.now() - task.startedAt > MAX_TASK_AGE) {
        await chrome.storage.local.remove('pendingTask');
        return;
      }
      const instanceId = task.detailsUrl.split('/').pop().toUpperCase();
      if (!location.pathname.toUpperCase().endsWith(instanceId)) return; // user browsing another event
      await run(task);
    } catch (err) {
      try {
        const data = await chrome.storage.local.get('pendingTask');
        if (data.pendingTask) {
          chrome.runtime.sendMessage({
            type: 'taskResult', entryId: data.pendingTask.entryId,
            ok: false, state: 'failed', message: 'Execution error: ' + err.message,
          });
        }
      } catch { /* nothing more we can do */ }
    }
  })();
})();
