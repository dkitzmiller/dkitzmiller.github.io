/* Court Helper for CourtReserve — background service worker.
   Schedules chrome.alarms per entry, runs ONE registration flow at a time
   (calendar TODAY refresh → details page), collects results, retries
   failures twice, and catches up missed entries at Chrome startup.

   All entry/queue mutations are serialized through withEntryLock: content
   scripts and the popup never write `entries` directly, so a single
   promise-chain lock here closes every read-modify-write race (e.g. two
   'heal' messages from one calendar scan clobbering each other's writes). */

importScripts('lib/crlib.js');

const RETRY_DELAY_MIN = 2;
const MAX_RETRIES = 2;
const STAGGER_MS = 15000;
/** If no result comes back within this window, the run is treated as failed
    (login redirect, unexpected page, killed script) instead of silently
    staying "scheduled" forever. */
const WATCHDOG_MIN = 3;
const AUTOFILL_WATCHDOG = 'watchdog:autofill';
const QUEUE_KEY = 'taskQueue';
const LICENSE_REVALIDATE = 'license:revalidate';

/** Premium gate: schedule/runNow/fireEntry require an active license. */
async function isPremium() {
  const lic = await CRLib.license.get();
  return CRLib.license.isPremium(lic);
}

function alarmName(id) { return 'autoreg:' + id; }
function watchdogName(id) { return 'watchdog:' + id; }

/** Promise-chain mutex. Only wrap outermost entry points — helpers called
    from inside a locked section (handleResult, dedupeEntries, fireEntry,
    runEntry, pumpQueue, startRun) must stay unwrapped or the chain deadlocks. */
let entryLock = Promise.resolve();
function withEntryLock(fn) {
  const run = entryLock.then(fn, fn);
  entryLock = run.catch(() => {});
  return run;
}

async function notify(title, message) {
  try {
    await chrome.notifications.create(undefined, {
      type: 'basic',
      iconUrl: 'icons/icon128.png',
      title,
      message,
      priority: 2,
    });
  } catch { /* notifications unavailable — non-fatal */ }
}

async function updateBadge() {
  const entries = await CRLib.store.list();
  const n = entries.filter((e) => e.status === 'scheduled').length;
  await chrome.action.setBadgeText({ text: n > 0 ? String(n) : '' });
  await chrome.action.setBadgeBackgroundColor({ color: '#d97706' });
}

// ---------------------------------------------------------------------------
// Run queue: exactly one registration flow is in flight at a time. Entries
// that fire while another run is active are queued (persisted in storage, so
// a service-worker restart cannot lose them) and started when the current
// run reports — success, failure, or watchdog timeout. The single global
// pendingTask slot can therefore never be overwritten by a simultaneous fire.
// ---------------------------------------------------------------------------

async function getQueue() {
  const r = await chrome.storage.local.get(QUEUE_KEY);
  return r[QUEUE_KEY] || [];
}

async function setQueue(q) {
  await chrome.storage.local.set({ [QUEUE_KEY]: q });
}

async function hasActiveRun() {
  const data = await chrome.storage.local.get('pendingTask');
  const t = data.pendingTask;
  // "Active" = within the watchdog window; older leftovers are reclaimed by
  // the watchdog or by catchUp().
  return !!(t && Date.now() - t.startedAt <= (WATCHDOG_MIN + 0.5) * 60 * 1000);
}

let runStarting = false; // same-worker race guard (two alarms on the same tick)

async function startRun(entry) {
  // Re-validate against the store: the entry may have been removed or
  // completed while it sat in the queue.
  const fresh = await CRLib.store.get(entry.id);
  if (!fresh || fresh.status === 'done' || fresh.status === 'failed') return;
  entry = fresh;

  // Two-hop flow: land on the org's month calendar FIRST and let
  // content-calendar.js click the scheduler's TODAY button — that forces a
  // fresh server read, so the details page can't be a stale pre-open
  // snapshot (no Register button). The calendar script then forwards the tab
  // to the event's details URL with stage 'details'.
  const calendarUrl = `https://app.courtreserve.com/Online/Calendar/Events/${entry.orgId}/Month`;
  await chrome.storage.local.set({
    pendingTask: {
      entryId: entry.id,
      orgId: entry.orgId,
      detailsUrl: entry.detailsUrl,
      date: entry.date || '', // fire-time verify: derive the real rule from a countdown
      category: entry.category || '',
      startedAt: Date.now(),
      reloaded: false,
      stage: 'calendar',
    },
  });
  await chrome.alarms.create(watchdogName(entry.id), { delayInMinutes: WATCHDOG_MIN });
  await chrome.tabs.create({ url: calendarUrl, active: false });
}

async function runEntry(entry) {
  if (runStarting || (await hasActiveRun())) {
    const q = await getQueue();
    if (!q.some((e) => e.id === entry.id)) {
      q.push(entry);
      await setQueue(q);
    }
    return;
  }
  runStarting = true;
  try {
    await startRun(entry);
  } finally {
    runStarting = false;
  }
}

async function pumpQueue() {
  const q = await getQueue();
  if (!q.length) return;
  const next = q.shift();
  await setQueue(q);
  await startRun(next);
}

async function fireEntry(id) {
  const entry = await CRLib.store.get(id);
  if (!entry || entry.status === 'done' || entry.status === 'failed') return;
  if (!(await isPremium())) {
    entry.status = 'failed';
    entry.lastRun = { at: Date.now(), ok: false, message: 'Premium license is not active.' };
    await CRLib.store.put(entry);
    await notify('🔒 Auto-Register skipped', `${entry.event} — ${CRLib.abbrevDate(entry.date)}, ${entry.time}\nPremium is not active on this browser.`);
    return;
  }
  await runEntry(entry);
}

async function handleResult(msg) {
  await chrome.storage.local.remove('pendingTask');
  await chrome.alarms.clear(watchdogName(msg.entryId));
  const entry = await CRLib.store.get(msg.entryId);
  if (!entry) { await pumpQueue(); return; }

  entry.lastRun = { at: Date.now(), ok: msg.ok, message: msg.message };

  if (msg.ok) {
    entry.status = 'done';
    await CRLib.store.put(entry);
    await chrome.alarms.clear(alarmName(entry.id));
    await notify(
      msg.state === 'waitlisted' ? '⏳ Auto-Register: waitlisted' : '✅ Auto-Register: registered',
      `${entry.event} — ${CRLib.abbrevDate(entry.date)}, ${entry.time}\n${msg.message}`,
    );
    // keep done entries briefly for the popup, then clean
    setTimeout(() => CRLib.store.remove(entry.id), 10 * 60 * 1000);
    await pumpQueue();
    // Post-fire piggyback: the browser is already awake and on CourtReserve,
    // so re-verify any stale window rules now — no extra wake needed.
    await maybeValidateRules('post-fire');
    return;
  }

  // Fire-time verify: the details page still showed a countdown — the stored
  // window rule was wrong (the club changed it). Reschedule to the REAL
  // opening moment and refresh the category rule. Not a failure: the retry
  // count stays where it is.
  if (msg.state === 'rescheduled' && typeof msg.newFireAt === 'number' && msg.newFireAt > Date.now()) {
    entry.fireAt = msg.newFireAt;
    entry.status = 'scheduled';
    await CRLib.store.put(entry);
    await chrome.alarms.clear(alarmName(entry.id));
    await chrome.alarms.create(alarmName(entry.id), { when: entry.fireAt });
    if (msg.rule && msg.category) {
      await saveCategoryRule(entry.orgId, msg.category, msg.rule);
      // Other scheduled entries of this category fire at the old moment too —
      // recompute them against the corrected rule.
      await healScheduledEntries();
    }
    await notify('🕐 Auto-Register rescheduled',
      `${entry.event} — ${CRLib.abbrevDate(entry.date)}, ${entry.time}\n${msg.message}`);
    await pumpQueue();
    return;
  }

  entry.retryCount = (entry.retryCount || 0) + 1;
  // 'ineligible' (rating-blocked) is terminal — retrying cannot change it.
  if (entry.retryCount <= MAX_RETRIES && msg.state !== 'ineligible') {
    entry.status = 'retrying';
    await CRLib.store.put(entry);
    await chrome.alarms.create(alarmName(entry.id), { when: Date.now() + RETRY_DELAY_MIN * 60 * 1000 });
    await notify('🔁 Auto-Register retry scheduled',
      `${entry.event} — ${CRLib.abbrevDate(entry.date)}, ${entry.time}\n${msg.message}\nRetry ${entry.retryCount}/${MAX_RETRIES} in ${RETRY_DELAY_MIN} min.`);
  } else {
    entry.status = 'failed';
    await CRLib.store.put(entry);
    await notify('❌ Auto-Register failed',
      `${entry.event} — ${CRLib.abbrevDate(entry.date)}, ${entry.time}\n${msg.message}`);
  }
  await pumpQueue();
}

// ---------------------------------------------------------------------------
// Rule validation: clubs sometimes change their registration-window rules
// (e.g. a seasonal shift), and the extension is never told. Three safety nets
// keep scheduled entries accurate without any nightly wake:
//   1. FIRE-TIME VERIFY  — a run that finds no Register button but a live
//      "Registration opens in …" countdown reschedules itself to the real
//      opening moment and refreshes the category rule (handled above).
//   2. POST-FIRE PIGGYBACK — after any successful registration, re-verify
//      stale rules while the browser is already on CourtReserve.
//   3. WAKE BACKSTOP — every service-worker cold start (≥5 min apart) also
//      checks staleness, so rule drift is caught within ~a day of use.
// A rule is stale when it is missing or its validatedAt is >24h old
// (CRLib.categoriesNeedingValidation). Validation reuses the Auto Fill
// machinery silently (no tabs in front, no notification unless a rule moved).
// ---------------------------------------------------------------------------

/** Persist a freshly read window rule for one category (org override). */
async function saveCategoryRule(orgId, category, rule, validatedAt) {
  const s = await CRLib.settings.load();
  const perOrg = {};
  Object.keys(s.perOrg || {}).forEach((k) => { perOrg[k] = s.perOrg[k]; });
  const existing = perOrg[orgId] || {};
  const categoryWindows = { ...(existing.categoryWindows || {}) };
  categoryWindows[category] = {
    daysBefore: rule.daysBefore,
    openTime: rule.openTime,
    validatedAt: typeof validatedAt === 'number' ? validatedAt : Date.now(),
  };
  perOrg[orgId] = { ...existing, categoryWindows };
  await CRLib.settings.save({
    daysBefore: s.daysBefore, openTime: s.openTime, eventFilter: s.eventFilter,
    eventFilterMode: s.eventFilterMode, eventFilterColor: s.eventFilterColor,
    eventFilterCategories: s.eventFilterCategories,
    perOrg, fireDelayMinutes: s.fireDelayMinutes,
    showAutoRegButtons: s.showAutoRegButtons,
    showOpensIndicator: s.showOpensIndicator === true,
  });
}

/**
 * Recompute fireAt for every scheduled entry from the CURRENT rules. Called
 * after a rule changed (fire-time reschedule or a silent validation that
 * found a moved window) so sibling entries of the same category don't keep
 * firing at the old moment. Only entries carrying a category heal precisely;
 * category-less entries rely on the calendar scan's own heal pass.
 */
async function healScheduledEntries() {
  const entries = await CRLib.store.list();
  for (const e of entries) {
    if (e.status !== 'scheduled' && e.status !== 'retrying') continue;
    if (!e.category) continue;
    const eventDate = CRLib.parseLongDate(e.date);
    if (!eventDate) continue;
    const s = await CRLib.settings.forOrg(e.orgId);
    const fireAt = CRLib.fireTime(eventDate, s, e.category).getTime();
    if (fireAt === e.fireAt) continue;
    e.fireAt = fireAt;
    await CRLib.store.put(e);
    await chrome.alarms.clear(alarmName(e.id));
    if (fireAt <= Date.now()) {
      // The corrected window is already open (or opening within the delay) —
      // run it now; the Register button should be there.
      await runEntry(e);
    } else {
      await chrome.alarms.create(alarmName(e.id), { when: fireAt });
    }
  }
}

/**
 * If any org with a scheduled entry due within 10 days has a selected
 * category whose window rule is missing or stale, kick off ONE silent
 * revalidation for it. No-op while a registration or another validation is
 * in flight, and when nothing needs checking — so this costs nothing on
 * ordinary wakes.
 */
async function maybeValidateRules(reason) {
  try {
    const data = await chrome.storage.local.get(['pendingAutofill', 'pendingTask']);
    if (data.pendingAutofill || data.pendingTask) return; // one flow at a time
    const entries = await CRLib.store.list();
    const horizon = Date.now() + 10 * 24 * 60 * 60 * 1000;
    const orgIds = {};
    for (const e of entries) {
      if (e.status !== 'scheduled' || typeof e.fireAt !== 'number' || e.fireAt > horizon) continue;
      orgIds[e.orgId] = true;
    }
    for (const orgId of Object.keys(orgIds)) {
      const s = await CRLib.settings.forOrg(orgId);
      if (CRLib.categoriesNeedingValidation(s).length) {
        await startAutofill(orgId, { silent: true, revalidate: true });
        return; // one org per pass; the next wake/success covers the rest
      }
    }
  } catch { /* rule validation is best-effort */ }
}

/**
 * One entry per occurrence. Identity is org + event + date + time
 * (CRLib.entryKey); CourtReserve rotates its Details-link tokens, so before
 * this rule the same event could be scheduled twice under different ids.
 * Keeps preferId when given, else the most recently created entry (the newer
 * the entry, the fresher its link), and clears alarms/storage for the rest.
 */
async function dedupeEntries(preferId) {
  const entries = await CRLib.store.list();
  const groups = {};
  for (const e of entries) {
    const key = CRLib.entryKey(e.orgId, e);
    (groups[key] = groups[key] || []).push(e);
  }
  for (const key of Object.keys(groups)) {
    const group = groups[key];
    if (group.length < 2) continue;
    let keep = preferId ? group.find((e) => e.id === preferId) : null;
    if (!keep) {
      keep = group.slice().sort((a, b) =>
        String(b.createdAt || '').localeCompare(String(a.createdAt || '')))[0];
    }
    for (const e of group) {
      if (e.id === keep.id) continue;
      await chrome.alarms.clear(alarmName(e.id));
      await chrome.alarms.clear(watchdogName(e.id));
      await CRLib.store.remove(e.id);
    }
  }
}

async function catchUp() {
  // Reclaim a run left in flight by a browser/service-worker restart.
  const ptData = await chrome.storage.local.get('pendingTask');
  const pt = ptData.pendingTask;
  if (pt && Date.now() - pt.startedAt > (WATCHDOG_MIN + 0.5) * 60 * 1000) {
    await chrome.storage.local.remove('pendingTask');
    await handleResult({
      type: 'taskResult', entryId: pt.entryId, ok: false, state: 'failed',
      message: 'The browser restarted while a registration was in progress.',
    });
  }

  // Merge duplicate entries for the same occurrence before re-arming alarms.
  await dedupeEntries(null);

  const entries = await CRLib.store.list();
  const now = Date.now();
  let stagger = 0;
  for (const e of entries) {
    if (e.status === 'done' || e.status === 'failed') continue;
    if (e.fireAt <= now) {
      setTimeout(() => fireEntry(e.id), stagger);
      stagger += STAGGER_MS;
    } else {
      await chrome.alarms.create(alarmName(e.id), { when: e.fireAt });
    }
  }

  // Drain any queued runs left over from before the restart.
  const queued = await getQueue();
  if (queued.length) {
    await setQueue([]);
    for (const e of queued) {
      setTimeout(() => fireEntry(e.id), stagger);
      stagger += STAGGER_MS;
    }
  }
}

// ---------------------------------------------------------------------------
// Auto Fill: derive the registration-window rule from a live details page.
// Flow: popup starts it → we open the org's month calendar → content-calendar
// picks a not-yet-open event matching the keyword filter and follows its
// Details link → content-details reads "Registration opens in …", computes
// daysBefore/openTime, saves them, and reports back via 'autofillResult'.
// ---------------------------------------------------------------------------

async function startAutofill(orgIdHint, opts) {
  const hinted = /^\d+$/.test(String(orgIdHint || '').trim());
  let orgId = hinted ? String(orgIdHint).trim() : '';
  if (!orgId) {
    // Fall back to the org of an already-open CourtReserve calendar tab.
    const tabs = await chrome.tabs.query({ url: 'https://app.courtreserve.com/Online/Calendar/Events/*' });
    for (const t of tabs) {
      const m = /\/Online\/Calendar\/Events\/(\d+)/.exec(t.url || '');
      if (m) { orgId = m[1]; break; }
    }
  }
  if (!orgId) {
    // Last resort: a previously learned org, preferring the one CourtReserve
    // marks as Primary in the "My Clubs" menu.
    const data = await chrome.storage.local.get('orgs');
    const known = Array.isArray(data.orgs) ? data.orgs : [];
    const pick = known.find((o) => o.primary) || known[0];
    if (pick && /^\d+$/.test(String(pick.id))) orgId = String(pick.id);
  }
  if (!orgId) {
    // Nothing learned yet and no calendar tab open — fail with guidance
    // instead of guessing an org id.
    await chrome.storage.local.set({
      autofillResult: {
        ok: false,
        message: 'No organization known yet — open your club\u2019s CourtReserve calendar once, then retry.',
        orgId: '',
        at: Date.now(),
      },
    });
    return;
  }
  await chrome.storage.local.remove('autofillResult');
  // Eligibility verdicts need the player's Gender + rating(s) — fetch the
  // profile first when it is missing or stale (throttled, silent).
  await ensureProfile(orgId);
  await chrome.alarms.create(AUTOFILL_WATCHDOG, { delayInMinutes: 5 }); // multi-category loop, up to 6 attempts
  const tab = await chrome.tabs.create({
    url: `https://app.courtreserve.com/Online/Calendar/Events/${orgId}/Month`,
    active: false,
  });
  await chrome.storage.local.set({
    pendingAutofill: {
      orgId,
      // An explicit Org ID targets that org (saved as an override); a plain
      // Auto Fill updates the global rule the user sees in the fields above.
      saveAs: hinted ? 'override' : 'global',
      stage: 'scan',
      startedAt: Date.now(),
      // Silent revalidation (rule-drift safety net): also re-check rules that
      // are merely STALE, and stay quiet unless a rule actually moved.
      revalidate: !!(opts && opts.revalidate),
      silent: !!(opts && opts.silent),
      // Full sweep (explicit "Get settings from CourtReserve"): investigate
      // EVERY category on the org's FILTER list — rules AND eligibility.
      allCategories: !!(opts && opts.allCategories),
    },
    autofillTabId: tab.id,
  });
}

async function finishAutofill(msg) {
  const afData = await chrome.storage.local.get(['pendingAutofill', 'autofillTabId']);
  const pa = afData.pendingAutofill || null;
  const tabId = afData.autofillTabId || null;
  await chrome.storage.local.remove(['pendingAutofill', 'autofillTabId']);
  await chrome.alarms.clear(AUTOFILL_WATCHDOG);
  if (tabId) {
    try { await chrome.tabs.remove(tabId); } catch { /* tab may already be closed */ }
  }
  await chrome.storage.local.set({
    autofillResult: {
      ok: !!msg.ok,
      message: msg.message || '',
      orgId: msg.orgId || '',
      at: Date.now(),
    },
  });
  // If a first-run init is waiting on this Auto Fill, it ends here.
  const initData = await chrome.storage.local.get(INIT_KEY);
  const init = initData[INIT_KEY];
  if (init && init.running && init.stage === 'autofill') {
    await chrome.storage.local.set({
      [INIT_KEY]: { running: false, stage: 'done', orgId: init.orgId, ok: !!msg.ok, message: msg.message || '', at: Date.now() },
    });
  }
  if (pa && pa.silent) {
    // Silent rule validation: no fanfare when everything still matches, and
    // failures stay quiet too (the next wake retries). Only a rule that
    // actually MOVED earns a notification — and a re-heal of every scheduled
    // entry so they fire at the corrected moment.
    if (msg.ok && msg.changed) {
      await withEntryLock(healScheduledEntries);
      await notify('🔄 Registration window changed',
        (msg.message || 'A club changed a registration window.') +
        '\nYour scheduled auto-registrations were updated to the new times.');
    }
    return;
  }
  await notify(
    msg.ok ? '✨ Auto Fill: registration window detected' : '⚠ Auto Fill failed',
    msg.message || '',
  );
}

// ---------------------------------------------------------------------------
// First-run initialization ("Detect my club & settings" on the Setup tab).
// Chains existing pieces: find the user's main org (Primary badge from the
// learned "My Clubs" list, else an org id in any open CourtReserve tab) →
// load that org's calendar FILTER categories → run Auto Fill to derive the
// registration-window rule. Progress lives in storage key INIT_KEY so the
// popup can render it (and survives the popup closing).
// ---------------------------------------------------------------------------

const INIT_KEY = 'initState';
const INIT_WATCHDOG = 'watchdog:init';

async function setInit(patch) {
  const data = await chrome.storage.local.get(INIT_KEY);
  await chrome.storage.local.set({ [INIT_KEY]: { ...(data[INIT_KEY] || {}), ...patch } });
}

function orgIdFromUrl(url) {
  const m =
    /\/Online\/(?:Calendar\/Events|Portal\/Index)\/(\d+)/.exec(url || '') ||
    /\/Online\/Events\/Details\/(\d+)\//.exec(url || '');
  return m ? m[1] : '';
}

/** Main org: the one CourtReserve marks Primary, else any org id visible in
    an open CourtReserve tab, else the first learned org. */
async function findMainOrgId() {
  const data = await chrome.storage.local.get('orgs');
  const known = Array.isArray(data.orgs) ? data.orgs : [];
  const primary = known.find((o) => o.primary && /^\d+$/.test(String(o.id)));
  if (primary) return String(primary.id);
  const tabs = await chrome.tabs.query({ url: 'https://app.courtreserve.com/*' });
  for (const t of tabs) {
    const id = orgIdFromUrl(t.url);
    if (id) return id;
  }
  const first = known.find((o) => /^\d+$/.test(String(o.id)));
  return first ? String(first.id) : '';
}

/** Resolve when the tab finishes loading (or the timeout hits). */
function waitForTabComplete(tabId, timeoutMs) {
  return new Promise((resolve) => {
    let done = false;
    const timer = setTimeout(() => finish(false), timeoutMs || 15000);
    function finish(ok) {
      if (done) return;
      done = true;
      clearTimeout(timer);
      chrome.tabs.onUpdated.removeListener(listener);
      resolve(ok);
    }
    function listener(id, info) { if (id === tabId && info.status === 'complete') finish(true); }
    chrome.tabs.onUpdated.addListener(listener);
  });
}

// ---------------------------------------------------------------------------
// Player profile learning (v1.5.18): the My Profile page carries the user's
// Gender and rating(s) per organization — the yardstick for the Rating/Gender
// Restriction blocks on event details pages. content-profile.js saves the
// profile whenever the user visits the page; ensureProfile fetches it in the
// background for orgs that have none yet (first-run init, popup org view).
// ---------------------------------------------------------------------------

// Runs in the profile page's MAIN world. Must be fully self-contained —
// same reading logic as content-profile.js.
function readPlayerProfile() {
  try {
    var antSelectValue = function (inputId) {
      var inp = document.getElementById(inputId);
      if (!inp) return "";
      var wrap = inp.closest(".ant-select");
      if (!wrap) return inp.value || "";
      var item = wrap.querySelector(".ant-select-selection-item");
      return item ? (item.getAttribute("title") || item.textContent || "").trim() : "";
    };
    var gender = antSelectValue("Gender");
    // Three rating fields exist: "Rating" (club-given — the restriction
    // yardstick), "CORE Rating System" (tested/external), and "Player
    // Rating" (self-declared custom field). Use the club's "Rating"; fall
    // back to CORE, then the self-declared value only when neither is set.
    var byLabel = {};
    var labels = document.querySelectorAll("label.form-label[for]");
    for (var i = 0; i < labels.length; i++) {
      var text = (labels[i].textContent || "").trim();
      if (!/rating/i.test(text)) continue;
      var forId = labels[i].getAttribute("for");
      var target = forId && document.getElementById(forId);
      if (!target) continue;
      var val = target.closest(".ant-select") ? antSelectValue(forId) : String(target.value || "").trim();
      if (val) byLabel[text.toLowerCase()] = val;
    }
    var ratings = [];
    var core = "";
    Object.keys(byLabel).forEach(function (k) { if (/core/.test(k) && !core) core = byLabel[k]; });
    if (byLabel["rating"]) ratings.push(byLabel["rating"]);
    else if (core) ratings.push(core);
    else if (byLabel["player rating"]) ratings.push(byLabel["player rating"]);
    return { gender: gender, ratings: ratings };
  } catch (e) {
    return { gender: "", ratings: [] };
  }
}

let profileFetchInFlight = false;

/** Fetch and store the player's profile for an org when missing or stale
    (>30 days). Silent and best-effort: one background tab, no notifications. */
async function ensureProfile(orgId) {
  orgId = String(orgId || "").trim();
  if (!/^\d+$/.test(orgId) || profileFetchInFlight) return;
  const existing = await CRLib.profiles.get(orgId);
  if (existing && Date.now() - (existing.at || 0) < 30 * 24 * 60 * 60 * 1000) return;
  profileFetchInFlight = true;
  let tabId = null;
  try {
    const tab = await chrome.tabs.create({
      url: `https://app.courtreserve.com/Online/MyProfile/MyProfile/${orgId}`,
      active: false,
    });
    tabId = tab.id;
    await waitForTabComplete(tabId, 20000);
    await new Promise((r) => setTimeout(r, 2000)); // let the Ant form render
    const res = await chrome.scripting.executeScript({
      target: { tabId },
      world: 'MAIN',
      func: readPlayerProfile,
    });
    const p = (res && res[0] && res[0].result) || null;
    if (p && (p.gender || (p.ratings || []).length)) {
      await CRLib.profiles.put(orgId, { gender: p.gender, ratings: p.ratings, at: Date.now() });
    }
  } catch { /* profile learning is best-effort */ }
  if (tabId) {
    try { await chrome.tabs.remove(tabId); } catch { /* already closed */ }
  }
  profileFetchInFlight = false;
}

// Runs in the calendar page's MAIN world. Must be fully self-contained.
// Same reader the popup uses for the FILTER panel category list.
function readCalendarCategories() {  try {
    var rows = document.querySelectorAll('.custom-checkbox.rowCheckbox');
    if (!rows.length && typeof openLeftNav === 'function') {
      openLeftNav(); // some org pages render the panel lazily
      rows = document.querySelectorAll('.custom-checkbox.rowCheckbox');
    }
    var out = [];
    for (var i = 0; i < rows.length; i++) {
      var label = rows[i].querySelector('label.k-checkbox-label');
      var swatch = rows[i].querySelector('.categ-line-color');
      if (!label) continue;
      out.push({ name: label.innerText.trim(), color: swatch ? swatch.style.backgroundColor : '' });
    }
    out.sort(function (a, b) { return a.name.localeCompare(b.name); });
    return out;
  } catch (e) {
    return [];
  }
}

async function startInit() {
  const existing = (await chrome.storage.local.get(INIT_KEY))[INIT_KEY];
  if (existing && existing.running && Date.now() - (existing.at || 0) < 6 * 60 * 1000) return; // one at a time

  await setInit({ running: true, stage: 'find-org', orgId: '', ok: false, message: '', at: Date.now() });
  await chrome.alarms.create(INIT_WATCHDOG, { delayInMinutes: 4 }); // covers find-org + categories; autofill has its own watchdog

  // 1) Find the main organization. If nothing is known and no CourtReserve
  //    tab is open, open the portal (active) and poll while the user logs in
  //    and lands on their club.
  let orgId = await findMainOrgId();
  if (!orgId) {
    const tabs = await chrome.tabs.query({ url: 'https://app.courtreserve.com/*' });
    if (!tabs.length) {
      await chrome.tabs.create({ url: 'https://app.courtreserve.com/', active: true });
    }
    const deadline = Date.now() + 150000;
    while (!orgId && Date.now() < deadline) {
      await new Promise((r) => setTimeout(r, 2500));
      orgId = await findMainOrgId();
    }
  }
  if (!orgId) {
    await chrome.alarms.clear(INIT_WATCHDOG);
    await setInit({
      running: false, stage: 'done', ok: false, at: Date.now(),
      message: 'No organization found — log into CourtReserve, open your club\u2019s calendar, then run setup again.',
    });
    await notify('⚠ Setup incomplete', 'Log into CourtReserve, open your club\u2019s calendar, then run setup again.');
    return;
  }
  await setInit({ orgId, stage: 'categories' });

  // 2) Load the org's FILTER categories from its calendar (reuses an open
  //    calendar tab when one exists). The same page load also lets the
  //    content script learn the org names/Primary badge. A logged-out or
  //    changed page yields an empty list — non-fatal: categories can be
  //    refreshed later from Settings.
  let createdTabId = null;
  try {
    const calTabs = await chrome.tabs.query({ url: `https://app.courtreserve.com/Online/Calendar/Events/${orgId}/*` });
    let tabId = calTabs.length ? calTabs[0].id : null;
    if (!tabId) {
      const tab = await chrome.tabs.create({
        url: `https://app.courtreserve.com/Online/Calendar/Events/${orgId}/Month`,
        active: false,
      });
      tabId = tab.id;
      createdTabId = tab.id;
      await waitForTabComplete(tabId, 20000);
      await new Promise((r) => setTimeout(r, 2000)); // let the FILTER panel render
    }
    const res = await chrome.scripting.executeScript({
      target: { tabId },
      world: 'MAIN',
      func: readCalendarCategories,
    });
    const cats = (res && res[0] && res[0].result) || [];
    if (cats.length) {
      const data = await chrome.storage.local.get('orgCategories');
      const orgCategories = data.orgCategories || {};
      orgCategories[orgId] = cats;
      await chrome.storage.local.set({ orgCategories });
    }
  } catch { /* categories are best-effort during init */ }
  if (createdTabId) {
    try { await chrome.tabs.remove(createdTabId); } catch { /* already closed */ }
  }

  // 2.5) Learn the player's Gender + rating(s) for this org — the yardstick
  //      for Rating/Gender Restriction blocks on event pages (eligibility
  //      filtering). Best-effort and silent.
  await setInit({ stage: 'categories' });
  await ensureProfile(orgId);

  // 3) Derive the registration-window rules AND eligibility for EVERY
  //    category (full sweep): one details-page visit per FILTER category
  //    reads its countdown rule and its Rating/Gender Restriction blocks, so
  //    restricted categories are already hidden when the user first opens
  //    Settings. finishAutofill finalizes the init state; the autofill
  //    watchdog covers failure from here on.
  await chrome.alarms.clear(INIT_WATCHDOG);
  await setInit({ stage: 'autofill' });
  const pending = (await chrome.storage.local.get('pendingAutofill')).pendingAutofill;
  if (!pending) await startAutofill(orgId, { allCategories: true }); // targeted → saved as this org's rules
}

// ---------------------------------------------------------------------------
// Popup-open org sync: open the most recently used (LRU) org's calendar and
// make sure the user LANDS there. CourtReserve bounces logged-out users to
// its sign-in page, so watch the tab: if the post-login landing is the
// portal/root default instead of the calendar, route the tab to the calendar
// (CourtReserve often honors ReturnUrl and lands there on its own). Once the
// calendar is up, refresh the org's stored FILTER categories so the extension
// is fully initialized even though opening the tab closed the popup.
// ---------------------------------------------------------------------------

function calendarMonthUrl(orgId) {
  return `https://app.courtreserve.com/Online/Calendar/Events/${orgId}/Month`;
}

/** Active tabs first, then most recently active — "the tab the user is on". */
function sortTabsByRecency(tabs) {
  tabs.sort((a, b) => {
    if (!!a.active !== !!b.active) return a.active ? -1 : 1;
    return (b.lastAccessed || 0) - (a.lastAccessed || 0);
  });
  return tabs;
}

/** Bring a tab to the front (its window too). Best-effort. */
async function focusTab(tab) {
  try { await chrome.tabs.update(tab.id, { active: true }); } catch { /* gone */ }
  try { await chrome.windows.update(tab.windowId, { focused: true }); } catch { /* non-fatal */ }
}

function isOrgCalendarUrl(url, orgId) {
  const m = /\/Online\/Calendar\/Events\/(\d+)/.exec(url || '');
  return !!m && m[1] === String(orgId);
}

// CourtReserve's standard post-login destinations (when no ReturnUrl wins).
function isDefaultLandingUrl(url) {
  return /^https:\/\/app\.courtreserve\.com\/?([?#]|$)/.test(url || '') ||
    /\/Online\/(?:Portal|Home)\//.test(url || '');
}

/** Persist a fresh FILTER category list for the org (best-effort). */
async function refreshOrgCategories(tabId, orgId) {
  try {
    const res = await chrome.scripting.executeScript({
      target: { tabId },
      world: 'MAIN',
      func: readCalendarCategories,
    });
    const cats = (res && res[0] && res[0].result) || [];
    if (cats.length) {
      const data = await chrome.storage.local.get('orgCategories');
      const orgCategories = data.orgCategories || {};
      orgCategories[orgId] = cats;
      await chrome.storage.local.set({ orgCategories });
    }
  } catch { /* categories are best-effort here */ }
}

function watchCalendarLanding(tabId, orgId) {
  const deadline = Date.now() + 3 * 60 * 1000; // generous window to sign in
  let redirected = false; // take over the post-login landing at most once
  let done = false;

  function cleanup() {
    if (done) return;
    done = true;
    chrome.tabs.onUpdated.removeListener(onUpdated);
    chrome.tabs.onRemoved.removeListener(onRemoved);
  }
  function onRemoved(id) { if (id === tabId) cleanup(); }
  function onUpdated(id, info, tab) {
    if (done || id !== tabId) return;
    if (Date.now() > deadline) { cleanup(); return; }
    const url = info.url || (tab && tab.url) || '';
    if (!url) return; // cross-origin detour we can't see — keep waiting
    if (isOrgCalendarUrl(url, orgId)) {
      if (info.status === 'complete') {
        cleanup();
        // Let the FILTER panel render, then initialize the org's data.
        setTimeout(() => refreshOrgCategories(tabId, orgId), 2000);
      }
      return;
    }
    // This tab was opened FOR the calendar, so any portal/root landing before
    // reaching it is CourtReserve's own post-login default — reroute it once.
    // (Sign-in pages are left alone; the user needs them. Later navigations
    // are the user's own and are never hijacked.)
    if (!redirected && info.status === 'complete' && isDefaultLandingUrl(url)) {
      redirected = true;
      chrome.tabs.update(tabId, { url: calendarMonthUrl(orgId) }).catch(() => {});
    }
  }
  chrome.tabs.onUpdated.addListener(onUpdated);
  chrome.tabs.onRemoved.addListener(onRemoved);
}

async function openOrgCalendar(orgId) {
  orgId = String(orgId || '').trim();
  if (!/^\d+$/.test(orgId)) return;
  await chrome.storage.local.set({ lruOrg: { id: orgId, at: Date.now() } });
  const url = calendarMonthUrl(orgId);
  // Reuse any existing CourtReserve tab rather than stacking up calendar
  // tabs: navigate the one the user used most recently and bring it forward.
  const tabs = sortTabsByRecency(await chrome.tabs.query({ url: 'https://app.courtreserve.com/*' }));
  if (tabs.length) {
    const t = tabs[0];
    try { await chrome.tabs.update(t.id, { url, active: true }); } catch { /* gone */ }
    await focusTab(t);
    watchCalendarLanding(t.id, orgId);
    return;
  }
  const tab = await chrome.tabs.create({ url, active: true });
  watchCalendarLanding(tab.id, orgId);
}
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  (async () => {
    switch (msg.type) {
      case 'schedule': {
        if (!(await isPremium())) {
          sendResponse({ ok: false, premiumRequired: true });
          break;
        }
        await withEntryLock(async () => {
          const entry = msg.entry;
          entry.status = 'scheduled';
          entry.retryCount = 0;
          await CRLib.store.put(entry);
          if (entry.fireAt <= Date.now()) {
            await runEntry(entry);
          } else {
            await chrome.alarms.create(alarmName(entry.id), { when: entry.fireAt });
          }
        });
        sendResponse({ ok: true });
        break;
      }
      case 'cancel': {
        await withEntryLock(async () => {
          await chrome.alarms.clear(alarmName(msg.id));
          await CRLib.store.remove(msg.id);
        });
        sendResponse({ ok: true });
        break;
      }
      case 'heal': {
        // A calendar cell reports that its stored entry has a stale identity
        // or link (rotated token) or fire time — refresh it in place, merge
        // any duplicates of the same occurrence, and re-arm the alarm.
        await withEntryLock(async () => {
          const { oldId, entry } = msg;
          if (oldId && oldId !== entry.id) {
            await chrome.alarms.clear(alarmName(oldId));
            await chrome.alarms.clear(watchdogName(oldId));
            await CRLib.store.remove(oldId);
          }
          const existing = await CRLib.store.get(entry.id);
          if (existing) {
            entry.status = existing.status;
            entry.retryCount = existing.retryCount;
            entry.lastRun = existing.lastRun;
            entry.createdAt = existing.createdAt;
          }
          await CRLib.store.put(entry);
          await dedupeEntries(entry.id);
          if (entry.status === 'scheduled' || entry.status === 'retrying') {
            await chrome.alarms.clear(alarmName(entry.id));
            if (entry.fireAt <= Date.now()) {
              await runEntry(entry);
            } else {
              await chrome.alarms.create(alarmName(entry.id), { when: entry.fireAt });
            }
          }
        });
        sendResponse({ ok: true });
        break;
      }
      case 'runNow': {
        if (!(await isPremium())) {
          sendResponse({ ok: false, premiumRequired: true });
          break;
        }
        await withEntryLock(async () => {
          const entry = await CRLib.store.get(msg.id);
          if (entry) await runEntry(entry);
        });
        sendResponse({ ok: true });
        break;
      }
      case 'licenseStatus': {
        const lic = await CRLib.license.get();
        sendResponse({ ok: true, license: lic, premium: CRLib.license.isPremium(lic) });
        break;
      }
      case 'licenseActivate': {
        const result = await CRLib.license.activate(msg.key, msg.deviceName);
        if (result.ok) {
          await chrome.alarms.create(LICENSE_REVALIDATE, { periodInMinutes: 7 * 24 * 60 });
          await notify('🌟 Premium activated', 'Auto-Register is now unlocked on this browser.');
        }
        sendResponse(result);
        break;
      }
      case 'licenseDeactivate': {
        const result = await CRLib.license.deactivate();
        await chrome.alarms.clear(LICENSE_REVALIDATE);
        sendResponse(result);
        break;
      }
      case 'taskResult':
        await withEntryLock(() => handleResult(msg));
        sendResponse({ ok: true });
        break;
      case 'autofillStart':
        await startAutofill(msg.orgId, { allCategories: msg.all === true });
        sendResponse({ ok: true });
        break;
      case 'ensureProfile':
        // The popup asks for a profile fetch when viewing an org that has
        // none (throttled inside ensureProfile).
        ensureProfile(msg.orgId).catch(() => {});
        sendResponse({ ok: true });
        break;
      case 'initStart':
        await startInit();
        sendResponse({ ok: true });
        break;
      case 'openOrgCalendar':
        await openOrgCalendar(msg.orgId);
        sendResponse({ ok: true });
        break;
      case 'orgVisited': {
        // A user-driven calendar visit makes that org the LRU (automation-
        // opened tabs are filtered out by the content script).
        const id = String(msg.orgId || '').trim();
        if (/^\d+$/.test(id)) {
          await chrome.storage.local.set({ lruOrg: { id, at: Date.now() } });
        }
        sendResponse({ ok: true });
        break;
      }
      case 'calendarTarget': {
        // The calendar to send the user to (post-purchase success page): the
        // org of an open CourtReserve calendar tab — the one being viewed
        // first (active, then most recently active) — else the LRU org, else
        // the Primary / first learned org. Empty when nothing is known.
        let orgId = '';
        const calTabs = sortTabsByRecency(
          await chrome.tabs.query({ url: 'https://app.courtreserve.com/Online/Calendar/Events/*' }));
        for (const t of calTabs) {
          const m = /\/Online\/Calendar\/Events\/(\d+)/.exec(t.url || '');
          if (m) { orgId = m[1]; break; }
        }
        if (!orgId) {
          const data = await chrome.storage.local.get(['lruOrg', 'orgs']);
          const lru = data.lruOrg && /^\d+$/.test(String(data.lruOrg.id || '')) ? String(data.lruOrg.id) : '';
          if (lru) {
            orgId = lru;
          } else {
            const known = Array.isArray(data.orgs) ? data.orgs : [];
            const pick =
              known.find((o) => o.primary && /^\d+$/.test(String(o.id))) ||
              known.find((o) => /^\d+$/.test(String(o.id)));
            if (pick) orgId = String(pick.id);
          }
        }
        sendResponse({ ok: true, orgId });
        break;
      }
      case 'focusOrgCalendar': {
        // Post-purchase hand-off: land the user on an EXISTING CourtReserve
        // tab when one is open — the org's calendar tab first, any other
        // CourtReserve tab otherwise — instead of stacking another calendar
        // tab. A fragment-only URL change doesn't reload the page, so force a
        // reload: the content script must see the #crh-activate hash to show
        // the activation card.
        const orgId = String(msg.orgId || '').trim();
        if (!/^\d+$/.test(orgId)) { sendResponse({ ok: false }); break; }
        const hash = /^#crh-activate/.test(String(msg.hash || '')) ? String(msg.hash) : '';
        await chrome.storage.local.set({ lruOrg: { id: orgId, at: Date.now() } });
        const base = calendarMonthUrl(orgId);
        let tabs = sortTabsByRecency(
          await chrome.tabs.query({ url: `https://app.courtreserve.com/Online/Calendar/Events/${orgId}/*` }));
        if (!tabs.length) {
          tabs = sortTabsByRecency(await chrome.tabs.query({ url: 'https://app.courtreserve.com/*' }));
        }
        if (tabs.length) {
          const t = tabs[0];
          const samePage = (t.url || '').split('#')[0] === base;
          try { await chrome.tabs.update(t.id, { url: base + hash, active: true }); } catch { /* gone */ }
          if (samePage) { try { await chrome.tabs.reload(t.id); } catch { /* gone */ } }
          await focusTab(t);
        } else {
          await chrome.tabs.create({ url: base + hash, active: true });
        }
        sendResponse({ ok: true });
        break;
      }
      case 'autofillResult':
        await finishAutofill(msg);
        sendResponse({ ok: true });
        break;
      default:
        sendResponse({ ok: false, error: 'unknown message type' });
    }
  })();
  return true; // async sendResponse
});

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === INIT_WATCHDOG) {
    (async () => {
      const init = (await chrome.storage.local.get(INIT_KEY))[INIT_KEY];
      if (!init || !init.running) return; // finished already
      if (init.stage === 'autofill') return; // the autofill watchdog owns it from here
      await setInit({
        running: false, stage: 'done', ok: false, at: Date.now(),
        message: 'Setup timed out — you may be logged out of CourtReserve, or the page changed. Try again from the Setup tab.',
      });
      await notify('⚠ Setup incomplete', 'Timed out — log into CourtReserve and try again from the Setup tab.');
    })();
    return;
  }
  if (alarm.name.startsWith('autoreg:')) {
    withEntryLock(() => fireEntry(alarm.name.slice('autoreg:'.length)));
    return;
  }
  if (alarm.name.startsWith('watchdog:')) {
    const id = alarm.name.slice('watchdog:'.length);
    withEntryLock(async () => {
      // A pendingTask still sitting here means the tab flow never reported —
      // login redirect, unexpected page, or a killed script. Fail loudly so
      // the retry path (and ultimately a ❌ notification) takes over.
      const data = await chrome.storage.local.get('pendingTask');
      const task = data.pendingTask;
      if (!task || task.entryId !== id) return; // result already arrived
      await chrome.storage.local.remove('pendingTask');
      await handleResult({
        type: 'taskResult',
        entryId: id,
        ok: false,
        state: 'failed',
        message: 'No response from the registration tab within 3 minutes — you may be logged out of CourtReserve, or the page changed.',
      });
    });
    return;
  }
  if (alarm.name === LICENSE_REVALIDATE) {
    // Weekly: a cancelled/refunded subscription flips valid → false, which
    // locks premium until the customer renews.
    CRLib.license.validate().catch(() => {});
    return;
  }
  if (alarm.name === AUTOFILL_WATCHDOG) {
    (async () => {
      const data = await chrome.storage.local.get('pendingAutofill');
      if (!data.pendingAutofill) return; // result already arrived
      await finishAutofill({
        ok: false,
        orgId: data.pendingAutofill.orgId,
        message: 'No response from the calendar/details pages within 5 minutes — you may be logged out of CourtReserve, or the page structure changed.',
      });
    })();
  }
});

chrome.runtime.onStartup.addListener(() => { withEntryLock(catchUp); });
chrome.runtime.onInstalled.addListener(() => { withEntryLock(catchUp); updateBadge(); });
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local' && changes.entries) updateBadge();
});

// Service workers are ephemeral: run maintenance on every cold start (at most
// once every 5 minutes) so that merely reloading the extension re-arms alarms,
// merges duplicate entries, and reclaims stale runs.
(async function maintenanceOnWake() {
  try {
    const r = await chrome.storage.local.get('lastMaintenanceAt');
    if (r.lastMaintenanceAt && Date.now() - r.lastMaintenanceAt < 5 * 60 * 1000) return;
    await chrome.storage.local.set({ lastMaintenanceAt: Date.now() });
    await withEntryLock(catchUp);
    // Re-arm weekly license revalidation after any restart; revalidate now if
    // the last check is over a week old.
    const lic = await CRLib.license.get();
    if (lic && lic.key) {
      const existing = await chrome.alarms.get(LICENSE_REVALIDATE);
      if (!existing) await chrome.alarms.create(LICENSE_REVALIDATE, { periodInMinutes: 7 * 24 * 60 });
      if (Date.now() - (lic.lastCheckAt || 0) > 7 * 24 * 60 * 60 * 1000) {
        CRLib.license.validate().catch(() => {});
      }
    }
    // Wake backstop for rule drift: if a club changed its registration-window
    // rule, re-verify stale category rules while we're awake anyway. No-op
    // unless entries are due soon AND a rule is missing or >24h unverified.
    await withEntryLock(() => maybeValidateRules('wake'));
  } catch { /* maintenance is best-effort */ }
})();
