/* Court Helper for CourtReserve — background service worker.
   Schedules chrome.alarms per entry, runs ONE registration flow at a time
   (calendar TODAY refresh → details page), collects results, retries
   failures twice, and catches up missed entries at Chrome startup.

   All entry/queue mutations are serialized through withEntryLock: content
   scripts and the popup never write `entries` directly, so a single
   promise-chain lock here closes every read-modify-write race (e.g. two
   'heal' messages from one calendar scan clobbering each other's writes). */

importScripts('lib/crlib.js');

const RETRY_DELAY_MIN = 2;
const MAX_RETRIES = 2;
const STAGGER_MS = 15000;
/** If no result comes back within this window, the run is treated as failed
    (login redirect, unexpected page, killed script) instead of silently
    staying "scheduled" forever. */
const WATCHDOG_MIN = 3;
// A run whose content scripts stamped progressAt within this window is alive
// — the watchdog re-arms instead of failing it (prevents a duplicate retry
// when pages load slowly at the exact opening minute). Hard cap: no run may
// exceed MAX_RUN_AGE_MS total, heartbeat or not.
const HEARTBEAT_FRESH_MS = 90 * 1000;
const MAX_RUN_AGE_MS = 6 * 60 * 1000;
const AUTOFILL_WATCHDOG = 'watchdog:autofill';
const QUEUE_KEY = 'taskQueue';
const LICENSE_REVALIDATE = 'license:revalidate';

/** Premium gate: schedule/runNow/fireEntry require an active license. */
async function isPremium() {
  const lic = await CRLib.license.get();
  return CRLib.license.isPremium(lic);
}

function alarmName(id) { return 'autoreg:' + id; }
function watchdogName(id) { return 'watchdog:' + id; }

/** Promise-chain mutex. Only wrap outermost entry points — helpers called
    from inside a locked section (handleResult, dedupeEntries, fireEntry,
    runEntry, pumpQueue, startRun) must stay unwrapped or the chain deadlocks. */
let entryLock = Promise.resolve();
function withEntryLock(fn) {
  const run = entryLock.then(fn, fn);
  entryLock = run.catch(() => {});
  return run;
}

async function notify(title, message) {
  try {
    await chrome.notifications.create(undefined, {
      type: 'basic',
      iconUrl: 'icons/icon128.png',
      title,
      message,
      priority: 2,
    });
  } catch { /* notifications unavailable — non-fatal */ }
}

async function updateBadge() {
  const entries = await CRLib.store.list();
  const n = entries.filter((e) => e.status === 'scheduled').length;
  await chrome.action.setBadgeText({ text: n > 0 ? String(n) : '' });
  await chrome.action.setBadgeBackgroundColor({ color: '#d97706' });
}

// ---------------------------------------------------------------------------
// Run queue: exactly one registration flow is in flight at a time. Entries
// that fire while another run is active are queued (persisted in storage, so
// a service-worker restart cannot lose them) and started when the current
// run reports — success, failure, or watchdog timeout. The single global
// pendingTask slot can therefore never be overwritten by a simultaneous fire.
// ---------------------------------------------------------------------------

async function getQueue() {
  const r = await chrome.storage.local.get(QUEUE_KEY);
  return r[QUEUE_KEY] || [];
}

async function setQueue(q) {
  await chrome.storage.local.set({ [QUEUE_KEY]: q });
}

async function hasActiveRun() {
  const data = await chrome.storage.local.get('pendingTask');
  const t = data.pendingTask;
  if (!t) return false;
  // "Active" = within the watchdog window, OR still heartbeating (content
  // scripts stamp progressAt at each stage so a slow-but-alive run at the
  // opening minute is never mistaken for a dead one).
  if (Date.now() - t.startedAt <= (WATCHDOG_MIN + 0.5) * 60 * 1000) return true;
  return Date.now() - (t.progressAt || t.startedAt) <= HEARTBEAT_FRESH_MS;
}

let runStarting = false; // same-worker race guard (two alarms on the same tick)

async function startRun(entry) {
  // Re-validate against the store: the entry may have been removed or
  // completed while it sat in the queue.
  const fresh = await CRLib.store.get(entry.id);
  if (!fresh || fresh.status === 'done' || fresh.status === 'failed') return;
  entry = fresh;
  CRLib.log('run', 'Auto-Register', `${entry.event} — ${CRLib.abbrevDate(entry.date)}, ${entry.time}`, 'Firing');

  // Two-hop flow: land on the org's month calendar FIRST and let
  // content-calendar.js click the scheduler's TODAY button — that forces a
  // fresh server read, so the details page can't be a stale pre-open
  // snapshot (no Register button). The calendar script then forwards the tab
  // to the event's details URL with stage 'details'.
  const calendarUrl = `https://app.courtreserve.com/Online/Calendar/Events/${entry.orgId}/Month`;
  await chrome.storage.local.set({
    pendingTask: {
      entryId: entry.id,
      orgId: entry.orgId,
      detailsUrl: entry.detailsUrl,
      date: entry.date || '', // fire-time verify: derive the real rule from a countdown
      category: entry.category || '',
      startedAt: Date.now(),
      reloaded: false,
      stage: 'calendar',
    },
  });
  await chrome.alarms.create(watchdogName(entry.id), { delayInMinutes: WATCHDOG_MIN });
  // Quarantine window (v1.6.0): the fire flow's two-hop tab never touches the
  // user's own window. Active within the quarantine window so the page
  // renders (the new-UI TODAY navigation needs a live React app).
  const tab = await createAutomationTab(calendarUrl, true);
  // Remember the tab so handleResult can close it when the run ends — a
  // background-work tab must never be left behind (v1.5.27).
  await chrome.storage.local.set({ runTabId: tab.id });
}

async function runEntry(entry) {
  if (runStarting || (await hasActiveRun())) {
    const q = await getQueue();
    if (!q.some((e) => e.id === entry.id)) {
      q.push(entry);
      await setQueue(q);
    }
    return;
  }
  runStarting = true;
  try {
    await startRun(entry);
  } finally {
    runStarting = false;
  }
}

async function pumpQueue() {
  const q = await getQueue();
  if (!q.length) return;
  const next = q.shift();
  await setQueue(q);
  await startRun(next);
}

async function fireEntry(id) {
  const entry = await CRLib.store.get(id);
  if (!entry || entry.status === 'done' || entry.status === 'failed') return;
  if (!(await isPremium())) {
    CRLib.log('fail', 'Auto-Register', `${entry.event} — ${CRLib.abbrevDate(entry.date)}, ${entry.time}: Premium license is not active.`, 'Skipped');
    entry.status = 'failed';
    entry.lastRun = { at: Date.now(), ok: false, message: 'Premium license is not active.' };
    await CRLib.store.put(entry);
    await notify('🔒 Auto-Register skipped', `${entry.event} — ${CRLib.abbrevDate(entry.date)}, ${entry.time}\nPremium is not active on this browser.`);
    return;
  }
  await runEntry(entry);
}

async function handleResult(msg) {
  await chrome.storage.local.remove('pendingTask');
  await chrome.alarms.clear(watchdogName(msg.entryId));
  // Close the background-work tab this run opened — unless the user happened
  // to bring it to the front (don't yank a page someone is looking at).
  const rt = await chrome.storage.local.get('runTabId');
  await chrome.storage.local.remove('runTabId');
  if (rt.runTabId) await closeAutomationTab(rt.runTabId);
  const entry = await CRLib.store.get(msg.entryId);
  if (!entry) { await pumpQueue(); return; }

  // Atomicity guard: a completed run stays completed. A single run can send
  // TWO reports (the signup editor confirms, then the return navigation to
  // the details page reports again) — done entries are removed after 10 min,
  // so without this guard the second report would overwrite the log line and
  // fire a duplicate notification. A late SUCCESS for a failed entry is
  // still honored (the registration really did happen).
  if (entry.status === 'done') return;
  if (entry.status === 'failed' && !msg.ok) return;

  entry.lastRun = { at: Date.now(), ok: msg.ok, message: msg.message };

  if (msg.ok) {
    entry.status = 'done';
    CRLib.log('ok', 'Auto-Register',
      `${entry.event} — ${CRLib.abbrevDate(entry.date)}, ${entry.time}: ${msg.message}`,
      msg.state === 'waitlisted' ? 'Waitlisted' : 'Registered');
    await CRLib.store.put(entry);
    await chrome.alarms.clear(alarmName(entry.id));
    await notify(
      msg.state === 'waitlisted' ? '⏳ Auto-Register: waitlisted' : '✅ Auto-Register: registered',
      `${entry.event} — ${CRLib.abbrevDate(entry.date)}, ${entry.time}\n${msg.message}`,
    );
    // keep done entries briefly for the popup, then clean
    setTimeout(() => CRLib.store.remove(entry.id), 10 * 60 * 1000);
    await pumpQueue();
    // Post-fire piggyback: the browser is already awake and on CourtReserve,
    // so re-verify any stale window rules now — no extra wake needed.
    await maybeValidateRules('post-fire');
    return;
  }

  // Fire-time verify: the details page still showed a countdown — the stored
  // window rule was wrong (the club changed it). Reschedule to the REAL
  // opening moment and refresh the category rule. Not a failure: the retry
  // count stays where it is.
  if (msg.state === 'rescheduled' && typeof msg.newFireAt === 'number' && msg.newFireAt > Date.now()) {
    entry.fireAt = msg.newFireAt;
    entry.status = 'scheduled';
    CRLib.log('info', 'Auto-Register',
      `${entry.event} — ${CRLib.abbrevDate(entry.date)}, ${entry.time}: ${msg.message}`, 'Rescheduled');
    await CRLib.store.put(entry);
    await chrome.alarms.clear(alarmName(entry.id));
    await chrome.alarms.create(alarmName(entry.id), { when: entry.fireAt });
    if (msg.rule && msg.category) {
      await saveCategoryRule(entry.orgId, msg.category, msg.rule);
      // Other scheduled entries of this category fire at the old moment too —
      // recompute them against the corrected rule.
      await healScheduledEntries();
    }
    await notify('🕐 Auto-Register rescheduled',
      `${entry.event} — ${CRLib.abbrevDate(entry.date)}, ${entry.time}\n${msg.message}`);
    await pumpQueue();
    return;
  }

  entry.retryCount = (entry.retryCount || 0) + 1;
  // 'ineligible' (rating-blocked) is terminal — retrying cannot change it.
  if (entry.retryCount <= MAX_RETRIES && msg.state !== 'ineligible') {
    entry.status = 'retrying';
    CRLib.log('warn', 'Auto-Register',
      `${entry.event} — attempt ${entry.retryCount}/${MAX_RETRIES}: ${msg.message}`, 'Retrying');
    await CRLib.store.put(entry);
    await chrome.alarms.create(alarmName(entry.id), { when: Date.now() + RETRY_DELAY_MIN * 60 * 1000 });
    await notify('🔁 Auto-Register retry scheduled',
      `${entry.event} — ${CRLib.abbrevDate(entry.date)}, ${entry.time}\n${msg.message}\nRetry ${entry.retryCount}/${MAX_RETRIES} in ${RETRY_DELAY_MIN} min.`);
  } else {
    entry.status = 'failed';
    CRLib.log('fail', 'Auto-Register', `${entry.event} — ${CRLib.abbrevDate(entry.date)}, ${entry.time}: ${msg.message}`, 'Failed');
    await CRLib.store.put(entry);
    await notify('❌ Auto-Register failed',
      `${entry.event} — ${CRLib.abbrevDate(entry.date)}, ${entry.time}\n${msg.message}`);
  }
  await pumpQueue();
}

// ---------------------------------------------------------------------------
// Rule validation: clubs sometimes change their registration-window rules
// (e.g. a seasonal shift), and the extension is never told. Three safety nets
// keep scheduled entries accurate without any nightly wake:
//   1. FIRE-TIME VERIFY  — a run that finds no Register button but a live
//      "Registration opens in …" countdown reschedules itself to the real
//      opening moment and refreshes the category rule (handled above).
//   2. POST-FIRE PIGGYBACK — after any successful registration, re-verify
//      stale rules while the browser is already on CourtReserve.
//   3. WAKE BACKSTOP — every service-worker cold start (≥5 min apart) also
//      checks staleness, so rule drift is caught within ~a day of use.
// A rule is stale when it is missing or its validatedAt is >24h old
// (CRLib.categoriesNeedingValidation). Validation reuses the Auto Fill
// machinery silently (no tabs in front, no notification unless a rule moved).
// ---------------------------------------------------------------------------

/** Persist a freshly read window rule for one category (org override). */
async function saveCategoryRule(orgId, category, rule, validatedAt) {
  const s = await CRLib.settings.load();
  const perOrg = {};
  Object.keys(s.perOrg || {}).forEach((k) => { perOrg[k] = s.perOrg[k]; });
  const existing = perOrg[orgId] || {};
  const categoryWindows = { ...(existing.categoryWindows || {}) };
  categoryWindows[category] = {
    daysBefore: rule.daysBefore,
    openTime: rule.openTime,
    validatedAt: typeof validatedAt === 'number' ? validatedAt : Date.now(),
  };
  perOrg[orgId] = { ...existing, categoryWindows };
  await CRLib.settings.save({
    daysBefore: s.daysBefore, openTime: s.openTime, eventFilter: s.eventFilter,
    eventFilterMode: s.eventFilterMode, eventFilterColor: s.eventFilterColor,
    eventFilterCategories: s.eventFilterCategories,
    perOrg, fireDelaySeconds: s.fireDelaySeconds,
    showAutoRegButtons: s.showAutoRegButtons,
    showOpensIndicator: s.showOpensIndicator === true,
  });
}

/**
 * Recompute fireAt for every scheduled entry from the CURRENT rules. Called
 * after a rule changed (fire-time reschedule or a silent validation that
 * found a moved window) so sibling entries of the same category don't keep
 * firing at the old moment. Only entries carrying a category heal precisely;
 * category-less entries rely on the calendar scan's own heal pass.
 */
async function healScheduledEntries() {
  const entries = await CRLib.store.list();
  let healed = 0;
  for (const e of entries) {
    if (e.status !== 'scheduled' && e.status !== 'retrying') continue;
    if (!e.category) continue;
    const eventDate = CRLib.parseLongDate(e.date);
    if (!eventDate) continue;
    const s = await CRLib.settings.forOrg(e.orgId);
    const fireAt = CRLib.fireTime(eventDate, s, e.category).getTime();
    if (fireAt === e.fireAt) continue;
    e.fireAt = fireAt;
    healed++;
    await CRLib.store.put(e);
    await chrome.alarms.clear(alarmName(e.id));
    if (fireAt <= Date.now()) {
      // The corrected window is already open (or opening within the delay) —
      // run it now; the Register button should be there.
      await runEntry(e);
    } else {
      await chrome.alarms.create(alarmName(e.id), { when: fireAt });
    }
  }
  return healed;
}

/**
 * If any org with a scheduled entry due within 10 days has a selected
 * category whose window rule is missing or stale, kick off ONE silent
 * revalidation for it. No-op while a registration or another validation is
 * in flight, and when nothing needs checking — so this costs nothing on
 * ordinary wakes.
 */
async function maybeValidateRules(reason) {
  try {
    const data = await chrome.storage.local.get(['pendingAutofill', 'pendingTask']);
    if (data.pendingAutofill || data.pendingTask) return; // one flow at a time
    const entries = await CRLib.store.list();
    const horizon = Date.now() + 10 * 24 * 60 * 60 * 1000;
    const orgIds = {};
    for (const e of entries) {
      if (e.status !== 'scheduled' || typeof e.fireAt !== 'number' || e.fireAt > horizon) continue;
      orgIds[e.orgId] = true;
    }
    for (const orgId of Object.keys(orgIds)) {
      const s = await CRLib.settings.forOrg(orgId);
      if (CRLib.categoriesNeedingValidation(s).length) {
        await startAutofill(orgId, { silent: true, revalidate: true });
        return; // one org per pass; the next wake/success covers the rest
      }
    }
  } catch { /* rule validation is best-effort */ }
}

/**
 * One entry per occurrence. Identity is org + event + date + time
 * (CRLib.entryKey); CourtReserve rotates its Details-link tokens, so before
 * this rule the same event could be scheduled twice under different ids.
 * Keeps preferId when given, else the most recently created entry (the newer
 * the entry, the fresher its link), and clears alarms/storage for the rest.
 */
async function dedupeEntries(preferId) {
  const entries = await CRLib.store.list();
  const groups = {};
  for (const e of entries) {
    const key = CRLib.entryKey(e.orgId, e);
    (groups[key] = groups[key] || []).push(e);
  }
  for (const key of Object.keys(groups)) {
    const group = groups[key];
    if (group.length < 2) continue;
    let keep = preferId ? group.find((e) => e.id === preferId) : null;
    if (!keep) {
      keep = group.slice().sort((a, b) =>
        String(b.createdAt || '').localeCompare(String(a.createdAt || '')))[0];
    }
    for (const e of group) {
      if (e.id === keep.id) continue;
      await chrome.alarms.clear(alarmName(e.id));
      await chrome.alarms.clear(watchdogName(e.id));
      await CRLib.store.remove(e.id);
    }
  }
}

async function catchUp() {
  // Reclaim a run left in flight by a browser/service-worker restart.
  const ptData = await chrome.storage.local.get('pendingTask');
  const pt = ptData.pendingTask;
  if (pt && Date.now() - pt.startedAt > (WATCHDOG_MIN + 0.5) * 60 * 1000 &&
      Date.now() - (pt.progressAt || pt.startedAt) > HEARTBEAT_FRESH_MS) {
    await chrome.storage.local.remove('pendingTask');
    await handleResult({
      type: 'taskResult', entryId: pt.entryId, ok: false, state: 'failed',
      message: 'The browser restarted while a registration was in progress.',
    });
  }

  // Merge duplicate entries for the same occurrence before re-arming alarms.
  await dedupeEntries(null);

  const entries = await CRLib.store.list();
  const now = Date.now();
  let stagger = 0;
  for (const e of entries) {
    if (e.status === 'done' || e.status === 'failed') continue;
    if (e.fireAt <= now) {
      setTimeout(() => fireEntry(e.id), stagger);
      stagger += STAGGER_MS;
    } else {
      await chrome.alarms.create(alarmName(e.id), { when: e.fireAt });
    }
  }

  // Drain any queued runs left over from before the restart.
  const queued = await getQueue();
  if (queued.length) {
    await setQueue([]);
    for (const e of queued) {
      setTimeout(() => fireEntry(e.id), stagger);
      stagger += STAGGER_MS;
    }
  }
}

// ---------------------------------------------------------------------------
// Auto Fill: derive the registration-window rule from a live details page.
// Flow: popup starts it → we open the org's month calendar → content-calendar
// picks a not-yet-open event matching the keyword filter and follows its
// Details link → content-details reads "Registration opens in …", computes
// daysBefore/openTime, saves them, and reports back via 'autofillResult'.
// ---------------------------------------------------------------------------

async function startAutofill(orgIdHint, opts) {
  const hinted = /^\d+$/.test(String(orgIdHint || '').trim());
  // One run at a time: a second start clobbers pendingAutofill/autofillTabId
  // mid-run — the first run's chain then drives (and finishAutofill closes)
  // the SECOND run's tab, and vice versa (Sep 24: two starts a minute apart;
  // the tab the user was watching got closed by the other run's finish).
  const inflight = (await chrome.storage.local.get('pendingAutofill')).pendingAutofill;
  if (inflight && Date.now() - (inflight.startedAt || 0) < 5 * 60 * 1000) {
    CRLib.log('warn', 'Detect registration window',
      'A detection run is already in progress — let it finish (or wait 5 minutes) before starting another.',
      'Busy');
    return;
  }
  let orgId = hinted ? String(orgIdHint).trim() : '';
  if (!orgId) {
    // Fall back to the org of an already-open CourtReserve calendar tab (the
    // user's own tabs only — never an automation tab).
    const tabs = await queryUserTabs({ url: 'https://app.courtreserve.com/Online/Calendar/Events/*' });
    for (const t of tabs) {
      const m = /\/Online\/Calendar\/Events\/(\d+)/.exec(t.url || '');
      if (m) { orgId = m[1]; break; }
    }
  }
  if (!orgId) {
    // Last resort: a previously learned org, preferring the one CourtReserve
    // marks as Primary in the "My Clubs" menu.
    const data = await chrome.storage.local.get('orgs');
    const known = Array.isArray(data.orgs) ? data.orgs : [];
    const pick = known.find((o) => o.primary) || known[0];
    if (pick && /^\d+$/.test(String(pick.id))) orgId = String(pick.id);
  }
  if (!orgId) {
    // Nothing learned yet and no calendar tab open — fail with guidance
    // instead of guessing an org id.
    CRLib.log('fail', 'Detect registration window', 'No organization known — open your club\u2019s CourtReserve calendar once, then retry.', 'Failed');
    await chrome.storage.local.set({
      autofillResult: {
        ok: false,
        message: 'No organization known yet — open your club\u2019s CourtReserve calendar once, then retry.',
        orgId: '',
        at: Date.now(),
      },
    });
    return;
  }
  await chrome.storage.local.remove('autofillResult');
  // Arm the watchdog FIRST: the profile fetch below can take ~30s and the
  // service worker can be killed mid-wait — with no alarm armed, a first-run
  // init waiting on this Auto Fill would wedge in the 'autofill' stage.
  await chrome.alarms.create(AUTOFILL_WATCHDOG, { delayInMinutes: 5 }); // multi-category loop, up to 6 attempts
  // Quarantine window (v1.6.0): the run tab is ACTIVE inside the dedicated
  // unfocused automation window. The new-UI calendar's grid render waits on
  // rAF/idle callbacks that Chrome suspends in HIDDEN tabs — a hidden autofill
  // tab sat on calendar-grid-skeleton forever (Sep 24, PZB org 2151) — but an
  // active tab in an unfocused window renders normally, and the user's own
  // window never loses focus. (v1.6.2 shrank/parked the window bottom-right.)
  // The flow navigates this tab to Details pages anyway, and finishAutofill
  // closes it.
  const calUrl = `https://app.courtreserve.com/Online/Calendar/Events/${orgId}/Month`;
  const tab = await createAutomationTab(calUrl, true);
  await chrome.storage.local.set({
    pendingAutofill: {
      orgId,
      // An explicit Org ID targets that org (saved as an override); a plain
      // Auto Fill updates the global rule the user sees in the fields above.
      saveAs: hinted ? 'override' : 'global',
      stage: 'scan',
      startedAt: Date.now(),
      // Silent revalidation (rule-drift safety net): also re-check rules that
      // are merely STALE, and stay quiet unless a rule actually moved.
      revalidate: !!(opts && opts.revalidate),
      silent: !!(opts && opts.silent),
      // Auto-triggered (category pick / popup logic) vs a manual Detect click
      // — auto failures count toward the popup's daily pause cap (v1.6.2).
      auto: !!(opts && opts.auto),
    },
    autofillTabId: tab.id,
  });
  CRLib.log('run', 'Detect registration window', `Scanning org ${orgId} for registration windows${hinted ? ' (org override)' : ''}.`, 'Started');
  // Redirect guard (Sep 24, PZB org 2151): CourtReserve's SPA can bounce a
  // fresh calendar tab to /Online/MyProfile/MyProfile/{org} (forced profile
  // completion / re-login), which leaves the scan staring at a non-calendar
  // page. Check the tab's URL once it has had time to settle; on a bounce,
  // log it and navigate the SAME tab back to the calendar (one retry — if the
  // site bounces it again, the watchdog reports the failure).
  // v1.5.39: the check must tolerate running LATE — MV3 service-worker timers
  // are not exact, and on Sep 25 this guard fired ~60 s in, AFTER the scan
  // stage had already navigated the tab to a candidate's Details page; the
  // guard "corrected" the run's own navigation back to the calendar and the
  // run died stranded on stage 'details'. Skip the bounce whenever the tab is
  // on a page the run itself navigates to (Details / SignUpToEvent) or the
  // pending run has left the scan stage — only a genuine off-flow bounce
  // (MyProfile, login) with the run still in 'scan' gets corrected.
  await new Promise((r) => setTimeout(r, 8000));
  try {
    const cur = await chrome.tabs.get(tab.id);
    const u = (cur && cur.url) || '';
    const runNav = u.indexOf('/Online/Events/Details/') !== -1 ||
      u.indexOf('/Online/Events/SignUpToEvent/') !== -1;
    const st = await chrome.storage.local.get('pendingAutofill');
    const stage = (st.pendingAutofill && st.pendingAutofill.stage) || null;
    if (u && u.indexOf('/Online/Calendar/Events/') === -1 && !runNav && stage === 'scan') {
      CRLib.log('warn', 'Detect registration window',
        `CourtReserve redirected the calendar tab to ${u} — it may be forcing profile completion or re-login. Navigating back to the calendar once.`,
        'Redirected');
      await chrome.tabs.update(tab.id, { url: calUrl });
    }
  } catch { /* tab closed by the user — the watchdog reports the stalled run */ }
  // v1.6.2: no background profile fetch here — Gender/Rating are user-entered
  // in Settings (manual entry) and passively scraped when the user visits My
  // Profile; detection runs no longer open a profile tab.
}

async function finishAutofill(msg) {
  const afData = await chrome.storage.local.get(['pendingAutofill', 'autofillTabId']);
  const pa = afData.pendingAutofill || null;
  const tabId = afData.autofillTabId || null;
  await chrome.storage.local.remove(['pendingAutofill', 'autofillTabId']);
  await chrome.alarms.clear(AUTOFILL_WATCHDOG);
  // The run tab lives in the unfocused quarantine window — close it unless the
  // user deliberately brought that window to the front to watch.
  if (tabId) await closeAutomationTab(tabId);
  await chrome.storage.local.set({
    autofillResult: {
      ok: !!msg.ok,
      message: msg.message || '',
      orgId: msg.orgId || '',
      at: Date.now(),
    },
  });
  // If a first-run init is waiting on this Auto Fill, it ends here.
  const initData = await chrome.storage.local.get(INIT_KEY);
  const init = initData[INIT_KEY];
  if (init && init.running && init.stage === 'autofill') {
    await chrome.storage.local.set({
      [INIT_KEY]: {
        running: false, stage: 'done', orgId: init.orgId, ok: !!msg.ok,
        message: msg.message || '', at: Date.now(),
      },
    });
  }
  // v1.6.2 daily cap: an AUTO-triggered run that failed increments the org's
  // daily failure counter — the popup pauses auto-detection after 3.
  if (pa && pa.auto && !msg.ok && pa.orgId) {
    const d = await chrome.storage.local.get('autofillAutoFails');
    const fails = d.autofillAutoFails || {};
    const today = new Date().toDateString();
    const cur = fails[pa.orgId];
    fails[pa.orgId] = {
      day: today,
      count: (cur && cur.day === today ? (cur.count || 0) : 0) + 1,
    };
    await chrome.storage.local.set({ autofillAutoFails: fails });
  }
  if (pa && pa.silent) {
    // Silent rule validation: no fanfare when everything still matches, and
    // failures stay quiet too (the next wake retries). Only a rule that
    // actually MOVED earns a notification — and a re-heal of every scheduled
    // entry so they fire at the corrected moment.
    if (msg.ok && msg.changed) {
      CRLib.log('info', 'Check registration open time', msg.message || 'A club changed a registration window.', 'Window updated');
      await withEntryLock(healScheduledEntries);
      await notify('🔄 Registration window changed',
        (msg.message || 'A club changed a registration window.') +
        '\nYour scheduled auto-registrations were updated to the new times.');
    }
    return;
  }
  CRLib.log(msg.ok ? 'ok' : 'fail', 'Detect registration window', msg.message || '', msg.ok ? 'Done' : 'Failed');
  await notify(
    msg.ok ? '✨ Auto Fill: registration window detected' : '⚠ Auto Fill failed',
    msg.message || '',
  );
}

// ---------------------------------------------------------------------------
// First-run initialization ("Detect my club & settings" on the Setup tab).
// Chains existing pieces: find the user's main org (Primary badge from the
// learned "My Clubs" list, else an org id in any open CourtReserve tab) →
// load that org's calendar FILTER categories → run Auto Fill to derive the
// registration-window rule. Progress lives in storage key INIT_KEY so the
// popup can render it (and survives the popup closing).
// ---------------------------------------------------------------------------

const INIT_KEY = 'initState';
const INIT_WATCHDOG = 'watchdog:init';

async function setInit(patch) {
  const data = await chrome.storage.local.get(INIT_KEY);
  await chrome.storage.local.set({ [INIT_KEY]: { ...(data[INIT_KEY] || {}), ...patch } });
}

function orgIdFromUrl(url) {
  const m =
    /\/Online\/(?:Calendar\/Events|Portal\/Index)\/(\d+)/.exec(url || '') ||
    /\/Online\/Events\/Details\/(\d+)\//.exec(url || '');
  return m ? m[1] : '';
}

/** Main org: the one CourtReserve marks Primary, else any org id visible in
    an open CourtReserve tab, else the first learned org. */
async function findMainOrgId() {
  const data = await chrome.storage.local.get('orgs');
  const known = Array.isArray(data.orgs) ? data.orgs : [];
  const primary = known.find((o) => o.primary && /^\d+$/.test(String(o.id)));
  if (primary) return String(primary.id);
  const tabs = await chrome.tabs.query({ url: 'https://app.courtreserve.com/*' });
  for (const t of tabs) {
    const id = orgIdFromUrl(t.url);
    if (id) return id;
  }
  const first = known.find((o) => /^\d+$/.test(String(o.id)));
  return first ? String(first.id) : '';
}

/** Resolve when the tab finishes loading (or the timeout hits). */
function waitForTabComplete(tabId, timeoutMs) {
  return new Promise((resolve) => {
    let done = false;
    const timer = setTimeout(() => finish(false), timeoutMs || 15000);
    function finish(ok) {
      if (done) return;
      done = true;
      clearTimeout(timer);
      chrome.tabs.onUpdated.removeListener(listener);
      resolve(ok);
    }
    function listener(id, info) { if (id === tabId && info.status === 'complete') finish(true); }
    chrome.tabs.onUpdated.addListener(listener);
  });
}

// ---------------------------------------------------------------------------
// Automation quarantine window (v1.6.0): every background-work tab the
// extension opens now lives in ONE dedicated window that is NEVER focused.
// Background tabs used to be created inside the user's own window, where they
// could steal focus — or the user clicked into one mid-run and the flow broke
// (the Sep 27 complaint). A tab that is ACTIVE inside an unfocused window is
// still "visible" to Chrome, so its rAF/render pipeline runs and the new-UI
// React calendar grid paints there; tabs created inactive inside that window
// behave like the old hidden background tabs. If the user closes the window,
// the next automation quietly recreates it.
// ---------------------------------------------------------------------------
const QUARANTINE_WINDOW_KEY = 'crAutomationWindowId';

/** The quarantine window's id, or null when it no longer exists (stale ids
    are cleaned out of storage as a side effect). */
async function getQuarantineWindowId() {
  const data = await chrome.storage.local.get(QUARANTINE_WINDOW_KEY);
  const id = data[QUARANTINE_WINDOW_KEY];
  if (typeof id !== 'number') return null;
  try {
    await chrome.windows.get(id);
    return id;
  } catch {
    await chrome.storage.local.remove(QUARANTINE_WINDOW_KEY);
    return null;
  }
}

chrome.windows.onRemoved.addListener(async (windowId) => {
  try {
    const data = await chrome.storage.local.get(QUARANTINE_WINDOW_KEY);
    if (data[QUARANTINE_WINDOW_KEY] === windowId) {
      await chrome.storage.local.remove(QUARANTINE_WINDOW_KEY);
    }
  } catch { /* storage best-effort */ }
});

/** Open an automation tab inside the quarantine window (created on demand,
    focused:false so the user is never torn away from their own window).
    `active` = make the tab active WITHIN the quarantine window — needed when
    the page must render (the React month grid suspends rAF in hidden tabs);
    plain reads (profile, FILTER panel, Events → List) pass false, matching
    the old active:false background-tab behavior.
    v1.6.2: the window is small-ish and parked in the bottom-right corner of
    the user's current window — mostly tucked out of the way, but never fully
    occluded/offscreen, which could throttle rendering.
    v1.6.3: width must stay ABOVE 1200px — at <=1200px CourtReserve serves its
    MOBILE shell (no calendar FILTER drawer; the Events → List page hides its
    filter sidebar <=768px and renders a different accordion 769–1200px),
    which silently broke the Path B category read (Oct 5: 760px window →
    "Categories group found but no colored-bar rows"). */
async function createAutomationTab(url, active) {
  const winId = await getQuarantineWindowId();
  if (winId !== null) {
    try {
      return await chrome.tabs.create({ windowId: winId, url, active: !!active });
    } catch { /* window vanished mid-call — recreate below */ }
  }
  const W = 1240, H = 560; // >1200px wide = CourtReserve desktop shell
  let left = 80, top = 60;
  try {
    const ref = await chrome.windows.getLastFocused();
    if (ref && typeof ref.left === 'number' && typeof ref.width === 'number') {
      left = Math.max(0, ref.left + ref.width - W - 24);
      top = Math.max(0, (typeof ref.top === 'number' ? ref.top : 0) +
        (typeof ref.height === 'number' ? ref.height : 800) - H - 24);
    }
  } catch { /* fall back to the fixed corner */ }
  const win = await chrome.windows.create({
    url, focused: false, width: W, height: H, left, top,
  });
  if (win && typeof win.id === 'number') {
    await chrome.storage.local.set({ [QUARANTINE_WINDOW_KEY]: win.id });
  }
  return win && win.tabs && win.tabs[0];
}

/** Close a tab an automation run opened. A tab in the quarantine window is
    closed even when it is that window's active tab (nobody is watching an
    unfocused window) — unless the user has actually brought the quarantine
    window to the front. A tab anywhere else follows the old rule: close only
    when it is not the foreground tab. */
async function closeAutomationTab(tabId) {
  if (!tabId) return;
  try {
    const t = await chrome.tabs.get(tabId);
    if (!t) return;
    const qw = await getQuarantineWindowId();
    if (qw !== null && t.windowId === qw) {
      const w = await chrome.windows.get(t.windowId);
      if (w && w.focused) return; // the user is watching the quarantine window
      await chrome.tabs.remove(tabId);
      return;
    }
    if (!t.active) await chrome.tabs.remove(tabId);
  } catch { /* tab already gone */ }
}

/** chrome.tabs.query minus the quarantine window's tabs — user-facing surveys
    (org detection, "reuse an open CourtReserve tab") must never pick up an
    automation tab; that was the v1.5.28 "wrong org wins" class of bug. */
async function queryUserTabs(queryInfo) {
  const tabs = await chrome.tabs.query(queryInfo);
  const qw = await getQuarantineWindowId();
  if (qw === null) return tabs;
  return tabs.filter((t) => t.windowId !== qw);
}

// ---------------------------------------------------------------------------
// Player profile (v1.5.18, revised v1.6.2/1.6.3): the My Profile page carries
// the user's Gender and rating(s) per organization — the yardstick for the
// Rating/Gender Restriction blocks on event details pages. Profile data is
// USER-ENTERED in Settings (manual values always win); content-profile.js
// passively scrapes when the user visits My Profile (fill-blanks only).
// Nothing in the background reads the profile page anymore (v1.6.2 removed
// the background fetcher; v1.6.3 removed the club-setup profile phase).
// ---------------------------------------------------------------------------

// Runs in the calendar page's MAIN world. Must be fully self-contained.
// Same reader the popup uses for the FILTER panel category list — keep the
// two copies in sync. Returns { cats: [{name, color}], diag, notes }. Two
// FILTER UIs exist in the wild: OLD (.left-filter-nav, rows are
// .custom-checkbox.rowCheckbox with a .categ-line-color swatch) and NEW
// (React "Filter Events" drawer — collapsed dropdown
// data-testid="calendar-filter-categories-header", plain checkbox rows with
// no swatch, "Show all (N)" cascade; colors come from the page's own
// category API).
async function readCalendarCategories() {
  var SEL = '.custom-checkbox.rowCheckbox';
  // Matches the calendar drawer's calendar-filter-categories-header AND the
  // Events → List page's equivalent filter dropdown (same component,
  // different testid prefix) — the List page rows carry colored bars, so it
  // is the color-true source for orgs on the new UI.
  var HDR = '[data-testid*="filter-categories-header"]';
  var sleep = function (ms) { return new Promise(function (r) { setTimeout(r, ms); }); };
  var poll = async function (sel, ms, step, scope) {
    var root = scope || document;
    var found = root.querySelectorAll(sel);
    var deadline = Date.now() + ms;
    while (!found.length && Date.now() < deadline) {
      await sleep(step || 400);
      found = root.querySelectorAll(sel);
    }
    return found;
  };
  // Normalize any color (hex, named) to the browser's rgb() form — calendar
  // cells carry inline backgrounds in that form and matching compares strings.
  var normColor = function (c) {
    if (!c) return '';
    if (/transparent|rgba\(\s*0\s*,\s*0\s*,\s*0\s*,\s*0\s*\)/i.test(c)) return '';
    var d = document.createElement('div');
    d.style.backgroundColor = c;
    return d.style.backgroundColor || c;
  };
  // Cascading "show more / show all / +N more" reveal: click while countFn grows.
  var clickReveal = async function (scope, countFn, notes) {
    for (var round = 0; round < 5; round++) {
      var reveal = null;
      var cands = scope.querySelectorAll('button, a, span, div, p');
      for (var i = 0; i < cands.length; i++) {
        var t = (cands[i].textContent || '').trim();
        if (t.length < 40 && cands[i].offsetParent !== null &&
            (/^(show|view|see)\b.*\b(all|more)\b/i.test(t) || /^\+\s*\d+\s*more$/i.test(t))) {
          reveal = cands[i]; break;
        }
      }
      if (!reveal) return;
      var before = countFn();
      reveal.click();
      notes.push("clicked '" + (reveal.textContent || '').trim().slice(0, 24) + "'");
      await sleep(700);
      if (countFn() <= before) return;
    }
  };
  // The new drawer shows no swatches — recover category colors from the API
  // response the drawer itself fetched (same-origin, session cookies).
  var apiColors = async function () {
    try {
      var urls = [];
      performance.getEntriesByType('resource').forEach(function (e) {
        if (/categor/i.test(e.name) && urls.indexOf(e.name) === -1) urls.push(e.name);
      });
      var best = null, bestN = 0;
      for (var i = 0; i < urls.length; i++) {
        var j = await (await fetch(urls[i], { credentials: 'include' })).json().catch(function () { return null; });
        if (!j) continue;
        var candidates = [j, j.data, j.Data, j.categories, j.Categories, j.value];
        for (var c = 0; c < candidates.length; c++) {
          var arr = candidates[c];
          if (!Array.isArray(arr)) continue;
          var map = {}, n = 0;
          arr.forEach(function (it) {
            if (!it || typeof it !== 'object') return;
            var name = it.name || it.Name || it.categoryName || it.CategoryName || it.label || it.text;
            var col = it.color || it.Color || it.categoryColor || it.CategoryColor || it.hexColor || it.backgroundColor;
            if (name && col) { map[String(name).trim()] = normColor(String(col)); n++; }
          });
          if (n > bestN) { bestN = n; best = map; }
        }
      }
      return best;
    } catch (e) { return null; }
  };
  var fingerprint = function (notes) {
    var drawer = document.querySelector('.left-filter-nav') || document.body;
    var hdr = document.querySelector(HDR);
    var boxes = drawer.querySelectorAll('input[type="checkbox"]');
    var sample = '';
    if (boxes.length) {
      var row = boxes[0].closest('label') || boxes[0].parentElement;
      sample = (row && row.outerHTML ? row.outerHTML : '').replace(/\s+/g, ' ').slice(0, 220);
    }
    var testids = [];
    var tids = document.querySelectorAll('[data-testid]');
    for (var j = 0; j < Math.min(tids.length, 8); j++) testids.push(tids[j].getAttribute('data-testid'));
    var navKids = [];
    var nav = document.querySelector('[data-testid="calendar-nav-group"]');
    if (nav) {
      var nk = nav.querySelectorAll('[data-testid], button, a');
      for (var n = 0; n < Math.min(nk.length, 10); n++) {
        navKids.push(nk[n].getAttribute('data-testid') || (nk[n].textContent || '').trim().slice(0, 20));
      }
    }
    return notes + ' | categories-header: ' + (hdr ? 'yes' : 'no') +
      ', checkboxes on page: ' + boxes.length +
      (sample ? ', first row: ' + sample : '') +
      (testids.length ? ', testids: [' + testids.join(', ') + ']' : '') +
      (navKids.length ? ', nav-group: [' + navKids.join(', ') + ']' : '');
  };
  try {
    var notes = [];
    // --- Open the FILTER drawer (whichever UI this org has) ---
    var rows = document.querySelectorAll(SEL);
    if (!rows.length && !document.querySelector(HDR)) {
      if (typeof openLeftNav === 'function') {
        openLeftNav(); // OLD UI: render/open the left filter nav
        notes.push('opened drawer');
        rows = await poll(SEL, 4000);
      }
      if (!rows.length && !document.querySelector(HDR)) {
        // NEW UI: the "Filter Events" drawer opens ONLY via the calendar's
        // FILTER button — openLeftNav does not exist on these pages.
        var fbtn = null;
        var bc = document.querySelectorAll('button, a, [role="button"]');
        for (var f = 0; f < bc.length; f++) {
          var ft = (bc[f].textContent || '').trim();
          // "Filter", or "Filter (N)" once a filter is active (Oct 5: the
          // count badge made the exact-match regex miss the button entirely).
          if (/^filters?(\s*\(\s*\d+\s*\))?$/i.test(ft) && bc[f].offsetParent !== null) { fbtn = bc[f]; break; }
        }
        if (fbtn) {
          fbtn.click();
          notes.push('clicked the FILTER button');
          var dd = Date.now() + 4000;
          while (Date.now() < dd && !document.querySelector(SEL) && !document.querySelector(HDR)) {
            await sleep(300);
          }
        }
      }
    }
    // --- OLD UI ---
    rows = document.querySelectorAll(SEL);
    if (rows.length) {
      await clickReveal(document.querySelector('.left-filter-nav') || document,
        function () { return document.querySelectorAll(SEL).length; }, notes);
      rows = document.querySelectorAll(SEL);
      var out = [];
      for (var k = 0; k < rows.length; k++) {
        var label = rows[k].querySelector('label.k-checkbox-label');
        var swatch = rows[k].querySelector('.categ-line-color');
        if (!label) continue;
        out.push({ name: label.innerText.trim(), color: swatch ? normColor(swatch.style.backgroundColor) : '' });
      }
      out.sort(function (a, b) { return a.name.localeCompare(b.name); });
      if (out.length) return { cats: out, diag: '', notes: notes };
    }
    // --- NEW React "Filter Events" drawer ---
    var hdr = document.querySelector(HDR);
    if (hdr) {
      var card = hdr.parentElement || hdr;
      if (!card.querySelector('input[type="checkbox"]')) {
        hdr.click(); // collapsed Categories dropdown — expand it
        notes.push('expanded Categories dropdown');
        await poll('input[type="checkbox"]', 3000, 300, card);
      }
      await clickReveal(card, function () { return card.querySelectorAll('input[type="checkbox"]').length; }, notes);
      var boxes = card.querySelectorAll('input[type="checkbox"]');
      var out2 = [], seen = {};
      for (var m = 0; m < boxes.length; m++) {
        var rowEl = boxes[m].closest('label') || boxes[m].parentElement;
        var name = (rowEl && rowEl.textContent || '').replace(/\s+/g, ' ').trim();
        if (!name || name.length > 60 || seen[name]) continue;
        seen[name] = 1;
        // Colored bar (Events → List page) / swatch: may sit inside the
        // label or as a sibling in the row container — search both.
        var sw = rowEl.querySelector('[style*="background"]') ||
          (rowEl.parentElement && rowEl.parentElement.querySelector('[style*="background"]'));
        var color = sw ? normColor(sw.style.backgroundColor) : '';
        out2.push({ name: name, color: color });
      }
      if (out2.length) {
        if (out2.some(function (c) { return !c.color; })) {
          var cmap = await apiColors();
          if (cmap) out2.forEach(function (c) { if (!c.color && cmap[c.name]) c.color = cmap[c.name]; });
          notes.push(cmap ? "colors recovered from the page's category API" : 'no category API found for colors');
        }
        out2.sort(function (a, b) { return a.name.localeCompare(b.name); });
        var noColor = out2.filter(function (c) { return !c.color; }).length;
        return {
          cats: out2,
          diag: noColor ? noColor + ' of ' + out2.length + ' categories have no color — color matching will miss them.' : '',
          notes: notes
        };
      }
      notes.push('Categories dropdown held no checkbox rows');
    }
    return { cats: [], diag: fingerprint(notes.join('; ') || 'no actions'), notes: notes };
  } catch (e) {
    return { cats: [], diag: 'reader threw: ' + String(e), notes: notes || [] };
  }
}

// Runs in the Events → List page's MAIN world. Must be fully self-contained.
// That page's Filter panel groups filters under collapsible headers
// ("Categories  36 options ⌄"); expanding Categories shows a search box and
// rows that EACH carry a colored vertical bar, truncated behind a
// "Show all (N)" link. The rows are NOT dependable as input[type=checkbox]
// (custom React rows, possibly portal-rendered — Sep 24: "expanded the
// Categories group" yet zero checkbox inputs), so this reader anchors on the
// "Show all (N)" control / colored bars instead. This is the color-true
// source for orgs whose calendar uses the new React Filter drawer.
// Returns { cats: [{name, color}], diag, notes }.
async function readEventsListCategories() {
  var sleep = function (ms) { return new Promise(function (r) { setTimeout(r, ms); }); };
  var normColor = function (c) {
    if (!c) return '';
    if (/transparent|rgba\(\s*0\s*,\s*0\s*,\s*0\s*,\s*0\s*\)/i.test(c)) return '';
    var d = document.createElement('div');
    d.style.backgroundColor = c;
    return d.style.backgroundColor || c;
  };
  var notes = [];
  // Visible inline-background elements whose row text is short = category
  // rows (checkbox square + colored bar + name). Event-card category chips
  // also carry inline backgrounds, so callers must pass a SCOPED container.
  var barRows = function (scope) {
    var out = [], seen = {};
    var els = scope.querySelectorAll('[style*="background"]');
    for (var i = 0; i < els.length; i++) {
      if (els[i].offsetParent === null) continue;
      var row = els[i].closest('label') || els[i].parentElement;
      var name = (row && row.textContent || '').replace(/\s+/g, ' ').trim();
      if (!name || name.length > 60 || seen[name]) continue;
      if (/^(show|view|see)\b/i.test(name) || /\boptions?\b/i.test(name)) continue;
      var color = normColor(els[i].style.backgroundColor);
      if (!color) continue;
      seen[name] = 1;
      out.push({ name: name, color: color });
    }
    return out;
  };
  var findShowAll = function () {
    var cands = document.querySelectorAll('button, a, span, div, p');
    for (var i = 0; i < cands.length; i++) {
      var t = (cands[i].textContent || '').trim();
      if (/^show\s+all\s*\(\s*\d+\s*\)\s*$/i.test(t) && cands[i].offsetParent !== null) return cands[i];
    }
    return null;
  };
  // Walk up from an anchor until the ancestor holds >= 3 colored-bar rows —
  // that is the categories list container (not the whole filter panel, not
  // the events column).
  var containerOf = function (anchor) {
    var el = anchor;
    while (el && el !== document.body) {
      if (el.querySelector && barRows(el).length >= 3) return el;
      el = el.parentElement;
    }
    return null;
  };
  try {
    // 1) Find the "Categories" group header (testid first — the List page's
    //    is events-list-categories-header — then leading-text fallback).
    var findHeader = function () {
      var byTid = document.querySelector('[data-testid*="categories-header"]');
      if (byTid) return byTid;
      var all = document.querySelectorAll('div, button, span, h2, h3, h4');
      var best = null;
      for (var i = 0; i < all.length; i++) {
        var t = (all[i].textContent || '').replace(/\s+/g, ' ').trim();
        if (/^categories\b/i.test(t) && t.length < 40 && all[i].offsetParent !== null) {
          if (!best || t.length < (best.textContent || '').replace(/\s+/g, ' ').trim().length) best = all[i];
        }
      }
      return best;
    };
    var hdr = null;
    var deadline = Date.now() + 12000;
    while (!hdr && Date.now() < deadline) {
      hdr = findHeader();
      if (!hdr) await sleep(400);
    }
    if (!hdr) {
      var tids0 = [];
      var raw0 = document.querySelectorAll('[data-testid]');
      for (var j0 = 0; j0 < Math.min(raw0.length, 10); j0++) tids0.push(raw0[j0].getAttribute('data-testid'));
      return { cats: [], diag: 'no Categories group header on the Events → List page, testids: [' + tids0.join(', ') + ']', notes: notes };
    }

    // 2) Expand the group, then poll for list evidence ANYWHERE (the rows may
    //    be portal-rendered outside the header's subtree): the "Show all (N)"
    //    control or >= 3 colored-bar rows under the header's ancestors.
    var card = null, showAll = null;
    for (var attempt = 0; attempt < 2 && !card && !showAll; attempt++) {
      hdr.click();
      notes.push(attempt ? 'clicked the Categories group again' : 'expanded the Categories group');
      var dd = Date.now() + 6000;
      while (!card && !showAll && Date.now() < dd) {
        await sleep(400);
        showAll = findShowAll();
        if (showAll) { card = containerOf(showAll); break; }
        card = containerOf(hdr); // small lists render fully — no Show all link
      }
    }

    // 3) Reveal the full list: click "Show all (N)" while the row count grows.
    if (showAll) {
      for (var round = 0; round < 5 && showAll; round++) {
        var before = card ? barRows(card).length : 0;
        showAll.click();
        notes.push("clicked '" + (showAll.textContent || '').trim().slice(0, 24) + "'");
        await sleep(900);
        card = containerOf(showAll) || card; // container may re-render
        showAll = findShowAll(); // another reveal stage, or gone = fully shown
        var after = card ? barRows(card).length : 0;
        if (showAll && after <= before) break;
      }
    }

    // 4) Read the rows.
    var out = card ? barRows(card) : [];
    if (!out.length) {
      var inputs = document.querySelectorAll('input[type="checkbox"]').length;
      var roles = document.querySelectorAll('[role="checkbox"]').length;
      var sawShowAll = !!showAll || notes.some(function (n) { return /Show all/i.test(n); });
      var hdrHtml = (hdr.outerHTML || '').replace(/\s+/g, ' ').slice(0, 180);
      return {
        cats: [],
        diag: 'Categories group found but no colored-bar rows — showAll: ' + (sawShowAll ? 'seen' : 'never seen') +
          ', checkbox inputs on page: ' + inputs + ', role=checkbox: ' + roles +
          ', card: ' + (card ? 'yes' : 'no') + ', header html: ' + hdrHtml,
        notes: notes
      };
    }
    out.sort(function (a, b) { return a.name.localeCompare(b.name); });
    notes.push('read ' + out.length + ' rows with colors');
    return { cats: out, diag: '', notes: notes };
  } catch (e) {
    return { cats: [], diag: 'list reader threw: ' + String(e), notes: notes };
  }
}

/**
 * Full category-read pipeline for one org, running entirely in the
 * background (the popup is ephemeral — a closing popup used to strand
 * half-finished reads and their background tabs, Sep 24):
 *   PATH A (works for most orgs): every open calendar tab for the org,
 *     most recently used first; optionally a background calendar tab
 *     opened for the occasion.
 *   PATH B (outlier orgs whose new-UI calendar drawer has no color
 *     swatches): the Events → List page (/Online/Events/List/{orgId}),
 *     whose Categories group carries a colored bar on every row. Used
 *     whenever Path A found nothing OR found names without colors.
 * Every tab opened here is closed here (finally). A non-empty result is
 * persisted to orgCategories. Returns { cats, diag, notes } — callers log;
 * notes always name the path that produced the result.
 *
 * Concurrent callers (init + calendar landing + manual Refresh can overlap)
 * share ONE in-flight read per org — otherwise parallel runs open duplicate
 * background tabs and race the same page renders (Sep 24 log showed three
 * overlapping reads for org 2151).
 */
const categoryReadInflight = new Map(); // orgId -> Promise
function readCategoriesForOrg(orgId, opts) {
  const key = String(orgId);
  const flying = categoryReadInflight.get(key);
  if (flying) return flying;
  const p = readCategoriesForOrgInner(key, opts)
    .finally(() => categoryReadInflight.delete(key));
  categoryReadInflight.set(key, p);
  return p;
}

async function readCategoriesForOrgInner(orgId, opts) {
  const notes = [];
  let diag = '';
  const readFrom = async (tabId) => {
    const res = await chrome.scripting.executeScript({
      target: { tabId },
      world: 'MAIN',
      func: readCalendarCategories,
    });
    const r = (res && res[0] && res[0].result) || {};
    if (r.notes && r.notes.length) notes.push(...r.notes);
    return r;
  };
  const hasColors = (cats) => cats.length && !cats.some((c) => !c.color);
  let cats = [];

  // --- PATH A: the calendar's own FILTER panel -----------------------------
  // User tabs only: an automation (quarantine-window) calendar tab can be
  // mid-navigation or wedged on the skeleton, and its per-window "active"
  // flag would sort it ahead of the tab the user is actually on.
  const calTabs = sortTabsByRecency(
    await queryUserTabs({ url: `https://app.courtreserve.com/Online/Calendar/Events/${orgId}/*` }));
  for (const t of calTabs) {
    try {
      const r = await readFrom(t.id);
      if ((r.cats || []).length) { cats = r.cats; diag = r.diag || ''; break; }
      diag = r.diag || diag;
    } catch (e) { diag = 'injection failed: ' + (e && e.message ? e.message : String(e)); }
  }

  let createdTabId = null;
  if (!cats.length && opts && opts.openTab) {
    try {
      const tab = await createAutomationTab(calendarMonthUrl(orgId), false);
      createdTabId = tab.id;
      await waitForTabComplete(tab.id, 20000);
      await new Promise((r) => setTimeout(r, 2000)); // let the page render
      const r = await readFrom(tab.id);
      cats = r.cats || [];
      diag = r.diag || diag;
    } catch { /* fall through to the List page */ }
  }
  if (hasColors(cats)) notes.push('source: calendar FILTER panel (Path A)');

  // --- PATH B: the Events → List page (colored bar on every row) -----------
  if (!hasColors(cats)) {
    notes.push(cats.length
      ? 'calendar FILTER panel gave ' + cats.length + ' names but NO colors — switching to the Events → List page (Path B)'
      : 'calendar FILTER panel gave nothing — switching to the Events → List page (Path B)');
    try {
      const tab = await createAutomationTab(
        `https://app.courtreserve.com/Online/Events/List/${orgId}`, false);
      try {
        await waitForTabComplete(tab.id, 20000);
        await new Promise((r) => setTimeout(r, 2000)); // let the Filter panel render
        const res = await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          world: 'MAIN',
          func: readEventsListCategories,
        });
        const r = (res && res[0] && res[0].result) || {};
        if (r.notes && r.notes.length) notes.push(...r.notes);
        // The List page wins when it has colors, or when the calendar read
        // found nothing at all; otherwise keep the calendar's list.
        if ((r.cats || []).length && (hasColors(r.cats) || !cats.length)) {
          cats = r.cats;
          diag = r.diag || '';
          notes.push('source: Events → List page (Path B)');
        } else if (r.diag) {
          diag = r.diag;
        }
      } finally {
        await closeAutomationTab(tab.id);
      }
    } catch { /* List fallback is best-effort */ }
  }

  if (createdTabId) await closeAutomationTab(createdTabId);
  if (cats.length) {
    const data = await chrome.storage.local.get(['orgCategories', 'orgCategoriesAt']);
    const orgCategories = data.orgCategories || {};
    orgCategories[orgId] = cats;
    const orgCategoriesAt = data.orgCategoriesAt || {};
    orgCategoriesAt[orgId] = Date.now();
    await chrome.storage.local.set({ orgCategories, orgCategoriesAt });
  }
  return { cats, diag, notes };
}

// ---------------------------------------------------------------------------
// Foreground club setup (v1.6.0 — "the first piece" of the two-phase split):
// profile (Gender + Rating) and the club's FILTER categories are read in a
// tab the user can SEE, with an on-page overlay narrating each step. These
// two reads are the ones that misbehaved as hidden background tabs (focus
// theft, stranded half-read panels — the Sep 27 complaint). Registration
// rules are NOT part of this pass; they stay on the reservation side
// (Auto Fill / silent revalidation), which runs in the quarantine window.
// ---------------------------------------------------------------------------

const SETUP_KEY = 'pendingClubSetup';

// Injected into the setup tab (ISOLATED world). Idempotent: creates, updates,
// or (text = null) removes a small status card pinned bottom-right.
function renderClubSetupOverlay(text, done) {
  var ID = 'crh-club-setup-overlay';
  var el = document.getElementById(ID);
  if (!text) { if (el) el.remove(); return; }
  if (!el) {
    el = document.createElement('div');
    el.id = ID;
    el.style.cssText = 'position:fixed;bottom:18px;right:18px;z-index:2147483647;' +
      'background:#1c1917;color:#fafaf9;padding:11px 15px;border-radius:10px;' +
      'font:13px/1.45 -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;' +
      'max-width:330px;box-shadow:0 8px 24px rgba(0,0,0,.35);display:flex;gap:9px;align-items:center;';
    (document.body || document.documentElement).appendChild(el);
  }
  el.textContent = '';
  var icon = document.createElement('span');
  icon.textContent = done ? '✅' : '⏳';
  var label = document.createElement('span');
  label.textContent = text;
  el.appendChild(icon);
  el.appendChild(label);
}

async function setSetupOverlay(tabId, text, done) {
  try {
    await chrome.scripting.executeScript({
      target: { tabId },
      func: renderClubSetupOverlay,
      args: [text, !!done],
    });
  } catch { /* page mid-navigation — the next update repaints the overlay */ }
}

/** Read the club's FILTER categories in a foreground, narrated pass.
    Reuses the org's open calendar tab when one exists (the tab the user is
    looking at wins), else opens one — with a redirect guard for
    CourtReserve's bounce-to-MyProfile habit. v1.6.3: categories ONLY —
    Gender/Rating are user-entered in Settings, so the pass never leaves the
    calendar. opts.init = update the first-run init stage while working. */
async function runClubSetup(orgId, opts) {
  orgId = String(orgId || '').trim();
  if (!/^\d+$/.test(orgId)) return { ok: false, error: 'bad orgId' };
  opts = opts || {};
  const inflight = (await chrome.storage.local.get(SETUP_KEY))[SETUP_KEY];
  if (inflight && inflight.running && Date.now() - (inflight.startedAt || 0) < 3 * 60 * 1000) {
    return { ok: false, error: 'Club setup is already running.' };
  }
  await chrome.storage.local.set({
    [SETUP_KEY]: { running: true, orgId, stage: 'open', startedAt: Date.now() },
  });
  CRLib.log('run', 'Club setup', `Org ${orgId} — foreground pass: categories.`, 'Started');
  const finish = async (ok, message, count) => {
    await chrome.storage.local.set({
      [SETUP_KEY]: { running: false, orgId, stage: 'done', ok, message, at: Date.now() },
    });
    CRLib.log(ok ? 'ok' : 'warn', 'Club setup', `Org ${orgId} — ${message}`, ok ? 'Done' : 'Incomplete');
    return { ok, error: ok ? undefined : message, count: count || 0 };
  };
  let tabId = null;
  try {
    // The setup tab: the org's calendar tab when the user already has one
    // (active tab of the current window first — that is the tab they are
    // looking at), otherwise a fresh foreground tab. Automation
    // (quarantine-window) tabs are never touched.
    let tabs = await chrome.tabs.query({
      url: `https://app.courtreserve.com/Online/Calendar/Events/${orgId}/*`,
      active: true, currentWindow: true,
    });
    if (!tabs.length) {
      tabs = sortTabsByRecency(
        await queryUserTabs({ url: `https://app.courtreserve.com/Online/Calendar/Events/${orgId}/*` }));
    }
    if (tabs.length) {
      tabId = tabs[0].id;
      await focusTab(tabs[0]);
    } else {
      const t = await chrome.tabs.create({ url: calendarMonthUrl(orgId), active: true });
      tabId = t.id;
      await waitForTabComplete(tabId, 20000);
      await new Promise((r) => setTimeout(r, 1500)); // let the app boot
    }
    // Redirect guard (v1.6.3): CourtReserve's SPA can bounce a fresh calendar
    // tab to MyProfile / the portal (forced profile completion, re-login).
    // Phase 1 then reads a non-calendar page and finds NOTHING (Oct 5: setup
    // reported "no categories" while the tab sat on MyProfile). Give the page
    // a moment, and if it is not on this org's calendar, navigate it back
    // once and wait for the calendar to arrive.
    for (let bounce = 0; bounce < 2; bounce++) {
      let cur = null;
      try { cur = await chrome.tabs.get(tabId); } catch { cur = null; }
      if (cur && isOrgCalendarUrl(cur.url || '', orgId)) break;
      try {
        await chrome.tabs.update(tabId, { url: calendarMonthUrl(orgId) });
        await waitForTabComplete(tabId, 20000);
        await new Promise((r) => setTimeout(r, 2500)); // app boot + grid render
      } catch { /* tab gone — phase 1 will report nothing */ }
    }
    await chrome.storage.local.set({
      [SETUP_KEY]: { running: true, orgId, stage: 'categories', startedAt: Date.now(), tabId },
    });

    // Categories (v1.6.3: the ONLY phase — Gender/Rating are user-entered in
    // Settings; nothing navigates away from the calendar anymore). The
    // standard reader walks the tab's FILTER panel (recency-first, so THIS
    // tab wins) and falls back to the Events → List page in a quarantine tab
    // for colors.
    if (opts.init) await setInit({ stage: 'categories' });
    await setSetupOverlay(tabId, 'Club setup — reading the club\u2019s categories…');
    const r = await readCategoriesForOrg(orgId, { openTab: false });
    const cats = r.cats || [];

    const bits = [];
    bits.push(cats.length ? `${cats.length} categories` : 'no categories found');
    const ok = cats.length > 0;
    const message = ok
      ? `Setup read ${bits.join(' · ')}. Set your Gender/Rating in Settings if you want restricted events hidden.`
      : 'No categories found on this club\u2019s calendar — log in if asked, then run setup again.';
    await setSetupOverlay(tabId, `Club setup ${ok ? 'complete' : 'incomplete'} — ${bits.join(' · ')}`, true);
    setTimeout(() => setSetupOverlay(tabId, null), 4000);
    return await finish(ok, message, cats.length);
  } catch (e) {
    if (tabId) {
      await setSetupOverlay(tabId, 'Club setup hit an error — details are on the extension\u2019s Log tab.', true);
      setTimeout(() => setSetupOverlay(tabId, null), 4000);
    }
    return await finish(false, String((e && e.message) || e), 0);
  }
}

async function startInit() {
  const existing = (await chrome.storage.local.get(INIT_KEY))[INIT_KEY];
  if (existing && existing.running && Date.now() - (existing.at || 0) < 6 * 60 * 1000) return; // one at a time

  await setInit({ running: true, stage: 'find-org', orgId: '', ok: false, message: '', at: Date.now() });
  await chrome.alarms.create(INIT_WATCHDOG, { delayInMinutes: 4 }); // covers find-org + categories; autofill has its own watchdog

  // 1) Find the main organization. If nothing is known and no CourtReserve
  //    tab is open, open the portal (active) and poll while the user logs in
  //    and lands on their club.
  let orgId = await findMainOrgId();
  if (!orgId) {
    const tabs = await queryUserTabs({ url: 'https://app.courtreserve.com/*' });
    if (!tabs.length) {
      await chrome.tabs.create({ url: 'https://app.courtreserve.com/', active: true });
    }
    const deadline = Date.now() + 150000;
    while (!orgId && Date.now() < deadline) {
      await new Promise((r) => setTimeout(r, 2500));
      orgId = await findMainOrgId();
    }
  }
  if (!orgId) {
    await chrome.alarms.clear(INIT_WATCHDOG);
    await setInit({
      running: false, stage: 'done', ok: false, at: Date.now(),
      message: 'No organization found — log into CourtReserve, open your club\u2019s calendar, then run setup again.',
    });
    await notify('⚠ Setup incomplete', 'Log into CourtReserve, open your club\u2019s calendar, then run setup again.');
    return;
  }
  await setInit({ orgId, stage: 'categories' });

  // 2) Foreground club setup (v1.6.0; categories-only since v1.6.3): the
  //    org's FILTER categories are read in one narrated, foreground pass
  //    (runClubSetup) — the read that broke as a hidden background tab
  //    (focus theft / stranded panels, Sep 27). Gender/Rating are NOT read
  //    here — the user types them in Settings (v1.6.2 manual-entry model).
  //    Non-fatal: categories can be refreshed later from Settings.
  try {
    const sr = await runClubSetup(orgId, { init: true });
    if (!sr.ok) {
      CRLib.log('warn', 'Club setup',
        `Init setup pass for org ${orgId}: ${sr.error || 'incomplete'} — categories can be refreshed later from Settings.`,
        'Incomplete');
    }
  } catch { /* club setup is best-effort during init */ }

  // 3) Derive the registration-window rule. finishAutofill finalizes the
  //    init state; the autofill watchdog covers failure from here on.
  //    (Targeted, not a sweep: eligibility is learned opportunistically
  //    whenever a details page is visited — v1.5.24 scale-back.)
  //    A fresh install has NO selected categories yet — there is nothing to
  //    detect, and the legacy keyword fallback would just fail with "no
  //    not-yet-open event found". Skip straight to done; picking categories
  //    later triggers rule detection on its own.
  const initSettings = await CRLib.settings.forOrg(orgId);
  if (!(initSettings.eventFilterCategories || []).length) {
    await chrome.alarms.clear(INIT_WATCHDOG);
    await setInit({
      running: false, stage: 'done', ok: true, at: Date.now(),
      message: 'Pick your categories in Settings — registration windows are detected automatically.',
    });
    return;
  }
  await chrome.alarms.clear(INIT_WATCHDOG);
  await setInit({ stage: 'autofill' });
  const pending = (await chrome.storage.local.get('pendingAutofill')).pendingAutofill;
  if (pending && Date.now() - (pending.startedAt || 0) < 5 * 60 * 1000) {
    // Genuinely in flight — finishAutofill finalizes this init. Make sure its
    // watchdog actually exists; without one a dead run would wedge the init
    // stage forever (the init watchdog was cleared just above).
    const w = await chrome.alarms.get(AUTOFILL_WATCHDOG);
    if (!w) await chrome.alarms.create(AUTOFILL_WATCHDOG, { delayInMinutes: 5 });
  } else {
    // Stale hand-off from a run that died without reporting (killed service
    // worker) — it can never finish this init. Drop it and start fresh.
    if (pending) await chrome.storage.local.remove(['pendingAutofill', 'autofillTabId']);
    await startAutofill(orgId); // targeted → saved as this org's rule
  }
}

// ---------------------------------------------------------------------------
// Popup-open org sync: open the most recently used (LRU) org's calendar and
// make sure the user LANDS there. CourtReserve bounces logged-out users to
// its sign-in page, so watch the tab: if the post-login landing is the
// portal/root default instead of the calendar, route the tab to the calendar
// (CourtReserve often honors ReturnUrl and lands there on its own). Once the
// calendar is up, refresh the org's stored FILTER categories so the extension
// is fully initialized even though opening the tab closed the popup.
// ---------------------------------------------------------------------------

function calendarMonthUrl(orgId) {
  return `https://app.courtreserve.com/Online/Calendar/Events/${orgId}/Month`;
}

/** Active tabs first, then most recently active — "the tab the user is on". */
function sortTabsByRecency(tabs) {
  tabs.sort((a, b) => {
    if (!!a.active !== !!b.active) return a.active ? -1 : 1;
    return (b.lastAccessed || 0) - (a.lastAccessed || 0);
  });
  return tabs;
}

/** Bring a tab to the front (its window too). Best-effort. */
async function focusTab(tab) {
  try { await chrome.tabs.update(tab.id, { active: true }); } catch { /* gone */ }
  try { await chrome.windows.update(tab.windowId, { focused: true }); } catch { /* non-fatal */ }
}

function isOrgCalendarUrl(url, orgId) {
  const m = /\/Online\/Calendar\/Events\/(\d+)/.exec(url || '');
  return !!m && m[1] === String(orgId);
}

// CourtReserve's standard post-login destinations (when no ReturnUrl wins).
function isDefaultLandingUrl(url) {
  return /^https:\/\/app\.courtreserve\.com\/?([?#]|$)/.test(url || '') ||
    /\/Online\/(?:Portal|Home)\//.test(url || '');
}

/** Persist a fresh FILTER category list for the org (best-effort).
    v1.6.2: skipped when the stored list is fresh (<24h) — calendar landings
    happen on every org switch/popup sync, and re-reading the FILTER panel
    each time was background churn the user could see. The Refresh Categories
    button and club setup still force a read. */
async function refreshOrgCategories(_tabId, orgId, opts) {
  try {
    if (!(opts && opts.force)) {
      const d = await chrome.storage.local.get(['orgCategories', 'orgCategoriesAt']);
      const has = d.orgCategories && (d.orgCategories[orgId] || []).length;
      const at = (d.orgCategoriesAt || {})[orgId] || 0;
      if (has && Date.now() - at < 24 * 60 * 60 * 1000) return; // fresh enough
    }
    // Reuse the shared pipeline: open calendar tabs are read recency-first
    // (the landing tab is the most recent), with the Events → List fallback
    // when names or colors are missing.
    const r = await readCategoriesForOrg(orgId, { openTab: false });
    if (!r.cats.length && r.diag) {
      CRLib.log('info', 'Learn categories',
        `Calendar landing read no categories for org ${orgId} — the club may use none, or the panel markup differs. ${r.diag}`,
        'None found');
    }
  } catch { /* categories are best-effort here */ }
}

function watchCalendarLanding(tabId, orgId) {
  const deadline = Date.now() + 3 * 60 * 1000; // generous window to sign in
  let redirected = false; // take over the post-login landing at most once
  let done = false;

  function cleanup() {
    if (done) return;
    done = true;
    chrome.tabs.onUpdated.removeListener(onUpdated);
    chrome.tabs.onRemoved.removeListener(onRemoved);
  }
  function onRemoved(id) { if (id === tabId) cleanup(); }
  function onUpdated(id, info, tab) {
    if (done || id !== tabId) return;
    if (Date.now() > deadline) { cleanup(); return; }
    const url = info.url || (tab && tab.url) || '';
    if (!url) return; // cross-origin detour we can't see — keep waiting
    if (isOrgCalendarUrl(url, orgId)) {
      if (info.status === 'complete') {
        cleanup();
        // Let the FILTER panel render, then initialize the org's data.
        setTimeout(() => refreshOrgCategories(tabId, orgId), 2000);
      }
      return;
    }
    // This tab was opened FOR org X's calendar, so any portal/root landing —
    // or a landing on a DIFFERENT org's calendar (CourtReserve sometimes
    // bounces to the Primary club) — before reaching it is CourtReserve's
    // own redirect, not user intent: reroute it once. (Sign-in pages are
    // left alone; the user needs them. Later navigations are the user's own
    // and are never hijacked.)
    if (!redirected && info.status === 'complete') {
      const otherCal = /\/Online\/Calendar\/Events\/(\d+)/.exec(url);
      if ((otherCal && otherCal[1] !== String(orgId)) || isDefaultLandingUrl(url)) {
        redirected = true;
        chrome.tabs.update(tabId, { url: calendarMonthUrl(orgId) }).catch(() => {});
      }
    }
  }
  chrome.tabs.onUpdated.addListener(onUpdated);
  chrome.tabs.onRemoved.addListener(onRemoved);
}

async function openOrgCalendar(orgId) {
  orgId = String(orgId || '').trim();
  if (!/^\d+$/.test(orgId)) return;
  await chrome.storage.local.set({ lruOrg: { id: orgId, at: Date.now() } });
  const url = calendarMonthUrl(orgId);
  // Reuse any existing CourtReserve tab rather than stacking up calendar
  // tabs: prefer the active tab of the window the user is currently in —
  // that is the tab they are looking at — then the most recently used one.
  // Automation (quarantine-window) tabs are excluded from the fallback
  // survey: they must never be navigated or focused on the user's behalf.
  let tabs = await chrome.tabs.query({ url: 'https://app.courtreserve.com/*', active: true, currentWindow: true });
  if (!tabs.length) {
    tabs = sortTabsByRecency(await queryUserTabs({ url: 'https://app.courtreserve.com/*' }));
  }
  if (tabs.length) {
    const t = tabs[0];
    try { await chrome.tabs.update(t.id, { url, active: true }); } catch { /* gone */ }
    await focusTab(t);
    watchCalendarLanding(t.id, orgId);
    return;
  }
  const tab = await chrome.tabs.create({ url, active: true });
  watchCalendarLanding(tab.id, orgId);
}
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  (async () => {
    switch (msg.type) {
      case 'whoami': {
        // Content scripts can't read their own tab id; the calendar uses this
        // to learn whether IT is the tab startAutofill created, so only that
        // tab drives pendingAutofill (the user's own calendar tab must never
        // take over month-paging when it becomes visible mid-run).
        sendResponse({ ok: true, tabId: (_sender && _sender.tab) ? _sender.tab.id : null });
        break;
      }
      case 'schedule': {
        if (!(await isPremium())) {
          sendResponse({ ok: false, premiumRequired: true });
          break;
        }
        await withEntryLock(async () => {
          const entry = msg.entry;
          entry.status = 'scheduled';
          entry.retryCount = 0;
          await CRLib.store.put(entry);
          CRLib.log('ok', 'Auto-Register', `${entry.event} — ${CRLib.abbrevDate(entry.date)}, ${entry.time}`, 'Scheduled');
          if (entry.fireAt <= Date.now()) {
            await runEntry(entry);
          } else {
            await chrome.alarms.create(alarmName(entry.id), { when: entry.fireAt });
          }
        });
        sendResponse({ ok: true });
        break;
      }
      case 'cancel': {
        await withEntryLock(async () => {
          const entry = await CRLib.store.get(msg.id); // grab details before removal
          await chrome.alarms.clear(alarmName(msg.id));
          await CRLib.store.remove(msg.id);
          CRLib.log('info', 'Remove Auto-Register',
            entry
              ? `${entry.event} — ${CRLib.abbrevDate(entry.date)}, ${entry.time}`
              : 'Scheduled registration removed.',
            'Cancelled');
        });
        sendResponse({ ok: true });
        break;
      }
      case 'heal': {
        // A calendar cell reports that its stored entry has a stale identity
        // or link (rotated token) or fire time — refresh it in place, merge
        // any duplicates of the same occurrence, and re-arm the alarm.
        await withEntryLock(async () => {
          const { oldId, entry } = msg;
          if (oldId && oldId !== entry.id) {
            await chrome.alarms.clear(alarmName(oldId));
            await chrome.alarms.clear(watchdogName(oldId));
            await CRLib.store.remove(oldId);
          }
          const existing = await CRLib.store.get(entry.id);
          if (existing) {
            entry.status = existing.status;
            entry.retryCount = existing.retryCount;
            entry.lastRun = existing.lastRun;
            entry.createdAt = existing.createdAt;
          }
          await CRLib.store.put(entry);
          await dedupeEntries(entry.id);
          if (entry.status === 'scheduled' || entry.status === 'retrying') {
            await chrome.alarms.clear(alarmName(entry.id));
            if (entry.fireAt <= Date.now()) {
              await runEntry(entry);
            } else {
              await chrome.alarms.create(alarmName(entry.id), { when: entry.fireAt });
            }
          }
        });
        sendResponse({ ok: true });
        break;
      }
      case 'runNow': {
        if (!(await isPremium())) {
          sendResponse({ ok: false, premiumRequired: true });
          break;
        }
        await withEntryLock(async () => {
          const entry = await CRLib.store.get(msg.id);
          if (entry) {
            CRLib.log('run', 'Run now', `${entry.event} — ${CRLib.abbrevDate(entry.date)}, ${entry.time}`, 'Started');
            await runEntry(entry);
          }
        });
        sendResponse({ ok: true });
        break;
      }
      case 'fireTimingChanged': {
        // The user changed the fire-seconds delay in Settings — recompute
        // fireAt for every scheduled entry and re-arm its alarm so they don't
        // have to remove and re-add each one.
        let healed = 0;
        await withEntryLock(async () => { healed = await healScheduledEntries(); });
        if (healed > 0) {
          CRLib.log('ok', 'Set fire timing',
            `Re-timed ${healed} scheduled entr${healed === 1 ? 'y' : 'ies'} to the new delay.`, 'Updated');
        }
        sendResponse({ ok: true, healed: healed });
        break;
      }
      case 'licenseStatus': {
        const lic = await CRLib.license.get();
        sendResponse({ ok: true, license: lic, premium: CRLib.license.isPremium(lic) });
        break;
      }
      case 'licenseActivate': {
        const result = await CRLib.license.activate(msg.key, msg.deviceName);
        CRLib.log(result.ok ? 'ok' : 'fail', 'Premium license',
          result.ok ? 'Premium activated on this browser.' : (result.message || 'Premium activation failed.'),
          result.ok ? 'Activated' : 'Failed');
        if (result.ok) {
          await chrome.alarms.create(LICENSE_REVALIDATE, { periodInMinutes: 7 * 24 * 60 });
          await notify('🌟 Premium activated', 'Auto-Register is now unlocked on this browser.');
        }
        sendResponse(result);
        break;
      }
      case 'licenseDeactivate': {
        const result = await CRLib.license.deactivate();
        CRLib.log(result.ok ? 'info' : 'fail', 'Premium license',
          result.ok ? 'Premium deactivated on this browser.' : (result.message || 'Premium deactivation failed.'),
          result.ok ? 'Deactivated' : 'Failed');
        await chrome.alarms.clear(LICENSE_REVALIDATE);
        sendResponse(result);
        break;
      }
      case 'taskResult':
        await withEntryLock(() => handleResult(msg));
        sendResponse({ ok: true });
        break;
      case 'autofillStart':
        await startAutofill(msg.orgId, { auto: !!msg.auto });
        sendResponse({ ok: true });
        break;
      case 'initStart':
        await startInit();
        sendResponse({ ok: true });
        break;
      case 'readCategories': {
        // Popup asks the background to (re)read an org's FILTER categories.
        // All tab orchestration lives here: the popup is ephemeral, so tabs
        // opened from a popup promise chain are stranded the moment the user
        // clicks elsewhere and the popup closes mid-flight.
        const orgId = String(msg.orgId || '').trim();
        if (!/^\d+$/.test(orgId)) {
          sendResponse({ ok: false, error: 'bad orgId' });
          break;
        }
        CRLib.log('run', 'Refresh categories', `Org ${orgId} — reading the calendar FILTER panel`, 'Started');
        try {
          const r = await readCategoriesForOrg(orgId, { openTab: !!msg.openTab });
          const cats = r.cats || [];
          const noColor = cats.filter((c) => !c.color).length;
          const notes = [...new Set(r.notes || [])];
          if (cats.length && !noColor) {
            CRLib.log('ok', 'Refresh categories',
              `Org ${orgId} — ${cats.length} categories loaded, all with colors.` +
                (notes.length ? ` (${notes.join('; ')})` : ''), 'Loaded');
          } else if (cats.length) {
            CRLib.log('warn', 'Refresh categories',
              `Org ${orgId} — ${cats.length} categories loaded but ${noColor} have no color.` +
                (notes.length ? ` (${notes.join('; ')})` : ''), 'Partial');
          } else {
            CRLib.log('warn', 'Refresh categories',
              `Org ${orgId} — no categories found.` +
                (notes.length ? ` (${notes.join('; ')})` : '') +
                (r.diag ? ` Page fingerprint: ${r.diag}` : ''), 'None found');
          }
          sendResponse({ ok: true, count: cats.length });
        } catch (e) {
          CRLib.log('fail', 'Refresh categories', `Org ${orgId} — ${(e && e.message) || e}`, 'Failed');
          sendResponse({ ok: false, error: String((e && e.message) || e) });
        }
        break;
      }
      case 'clubSetup': {
        // Foreground club setup pass (v1.6.0; categories-only since v1.6.3)
        // in a tab the user watches, narrated by an on-page overlay. The
        // popup fires this and usually closes as the CourtReserve tab takes
        // focus — the pass reports to storage (pendingClubSetup) and the Log.
        const setupOrgId = String(msg.orgId || '').trim();
        if (!/^\d+$/.test(setupOrgId)) {
          sendResponse({ ok: false, error: 'bad orgId' });
          break;
        }
        const sr = await runClubSetup(setupOrgId, {});
        sendResponse(sr);
        break;
      }
      case 'openOrgCalendar':
        await openOrgCalendar(msg.orgId);
        sendResponse({ ok: true });
        break;
      case 'orgVisited': {
        // A user-driven calendar visit makes that org the LRU (automation-
        // opened tabs are filtered out by the content script).
        const id = String(msg.orgId || '').trim();
        if (/^\d+$/.test(id)) {
          await chrome.storage.local.set({ lruOrg: { id, at: Date.now() } });
        }
        sendResponse({ ok: true });
        break;
      }
      case 'calendarTarget': {
        // The calendar to send the user to (post-purchase success page): the
        // org of an open CourtReserve calendar tab — the one being viewed
        // first (active, then most recently active) — else the LRU org, else
        // the Primary / first learned org. Empty when nothing is known.
        let orgId = '';
        const calTabs = sortTabsByRecency(
          await queryUserTabs({ url: 'https://app.courtreserve.com/Online/Calendar/Events/*' }));
        for (const t of calTabs) {
          const m = /\/Online\/Calendar\/Events\/(\d+)/.exec(t.url || '');
          if (m) { orgId = m[1]; break; }
        }
        if (!orgId) {
          const data = await chrome.storage.local.get(['lruOrg', 'orgs']);
          const lru = data.lruOrg && /^\d+$/.test(String(data.lruOrg.id || '')) ? String(data.lruOrg.id) : '';
          if (lru) {
            orgId = lru;
          } else {
            const known = Array.isArray(data.orgs) ? data.orgs : [];
            const pick =
              known.find((o) => o.primary && /^\d+$/.test(String(o.id))) ||
              known.find((o) => /^\d+$/.test(String(o.id)));
            if (pick) orgId = String(pick.id);
          }
        }
        sendResponse({ ok: true, orgId });
        break;
      }
      case 'focusOrgCalendar': {
        // Post-purchase hand-off: land the user on an EXISTING CourtReserve
        // tab when one is open — the org's calendar tab first, any other
        // CourtReserve tab otherwise — instead of stacking another calendar
        // tab. A fragment-only URL change doesn't reload the page, so force a
        // reload: the content script must see the #crh-activate hash to show
        // the activation card.
        const orgId = String(msg.orgId || '').trim();
        if (!/^\d+$/.test(orgId)) { sendResponse({ ok: false }); break; }
        const hash = /^#crh-activate/.test(String(msg.hash || '')) ? String(msg.hash) : '';
        await chrome.storage.local.set({ lruOrg: { id: orgId, at: Date.now() } });
        const base = calendarMonthUrl(orgId);
        let tabs = sortTabsByRecency(
          await queryUserTabs({ url: `https://app.courtreserve.com/Online/Calendar/Events/${orgId}/*` }));
        if (!tabs.length) {
          tabs = sortTabsByRecency(await queryUserTabs({ url: 'https://app.courtreserve.com/*' }));
        }
        if (tabs.length) {
          const t = tabs[0];
          const samePage = (t.url || '').split('#')[0] === base;
          try { await chrome.tabs.update(t.id, { url: base + hash, active: true }); } catch { /* gone */ }
          if (samePage) { try { await chrome.tabs.reload(t.id); } catch { /* gone */ } }
          await focusTab(t);
        } else {
          await chrome.tabs.create({ url: base + hash, active: true });
        }
        sendResponse({ ok: true });
        break;
      }
      case 'autofillResult':
        await finishAutofill(msg);
        sendResponse({ ok: true });
        break;
      default:
        sendResponse({ ok: false, error: 'unknown message type' });
    }
  })();
  return true; // async sendResponse
});

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === INIT_WATCHDOG) {
    (async () => {
      const init = (await chrome.storage.local.get(INIT_KEY))[INIT_KEY];
      if (!init || !init.running) return; // finished already
      if (init.stage === 'autofill') return; // the autofill watchdog owns it from here
      await setInit({
        running: false, stage: 'done', ok: false, at: Date.now(),
        message: 'Setup timed out — you may be logged out of CourtReserve, or the page changed. Try again from the Setup tab.',
      });
      await notify('⚠ Setup incomplete', 'Timed out — log into CourtReserve and try again from the Setup tab.');
    })();
    return;
  }
  if (alarm.name.startsWith('autoreg:')) {
    withEntryLock(() => fireEntry(alarm.name.slice('autoreg:'.length)));
    return;
  }
  if (alarm.name.startsWith('watchdog:')) {
    const id = alarm.name.slice('watchdog:'.length);
    withEntryLock(async () => {
      // A pendingTask still sitting here means the tab flow never reported —
      // login redirect, unexpected page, or a killed script. Fail loudly so
      // the retry path (and ultimately a ❌ notification) takes over.
      const data = await chrome.storage.local.get('pendingTask');
      const task = data.pendingTask;
      if (!task || task.entryId !== id) return; // result already arrived
      // Heartbeat: a run still reporting progress (slow pages at the opening
      // minute) gets another minute instead of a false failure + duplicate
      // retry. Dead runs stop heartbeating and are reclaimed on schedule.
      const lastBeat = task.progressAt || task.startedAt;
      if (Date.now() - lastBeat < HEARTBEAT_FRESH_MS &&
          Date.now() - task.startedAt < MAX_RUN_AGE_MS) {
        await chrome.alarms.create(watchdogName(id), { delayInMinutes: 1 });
        return;
      }
      await chrome.storage.local.remove('pendingTask');
      await handleResult({
        type: 'taskResult',
        entryId: id,
        ok: false,
        state: 'failed',
        message: 'No response from the registration tab within 3 minutes — you may be logged out of CourtReserve, or the page changed.',
      });
    });
    return;
  }
  if (alarm.name === LICENSE_REVALIDATE) {
    // Weekly: a cancelled/refunded subscription flips valid → false, which
    // locks premium until the customer renews.
    CRLib.license.validate().catch(() => {});
    return;
  }
  if (alarm.name === AUTOFILL_WATCHDOG) {
    (async () => {
      const data = await chrome.storage.local.get('pendingAutofill');
      if (!data.pendingAutofill) return; // result already arrived
      await finishAutofill({
        ok: false,
        orgId: data.pendingAutofill.orgId,
        message: 'No response from the calendar/details pages within 5 minutes — you may be logged out of CourtReserve, or the page structure changed.',
      });
    })();
  }
});

chrome.runtime.onStartup.addListener(() => { withEntryLock(catchUp); });
chrome.runtime.onInstalled.addListener(() => { withEntryLock(catchUp); updateBadge(); });
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local' && changes.entries) updateBadge();
});

// Service workers are ephemeral: run maintenance on every cold start (at most
// once every 5 minutes) so that merely reloading the extension re-arms alarms,
// merges duplicate entries, and reclaims stale runs.
(async function maintenanceOnWake() {
  try {
    const r = await chrome.storage.local.get('lastMaintenanceAt');
    if (r.lastMaintenanceAt && Date.now() - r.lastMaintenanceAt < 5 * 60 * 1000) return;
    await chrome.storage.local.set({ lastMaintenanceAt: Date.now() });
    await withEntryLock(catchUp);
    // Reclaim a wedged first-run init. The live watchdogs cover healthy
    // browsers, but an alarm lost with a killed worker (or a dead autofill
    // hand-off — the v1.5.29 stuck-setup bug) leaves initState.running set
    // forever and the popup shows "Setting up…" permanently. Anything still
    // marked running 6 minutes after its last state write with no autofill
    // hand-off in flight can never finish on its own — fail it so the user
    // can retry from the Setup tab.
    const initData = await chrome.storage.local.get([INIT_KEY, 'pendingAutofill']);
    const wedged = initData[INIT_KEY];
    if (wedged && wedged.running && Date.now() - (wedged.at || 0) > 6 * 60 * 1000 &&
        (wedged.stage !== 'autofill' || !initData.pendingAutofill)) {
      await setInit({
        running: false, stage: 'done', ok: false, at: Date.now(),
        message: 'Setup was interrupted — run setup again from the Setup tab.',
      });
    }
    // Re-arm weekly license revalidation after any restart; revalidate now if
    // the last check is over a week old.
    const lic = await CRLib.license.get();
    if (lic && lic.key) {
      const existing = await chrome.alarms.get(LICENSE_REVALIDATE);
      if (!existing) await chrome.alarms.create(LICENSE_REVALIDATE, { periodInMinutes: 7 * 24 * 60 });
      if (Date.now() - (lic.lastCheckAt || 0) > 7 * 24 * 60 * 60 * 1000) {
        CRLib.license.validate().catch(() => {});
      }
    }
    // Wake backstop for rule drift: if a club changed its registration-window
    // rule, re-verify stale category rules while we're awake anyway. No-op
    // unless entries are due soon AND a rule is missing or >24h unverified.
    await withEntryLock(() => maybeValidateRules('wake'));
  } catch { /* maintenance is best-effort */ }
})();
