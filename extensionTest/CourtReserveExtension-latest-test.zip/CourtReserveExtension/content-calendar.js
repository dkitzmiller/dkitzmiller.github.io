/**
 * Content script: CourtReserve calendar pages.
 *
 * Scans every .k-event cell and injects an "⏰ Auto-Register" button into
 * events whose registration window has NOT opened yet (per-category rule,
 * falling back to the org's days-before/opening-time rule). If an
 * auto-register entry already exists for that event instance, the button
 * reads "Remove Auto-Register" instead and cancels the schedule on click.
 *
 * Cell anatomy (Kendo scheduler):
 *   <div class="k-event" aria-label="Name on Friday, August 14, 2026 at 10:00 AM to 12:00 PM">
 *     <div class="link-k-event" data-href="/Online/Events/Details/2319/AEN4ZEW2319474">…
 * Not-yet-open cells show availability + a "Details" link but no REGISTER /
 * FULL / EDIT REGISTRATION action label.
 */
(function () {
  "use strict";

  var BTN_CLASS = "crx-autoreg-btn";
  var DAY_CLASS = "crx-opens-day";      // bold date-number marker (visual)
  var IND_CLASS = "crx-opens-pill";     // event-pill marker (tooltip + cleanup)
  var HOT_CLASS = "crx-opens-hot";      // date number while hovered (green)
  var TARGET_CLASS = "crx-opens-target";// event cells linked to a hovered date
  var DIM_CLASS = "crx-rating-dim";     // Filter-by-rating: ineligible event

  // Inject our stylesheet once.
  function ensureStyle() {
    if (document.getElementById("crx-autoreg-style")) return;
    var style = document.createElement("style");
    style.id = "crx-autoreg-style";
    style.textContent =
      "." + BTN_CLASS + "{" +
      "display:inline-block;margin-top:3px;padding:1px 8px;font-size:10.5px;font-weight:600;" +
      "line-height:1.5;border:none;border-radius:8px;cursor:pointer;" +
      "background:#0d9488;color:#fff;box-shadow:0 1px 2px rgba(0,0,0,.35);z-index:50;position:relative;}" +
      "." + BTN_CLASS + ":hover{background:#0f766e;}" +
      "." + BTN_CLASS + ".crx-remove{background:#b91c1c;}" +
      "." + BTN_CLASS + ".crx-remove:hover{background:#991b1b;}" +
      "." + BTN_CLASS + ".crx-lock{background:#7c3aed;}" +
      "." + BTN_CLASS + ".crx-lock:hover{background:#6d28d9;}" +
      // Date-number marker on the day registration OPENS: bold + black.
      "." + DAY_CLASS + "{font-weight:700 !important;color:#000 !important;cursor:pointer;}" +
      // While hovered, the date goes bright green and the matching event
      // cells light up in the same green — the link is unmistakable.
      "." + DAY_CLASS + "." + HOT_CLASS + "{color:#16a34a !important;}" +
      "." + TARGET_CLASS + "{box-shadow:0 0 0 3px #16a34a !important;background:rgba(34,197,94,.22) !important;}" +
      // Filter-by-rating: events the player's rating can't play are dimmed
      // (still clickable — the title heuristic can be wrong).
      "." + DIM_CLASS + "{opacity:.35 !important;filter:grayscale(.6);}";
    document.head.appendChild(style);
  }

  function orgIdFromLocation() {
    var m = /\/Online\/Calendar\/Events\/(\d+)/.exec(location.pathname);
    return m ? m[1] : "";
  }

  function instanceIdFromHref(href) {
    var m = /\/Online\/Events\/Details\/\d+\/([A-Za-z0-9]+)/.exec(href || "");
    return m ? m[1] : "";
  }

  // Fire delay for tooltips: 0 -> "at opening", 30 -> "30 sec after
  // registration opens", 90 -> "1.5 min after registration opens".
  function fmtFireDelay(sec) {
    sec = typeof sec === "number" ? sec : 60;
    if (sec === 0) return "at opening";
    if (sec < 60) return sec + " sec after registration opens";
    return (Math.round((sec / 60) * 10) / 10) + " min after registration opens";
  }

  // The event cell's category color: CourtReserve colors every event by its
  // category (the same colors shown in the FILTER panel), carried on an inner
  // div's inline background (old UI) or on the block itself (new UI).
  function cellBgColor(cell) {
    if (cell.style && cell.style.background) return cell.style.background;
    var inner = cell.querySelector("[style*=background]");
    return inner && inner.style ? inner.style.background : "";
  }

  // --- NEW-UI calendar (React; e.g. Pickleball Zone Bend, Sep 24) -----------
  // Month view event blocks are custom elements carrying the category color
  // on their own inline background, with text "Title 12p - 2p" and no
  // aria-label, no .k-event class, and no Kendo structure at all. They are
  // recognized by: inside the events-calendar-page container + inline
  // background + a clock-time range in a short text. The day number is found
  // in the block's nearest ancestor holding a bare-number element; month and
  // year come from the "September 2026" nav label. A synthesized old-format
  // label ("Name on Day, Month D, YYYY at H:MM AM to H:MM PM") is parked on
  // the element so the whole old pipeline (parseEventLabel, entryKey, …)
  // runs unchanged.
  var TIME_RANGE_RE = /\b(0?[1-9]|1[0-2])(:\d{2})?\s*[ap]m?\b\s*[-–—]\s*\b(0?[1-9]|1[0-2])(:\d{2})?\s*[ap]m?\b/i;
  var MONTHS = ["january","february","march","april","may","june","july","august","september","october","november","december"];
  var WEEKDAYS = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];

  // Rendered text of an element, normalized to single spaces. innerText puts
  // line breaks between block children; raw textContent GLUES them
  // ("8:30p25 of 32 spots…"), which broke TIME_RANGE_RE's word boundary and
  // hid every event whose pill carries spots/REGISTER after the time
  // (Sep 24, PZB month-template — September's title+time pills survived only
  // because the time happened to be last).
  function elText(el) {
    return ((el.innerText || el.textContent || "") + "").replace(/\s+/g, " ").trim();
  }

  function normClock(h, m, ap) {
    h = Number(h);
    if (ap === "p" && h !== 12) h += 12;
    if (ap === "a" && h === 12) h = 0;
    var hr = h % 12 === 0 ? 12 : h % 12;
    return hr + ":" + (m || "00") + " " + (h < 12 ? "AM" : "PM");
  }

  // "12p - 2p" / "5p - 6:30p" → "12:00 PM to 2:00 PM" (old-UI label format).
  function normTimeRange(raw) {
    var re = /(0?[1-9]|1[0-2])(?::(\d{2}))?\s*([ap])m?/gi;
    var a = re.exec(raw), b = re.exec(raw);
    if (!a || !b) return "";
    return normClock(a[1], a[2], a[3].toLowerCase()) + " to " + normClock(b[1], b[2], b[3].toLowerCase());
  }

  function newUiMonthYear() {
    var scope = document.querySelector('[data-testid="calendar-nav-group"]');
    var text = (scope ? scope.textContent : document.body.textContent) || "";
    // The label can be glued to the "Today" button ("TodaySeptember 2026"),
    // so match a KNOWN month name, not any run of letters.
    var m = /(january|february|march|april|may|june|july|august|september|october|november|december)\s+(\d{4})/i.exec(text);
    if (!m) return null;
    return { month: MONTHS.indexOf(m[1].toLowerCase()), year: Number(m[2]) };
  }

  // The day number for a block. Two strategies (Sep 24: the new UI does NOT
  // nest blocks inside day cells — blocks overlay the grid, so ancestry
  // alone can fail):
  //  A) walk up to the nearest ancestor holding a visible bare-number
  //     element (any tag; direct text nodes count — the number may share its
  //     element with the block container);
  //  B) POSITION-based: collect the grid's date-number elements, bucket them
  //     into 7 columns by x-center, take the column nearest the block's
  //     center, then the number whose row sits just above the block. Labels
  //     in a column step by 7 days; a first-row label >= 15 belongs to the
  //     previous month (leading cells), everything else to this month.
  function ownText(el) {
    var t = "";
    for (var i = 0; i < el.childNodes.length; i++) {
      if (el.childNodes[i].nodeType === 3) t += el.childNodes[i].textContent;
    }
    return t.trim();
  }

  function newUiBlockDateByWalk(el, my) {
    var node = el.parentElement;
    while (node && node !== document.body) {
      // The day cell itself may carry the number as a direct text node
      // ("21" followed by the event-block children) — check the chain first.
      var tOwn = ownText(node);
      if (/^\d{1,2}$/.test(tOwn)) {
        return dayToDate(Number(tOwn), my, node.getBoundingClientRect().top);
      }
      var cands = node.querySelectorAll("*");
      for (var i = 0; i < cands.length; i++) {
        if (cands[i].offsetParent === null) continue;
        if (el.contains(cands[i]) || cands[i].contains(el)) continue;
        var t = (cands[i].textContent || "").trim();
        if (!/^\d{1,2}$/.test(t)) continue;
        return dayToDate(Number(t), my, cands[i].getBoundingClientRect().top);
      }
      node = node.parentElement;
    }
    return null;
  }

  // Month-grid position → real month. The day number alone is ambiguous at
  // month boundaries: LEADING cells (top row, big numbers) belong to the
  // previous month and TRAILING cells (bottom rows, small numbers) to the
  // next. For a long time only the leading case was handled — so a trailing
  // "Nov 6" cell in the October grid was read as "Oct 6" (Oct 4: Auto Fill
  // read the CORE Lottery block's countdown — correct for the REAL Nov 6
  // event — and rejected it as implausible for the misdated "Oct 6").
  function gridRect() {
    var root = document.querySelector('[data-testid="events-calendar-page-inner"]') ||
               document.querySelector('[data-testid*="events-calendar-page"]');
    return root ? root.getBoundingClientRect() : null;
  }
  function dayToDate(day, my, elY) {
    var dim = new Date(my.year, my.month + 1, 0).getDate();
    if (day > dim) return new Date(my.year, my.month - 1, day); // leading prev-month cell
    if (elY != null) {
      var gr = gridRect();
      if (gr && gr.height > 0) {
        var frac = (elY - gr.top) / gr.height;
        // Small number low in the grid = trailing next-month row; big number
        // at the very top = leading prev-month row (defensive). Small numbers
        // of THIS month only occur in the top rows, so 0.6 is a safe cut.
        if (day <= 13 && frac > 0.6) return new Date(my.year, my.month + 1, day);
        if (day >= 20 && frac < 0.2) return new Date(my.year, my.month - 1, day);
      }
    }
    return new Date(my.year, my.month, day);
  }

  function newUiBlockDateByPos(el, my) {
    var root = document.querySelector('[data-testid="events-calendar-page-inner"]') ||
               document.querySelector('[data-testid*="events-calendar-page"]');
    if (!root) return null;
    var rect = el.getBoundingClientRect();
    var bx = rect.left + rect.width / 2, by = rect.top;
    var nums = [];
    var all = root.querySelectorAll("*");
    for (var i = 0; i < all.length; i++) {
      if (all[i].offsetParent === null) continue;
      if (el.contains(all[i]) || all[i].contains(el)) continue;
      var t = (all[i].textContent || "").trim();
      if (!/^\d{1,2}$/.test(t)) continue;
      var r = all[i].getBoundingClientRect();
      nums.push({ n: Number(t), x: r.left + r.width / 2, y: r.top });
    }
    if (nums.length < 7) return null; // not a recognizable month grid
    // Column width ≈ grid width / 7. Nearest column first (day numbers may be
    // left-aligned while the block is centered), then the LOWEST number row
    // still above the block — the block's own day cell.
    var colW = root.getBoundingClientRect().width / 7;
    var nearest = null, nearestDx = 1e9;
    for (var j = 0; j < nums.length; j++) {
      if (nums[j].y > by + 6) continue; // number below the block
      var dx = Math.abs(nums[j].x - bx);
      if (dx < nearestDx) { nearestDx = dx; nearest = nums[j]; }
    }
    if (!nearest || nearestDx > colW) return null;
    var best = null;
    for (var j2 = 0; j2 < nums.length; j2++) {
      if (Math.abs(nums[j2].x - nearest.x) > colW / 2) continue; // other columns
      if (nums[j2].y > by + 6) continue;
      if (!best || nums[j2].y > best.y) best = nums[j2];
    }
    if (!best) return null;
    // Day-of-week column from the block's x position, then anchor the WEEK:
    // the matched number's label + column offset give the exact date — the
    // label alone is ambiguous at month boundaries. Month classification
    // (leading/trailing/this) is shared with the walk strategy: the number's
    // own vertical position in the grid decides.
    return dayToDate(best.n, my, best.y);
  }

  function newUiBlockDate(el) {
    var my = newUiMonthYear();
    if (!my) return null;
    var d = newUiBlockDateByWalk(el, my) || newUiBlockDateByPos(el, my);
    if (!d) return null;
    return WEEKDAYS[d.getDay()] + ", " +
      MONTHS[d.getMonth()].charAt(0).toUpperCase() + MONTHS[d.getMonth()].slice(1) + " " +
      d.getDate() + ", " + d.getFullYear();
  }

  function newUiEventBlocks() {
    var root = document.querySelector('[data-testid="events-calendar-page-inner"]') ||
               document.querySelector('[data-testid*="events-calendar-page"]');
    if (!root) return [];
    var all = root.querySelectorAll('[style*="background"]');
    var out = [];
    for (var i = 0; i < all.length; i++) {
      var el = all[i];
      if (el.offsetParent === null) continue;
      var t = elText(el);
      if (t.length < 3 || t.length > 200 || !TIME_RANGE_RE.test(t)) continue;
      // Deepest qualifying block only — skip containers wrapping other blocks.
      var kids = el.querySelectorAll('[style*="background"]');
      var nested = false;
      for (var k = 0; k < kids.length; k++) {
        var kt = elText(kids[k]);
        if (kt.length >= 3 && kt.length <= 200 && TIME_RANGE_RE.test(kt)) { nested = true; break; }
      }
      if (!nested) out.push(el);
    }
    // Fallback (Sep 24, PZB month-template): some templates split each event
    // into a colored bar PLUS a separate text node — no single element has
    // both an inline background AND the time text, so the heuristic above
    // finds nothing while events render fine (probe: 12 inline-bg, 12
    // event-* testids, 12 time-range texts, 0 blocks). Anchor on the
    // event-* testid instead; cellBgColor() already digs the color out of
    // a child bar. The event-* element's own text may lack the time range
    // (bar only), so climb up to 3 ancestors for a SHORT text that has one
    // and remember it as the label source (prepNewUiBlock prefers _crxText).
    if (!out.length) {
      var evs = root.querySelectorAll('[data-testid^="event-"]');
      for (var j = 0; j < evs.length; j++) {
        var ev = evs[j];
        if (ev.offsetParent === null) continue;
        if (ev.querySelector('[data-testid^="event-"]')) continue; // deepest only (defensive)
        var text = "", scope = ev;
        for (var up = 0; up <= 3 && scope; up++) {
          var st = elText(scope);
          if (st.length >= 3 && st.length <= 260 && TIME_RANGE_RE.test(st)) { text = st; break; }
          scope = scope.parentElement;
        }
        if (!text) continue;
        ev._crxText = text;
        out.push(ev);
      }
    }
    return out;
  }

  // Prepare a new-UI block for the shared pipeline: synthesize _crxLabel and
  // _crxHref. Returns false when the block can't be fully parsed.
  function prepNewUiBlock(el) {
    var t = el._crxText || elText(el);
    var m = TIME_RANGE_RE.exec(t);
    if (!m) return false;
    // The label may come from an ancestor (_crxText) that also holds the day
    // number — strip a leading bare number ("6 PZB Round Robin …" → name
    // stays clean). Safe: real names starting with a number keep it unless a
    // space follows ("3.5/4.0 Round Robin" is untouched).
    var name = t.slice(0, m.index).trim().replace(/^\d{1,2}\s+/, "");
    var time = normTimeRange(m[0]);
    var date = newUiBlockDate(el);
    if (!name || !time || !date) return false;
    el._crxLabel = name + " on " + date + " at " + time;
    // Details link: an anchor when one exists; otherwise the instance id sits
    // in the block's own data-testid ("event-TO5K1FN2151830") and the URL is
    // synthesized (Sep 24: new-UI blocks have no <a> at all).
    var a = el.querySelector('a[href*="/Events/Details/"]') ||
      (el.closest && el.closest('a[href*="/Events/Details/"]'));
    var href = a ? (a.getAttribute("href") || "") :
      (el.getAttribute("data-href") || el.getAttribute("href") || "");
    if (!href) {
      var tid = el.getAttribute("data-testid") || "";
      var tm = /^event-([A-Za-z0-9]+)$/.exec(tid);
      var org = orgIdFromLocation();
      if (tm && org) href = "/Online/Events/Details/" + org + "/" + tm[1];
    }
    el._crxHref = href;
    return true;
  }

  // Every event cell on the page, whichever UI rendered it: old Kendo
  // .k-event cells, else new-UI blocks (prepped with synthesized labels).
  function collectEventCells() {
    var oldCells = document.querySelectorAll(".k-event");
    if (oldCells.length) return Array.prototype.slice.call(oldCells);
    var blocks = newUiEventBlocks();
    var out = [];
    for (var i = 0; i < blocks.length; i++) {
      if (prepNewUiBlock(blocks[i])) out.push(blocks[i]);
    }
    return out;
  }

  function cellLabel(cell) {
    return cell._crxLabel || cell.getAttribute("aria-label") || "";
  }

  function cellHref(cell) {
    if (cell._crxHref !== undefined) return cell._crxHref || null;
    var link = cell.querySelector(".link-k-event");
    return link ? link.getAttribute("data-href") : null;
  }

  // Diagnostics per VIEW (re-logs on month/week navigation): the nav label
  // is part of the key so paging months produces a fresh report.
  var newUiDiagLoggedFor = "";
  function newUiDiag(blocks, prepped) {
    if (!document.querySelector('[data-testid*="events-calendar-page"]')) return; // old UI — silent
    if (document.querySelector(".k-event")) return;
    var navKey = ((document.querySelector('[data-testid="calendar-nav-group"]') || {}).textContent || "")
      .replace(/\s+/g, " ").trim().slice(0, 40);
    if (newUiDiagLoggedFor === location.pathname + "|" + navKey) return;
    if (blocks.length && prepped.length && blocks.some(function (b) { return !!b._crxHref; })) return; // healthy
    newUiDiagLoggedFor = location.pathname + "|" + navKey;
    var sample = blocks.length
      ? (blocks[0].outerHTML || "").replace(/\s+/g, " ").slice(0, 300)
      : "(no blocks matched the time-range heuristic)";
    // Grid introspection: are there bare-number day labels anywhere, and does
    // the nav label parse? Tells us which date strategy can work.
    var root = document.querySelector('[data-testid="events-calendar-page-inner"]') ||
               document.querySelector('[data-testid*="events-calendar-page"]');
    var dayNums = 0;
    if (root) {
      var allEls = root.querySelectorAll("*");
      for (var g = 0; g < allEls.length; g++) {
        if (allEls[g].offsetParent === null) continue;
        if (/^\d{1,2}$/.test((allEls[g].textContent || "").trim())) dayNums++;
      }
    }
    var navText = ((document.querySelector('[data-testid="calendar-nav-group"]') || {}).textContent || "")
      .replace(/\s+/g, " ").trim().slice(0, 60);
    var tids = [];
    var rawTids = document.querySelectorAll("[data-testid]");
    for (var ti = 0; ti < Math.min(rawTids.length, 12); ti++) tids.push(rawTids[ti].getAttribute("data-testid"));
    // Grid rendered (day numbers present) but the block heuristic found
    // nothing — pinpoint WHICH condition fails: inline background, the
    // event-* testid, or the time-range text. (Sep 24: October's grid showed
    // 72 day labels and zero blocks while September's rendered fine.)
    // Counts ride in the main entry; HTML samples go out as SEPARATE entries
    // — the 600-char log ceiling was eating them when appended here.
    var probe = "";
    var probeSamples = [];
    if (!blocks.length && dayNums > 0) {
      var bgAll = root.querySelectorAll('[style*="background"]');
      var bgVis = 0;
      for (var bi = 0; bi < bgAll.length; bi++) {
        if (bgAll[bi].offsetParent === null) continue;
        bgVis++;
      }
      var evTids = root.querySelectorAll('[data-testid^="event-"]');
      var evVis = 0, evEl = null;
      for (var ei = 0; ei < evTids.length; ei++) {
        if (evTids[ei].offsetParent === null) continue;
        evVis++;
        if (!evEl) evEl = evTids[ei];
      }
      var timeCount = 0, timeEl = null;
      var probeEls = root.querySelectorAll("*");
      for (var pi = 0; pi < probeEls.length; pi++) {
        if (probeEls[pi].offsetParent === null) continue;
        var pt = (probeEls[pi].textContent || "").replace(/\s+/g, " ").trim();
        if (pt.length >= 3 && pt.length <= 120 && TIME_RANGE_RE.test(pt)) {
          timeCount++;
          if (!timeEl) timeEl = probeEls[pi];
        }
      }
      probe = ", inline-bg els: " + bgAll.length + " (" + bgVis + " visible)" +
        ", event-* testids: " + evTids.length + " (" + evVis + " visible)" +
        ", time-range els: " + timeCount;
      if (evEl) {
        probeSamples.push("event-* element: " + (evEl.outerHTML || "").replace(/\s+/g, " ").slice(0, 560));
        if (evEl.parentElement) {
          probeSamples.push("event-* parent: " + (evEl.parentElement.outerHTML || "").replace(/\s+/g, " ").slice(0, 560));
        }
      }
      if (timeEl && timeEl !== evEl) {
        probeSamples.push("time-range element: " + (timeEl.outerHTML || "").replace(/\s+/g, " ").slice(0, 400));
      }
    }
    CRLib.log("info", "Calendar scan",
      "New-UI calendar detected — url: " + location.pathname + ", grid root found: " + (root ? "yes" : "NO") +
      ", blocks: " + blocks.length + ", parsed: " + prepped.length +
      ", with Details link: " + prepped.filter(function (b) { return !!b._crxHref; }).length +
      ", day-number labels in grid: " + dayNums + ", nav label: \"" + navText + "\"" +
      ", testids: [" + tids.join(", ") + "]. First block: " + sample + probe,
      "Diagnostics");
    for (var psi = 0; psi < probeSamples.length; psi++) {
      CRLib.log("info", "Calendar scan", probeSamples[psi], "DOM probe");
    }
  }

  // Stuck-grid recovery (Sep 24, PZB org 2151): in automation-created tabs the
  // new-UI calendar can wedge on calendar-grid-skeleton forever — the app
  // chrome works (the nav label pages months) but the grid's data/render pass
  // never lands, so every scan finds zero events and zero day numbers. When
  // the page has had time to settle and the grid is STILL skeleton, reload
  // once per tab: the remount re-runs the events fetch on a warm app.
  function gridIsWedged() {
    if (document.querySelector(".k-scheduler, .k-event")) return false; // old UI
    if (!document.querySelector('[data-testid*="events-calendar-page"]')) return false;
    if (!document.querySelector('[data-testid="calendar-grid-skeleton"]')) return false;
    // Day numbers render WITH the grid even when a month has no events — no
    // visible day numbers means the grid itself never rendered.
    var root = document.querySelector('[data-testid="events-calendar-page-inner"]');
    if (!root) return false;
    var els = root.querySelectorAll("*");
    for (var i = 0; i < els.length; i++) {
      if (els[i].offsetParent !== null && /^\d{1,2}$/.test((els[i].textContent || "").trim())) return false;
    }
    return true;
  }
  // Positive "the grid is ready to scan" signal for the run's month-reset and
  // month-hop waits. The old checks queried the skeleton testid by PRESENCE,
  // but CourtReserve keeps that element in the DOM (hidden) even after the
  // grid renders — every wait burned its full 20 s and timed out (Sep 25,
  // v1.5.39 run: reset + 2 hops would have wasted 60 s of the 5-minute run
  // budget). Day numbers are the reliable signal: they paint WITH the grid,
  // even for event-free months.
  function newUiGridReady() {
    var root = document.querySelector('[data-testid="events-calendar-page-inner"]');
    if (!root) return false;
    var els = root.querySelectorAll("*");
    for (var i = 0; i < els.length; i++) {
      if (els[i].offsetParent !== null && /^\d{1,2}$/.test((els[i].textContent || "").trim())) return true;
    }
    return false;
  }
  function gridReadyForScan() {
    if (document.querySelector(".k-scheduler")) {
      return !document.querySelector(".k-loading-image, .k-icon.k-i-loading");
    }
    return newUiGridReady();
  }
  var gridRecoveryTried = false;
  function recoverWedgedGrid() {
    if (!CRLib.ctxAlive() || gridRecoveryTried) return;
    if (!gridIsWedged()) return;
    gridRecoveryTried = true;
    var alreadyReloaded = false;
    try { alreadyReloaded = sessionStorage.getItem("crxGridReload") === "1"; } catch (e) { /* ignore */ }
    if (alreadyReloaded) {
      // One reload didn't cure it — report what the page's own network log
      // shows for calendar/event API calls so the next debug round has data.
      var apiHints = [];
      try {
        var res = performance.getEntriesByType("resource") || [];
        for (var i = res.length - 1; i >= 0 && apiHints.length < 4; i--) {
          if (/calendar|event|booking|schedule/i.test(res[i].name)) {
            apiHints.push(res[i].name.split("?")[0].slice(-60) + " (" + Math.round(res[i].duration) + "ms)");
          }
        }
      } catch (e) { /* ignore */ }
      CRLib.log("warn", "Calendar scan",
        "This calendar's grid is still stuck on its loading skeleton after a reload — the events data never arrives in this tab. Recent calendar/event requests: " +
        (apiHints.length ? apiHints.join("; ") : "none seen"),
        "Grid stuck");
      return;
    }
    chrome.storage.local.get(["pendingAutofill", "pendingTask"]).then(function (data) {
      var org = orgIdFromLocation();
      var now = Date.now();
      var pa2 = data.pendingAutofill, pt2 = data.pendingTask;
      var driving = (pa2 && pa2.orgId === org && now - pa2.startedAt < 5 * 60 * 1000) ||
                    (pt2 && pt2.orgId === org && now - pt2.startedAt < 5 * 60 * 1000);
      if (!driving) {
        // v1.6.4: when the user is LOOKING at the wedged tab, the skeleton is
        // all they see — the calendar is broken for them anyway, so reload it
        // once (sessionStorage-guarded) rather than leaving a dead page and a
        // log hint nobody reads in time. Hidden user tabs stay untouched.
        if (document.visibilityState === "visible") {
          CRLib.log("info", "Calendar scan",
            "The calendar grid never finished loading (skeleton only) — reloading this tab once to retry the events load.",
            "Reloading");
          try { sessionStorage.setItem("crxGridReload", "1"); } catch (e) { /* ignore */ }
          location.reload();
          return;
        }
        CRLib.log("info", "Calendar scan",
          "This calendar's grid is stuck on its loading skeleton (no day numbers rendered) — reload the tab to retry the events load.",
          "Grid stuck");
        return;
      }
      CRLib.log("info", "Calendar scan",
        "The calendar grid never finished loading (skeleton only) — reloading this tab once to retry the events load.",
        "Reloading");
      try { sessionStorage.setItem("crxGridReload", "1"); } catch (e) { /* ignore */ }
      location.reload();
    });
  }

  // If the extension was reloaded/updated, this page's copy of the script is
  // orphaned — chrome.* calls would throw "Extension context invalidated".
  // Fail quietly (storage is guarded inside CRLib); only user clicks explain.
  var staleNotified = false;
  function staleNotice() {
    if (staleNotified) return;
    staleNotified = true;
    alert("The CourtReserve extension was reloaded or updated.\nRefresh this page to keep using it.");
  }
  function send(msg) {
    if (!CRLib.ctxAlive()) { staleNotice(); return; }
    try { chrome.runtime.sendMessage(msg); } catch (e) { staleNotice(); }
  }

  /** Cell text without our injected button (its label contains "Register"). */
  function cleanCellText(cell) {
    // TreeWalker over the LIVE cell, skipping our button's subtree, joining
    // text nodes with spaces. (Clone+textContent glued block children —
    // "…remainingREGISTER" — defeating the \bregister\b status check, and
    // innerText on a detached clone falls back to the same glued text.)
    var parts = [];
    var walker = document.createTreeWalker(cell, NodeFilter.SHOW_TEXT, {
      acceptNode: function (node) {
        var p = node.parentElement;
        if (p && p.closest("." + BTN_CLASS)) return NodeFilter.FILTER_REJECT;
        return NodeFilter.FILTER_ACCEPT;
      }
    });
    var n;
    while ((n = walker.nextNode())) parts.push(n.nodeValue);
    return parts.join(" ").replace(/\s+/g, " ").trim();
  }

  /** Drop the event→opening-date hover link (window passed, event opened). */
  function clearOpenHover(cell) {
    if (cell._crxOpenLabel) {
      cell._crxOpenLabel.classList.remove(HOT_CLASS);
      cell._crxOpenLabel = null;
    }
    cell.onmouseenter = null;
    cell.onmouseleave = null;
  }

  /**
   * Map a date to its visible day-number label (the .k-nav-day span). The
   * event pills live in an overlay (.k-scheduler-content), NOT inside the
   * day cells, so DOM ancestry can't find the day — map by date instead:
   * the .k-nav-day spans form the 6x7 grid in row-major order; the first
   * in-month cell is the "01" whose TD lacks k-other-month; the view
   * month/year comes from the "August 2026" label. Returns a lookup
   * function (null-safe).
   */
  function dayLabelFor() {
    var none = function () { return null; };
    var labelEl = document.querySelector(".k-lg-date-format, .k-sm-date-format");
    var m = /^([A-Za-z]+)\s+(\d{4})$/.exec((labelEl ? labelEl.textContent : "").trim());
    if (!m) return none;
    var first = new Date(m[1] + " 1, " + m[2] + " 12:00"); // noon: DST-safe
    if (isNaN(first)) return none;
    var spans = document.querySelectorAll(".k-nav-day");
    if (spans.length < 35) return none; // grid still rendering — retry next scan
    var i0 = -1;
    for (var i = 0; i < spans.length; i++) {
      var td = spans[i].closest("td");
      if ((spans[i].textContent || "").trim() === "01" && td && !td.classList.contains("k-other-month")) {
        i0 = i;
        break;
      }
    }
    if (i0 === -1) return none;
    return function (date) {
      var noon = new Date(date.getFullYear(), date.getMonth(), date.getDate(), 12);
      var idx = i0 + Math.round((noon - first) / 86400000);
      if (idx < 0 || idx >= spans.length) return null;
      // sanity: the grid cell's day number must match the event's day
      if (Number((spans[idx].textContent || "").trim()) !== date.getDate()) return null;
      return spans[idx];
    };
  }

  function scan() {
    if (!CRLib.ctxAlive()) { observer.disconnect(); return; } // orphaned by extension reload
    ensureStyle();
    // Sticky "the new-UI grid HAS rendered on this page" flag: the initial
    // render needs a visible tab, but once any grid has painted (skeleton
    // gone) the DOM persists when hidden and month-hops/fetches complete in
    // the background — so the autofill visibility gate lifts after this.
    if (!gridHasRendered &&
        document.querySelector('[data-testid*="events-calendar-page"]') &&
        !document.querySelector('[data-testid="calendar-grid-skeleton"]')) {
      gridHasRendered = true;
    }
    var orgId = orgIdFromLocation();
    CRLib.settings.forOrg(orgId).then(function (settings) {
      var dayLabelAt = settings.showOpensIndicator === true ? dayLabelFor() : null;
      // Reconcile date-number markers from scratch every scan: Kendo builds
      // the grid asynchronously, so a mark made during a mid-render pass
      // could otherwise stick to the wrong label.
      var oldMarks = document.querySelectorAll("." + DAY_CLASS);
      for (var om = 0; om < oldMarks.length; om++) {
        oldMarks[om].classList.remove(DAY_CLASS);
        oldMarks[om].removeAttribute("title");
      }
      var oldPills = document.querySelectorAll("." + IND_CLASS);
      for (var op = 0; op < oldPills.length; op++) {
        oldPills[op].classList.remove(IND_CLASS);
        oldPills[op].removeAttribute("title");
      }
      var oldTargets = document.querySelectorAll("." + TARGET_CLASS);
      for (var ot = 0; ot < oldTargets.length; ot++) oldTargets[ot].classList.remove(TARGET_CLASS);
      Promise.all([CRLib.store.list(), CRLib.license.get(), CRLib.profiles.get(orgId)]).then(function (res) {
      var entries = res[0];
      var premium = CRLib.license.isPremium(res[1]);
      // Player rating for the title-text guard (v1.6.5): first stored rating.
      var _prof = res[2];
      var userRating = (_prof && (_prof.ratings || [])[0]) || "";
      // One entry per occurrence: identity is org + event + date + time.
      // (CourtReserve rotates the Details-link token, so it can't be the key.)
      var byKey = {};
      entries.forEach(function (e) { byKey[CRLib.entryKey(e.orgId, e)] = e; });

      // Filter-by-rating (v1.7.0): when the option is on and a rating is
      // stored, the title-text guard also DIMS ineligible cells. When off
      // (or no rating), clear any stale dims up front.
      var dimOn = settings.filterByRating === true && !!userRating;
      if (!dimOn) {
        var oldDims = document.querySelectorAll("." + DIM_CLASS);
        for (var od = 0; od < oldDims.length; od++) oldDims[od].classList.remove(DIM_CLASS);
      }
      var cells = collectEventCells(); // old .k-event cells or prepped new-UI blocks
      newUiDiag(newUiEventBlocks(), cells);
      // "Registration opens" indicator: collected for EVERY matching not-open
      // cell — including ones whose button was already injected — and applied
      // to the date numbers after the loop. The marker lands on the day
      // registration OPENS (e.g. Aug 23), not the event's own day (e.g. Aug 31).
      var opensByDay = {}; // "y-m-d" -> { date: Date, events: [label], cells: [el] }
      // Scan counters — reported to the Log tab (throttled) so a missing
      // button is debuggable: which gate stopped it (filter/status/premium).
      // scanBtns counts buttons PRESENT after the scan (already-injected ones
      // are skipped by the loop but still on the page).
      var scanNotOpen = 0, scanMatched = 0, scanBtns = 0;
      // Gate-skip counters — when cells match but no buttons appear, the scan
      // log names the gate that stopped them (Sep 24 new-UI debugging).
      var skipElig = 0, skipNoLink = 0, skipCutoff = 0, skipHidden = 0, skipPast = 0, skipRating = 0;
      var skipSamples = []; // up to 3: name + parsed date + category + color
      for (var i = 0; i < cells.length; i++) {
        var cell = cells[i];

        var label = cellLabel(cell);
        var parts = CRLib.parseEventLabel(label);
        if (!parts) continue;
        // Category/keyword allowlist (e.g. the "4.0+ RR" category). A cell
        // that fails the filter is skipped — UNLESS an entry already exists
        // for it: the Remove Auto-Register button must stay reachable even
        // when the event no longer matches the current picks. (Nothing
        // picked at all → nothing matches → no new ⏰ buttons anywhere.)
        var key = CRLib.entryKey(orgId, parts);
        var entry = byKey[key];
        var cellBg = cellBgColor(cell);
        // The category this cell belongs to (by color) drives which window
        // rule applies — registration windows can differ per category.
        var catName = CRLib.categoryNameForColor(settings, cellBg);
        if (!entry && !CRLib.eventMatchesScoped(parts.event, cellBg, settings)) continue;
        scanMatched++;
        // Eligibility (v1.5.18): a category whose Rating/Gender Restriction
        // excludes the user's profile gets no ⏰ button and no opens
        // indicator — the user can't play it at all. An existing entry keeps
        // its Remove button reachable regardless.
        var elig = CRLib.categoryEligibilityFor(settings, catName);
        if (!entry && elig && elig.eligible === false) { skipElig++; continue; }

        // Only events whose registration has NOT opened yet get a button.
        var status = CRLib.cellStatus(cleanCellText(cell));
        if (status !== "not-open") {
          clearOpenHover(cell); // window now open — hover link is obsolete
          continue;
        }
        scanNotOpen++;
        var eventDate = CRLib.parseLongDate(parts.date);
        if (!eventDate) continue;
        // A parsed date in the PAST means the new-UI date resolver picked the
        // wrong grid row — count separately from a computed-but-gone cutoff.
        var today0 = new Date(); today0 = new Date(today0.getFullYear(), today0.getMonth(), today0.getDate());
        var sampleOf = function (why) {
          if (skipSamples.length >= 3) return;
          skipSamples.push(why + ": " + parts.event.slice(0, 40) + " → " + parts.date +
            " · cat=" + (catName || "?") + " · bg=" + (cellBg || "?"));
        };
        if (!entry && eventDate.getTime() < today0.getTime()) { skipPast++; sampleOf("past date"); continue; }
        // Title-text rating guard (v1.6.5): when the event's own text names a
        // rating rule ("4.0+", "3.0/3.5", "3.5 - 4.0", bare "3.5"), the
        // player's rating must satisfy it — no details-page visit needed. No
        // rating in the text = open to all; no stored rating = fail-open.
        // Placed before the opens-indicator so ineligible events neither get
        // a button NOR bold an opening date.
        if (!entry && userRating && !CRLib.titleRatingEligible(label, userRating)) {
          skipRating++; sampleOf("rating " + userRating);
          // Filter-by-rating (v1.7.0): also dim the cell when the option is
          // on — dimmed, not hidden, because the title heuristic can be
          // wrong and the event stays one click away.
          if (dimOn) cell.classList.add(DIM_CLASS);
          continue;
        }
        // Eligible (or scheduled) cell — make sure no stale dim survives
        // from an earlier scan with a different rating/option.
        if (dimOn && cell.classList.contains(DIM_CLASS)) cell.classList.remove(DIM_CLASS);

        if (settings.showOpensIndicator === true) {
          var opensAt = CRLib.registrationOpens(eventDate, settings, catName);
          // Fallback rules are guesses — label them so a wrong opening time
          // is never mistaken for a detected one.
          var est = !CRLib.windowRuleKnown(settings, catName);
          if (opensAt.getTime() > Date.now()) { // only while still closed
            var dayKey = opensAt.getFullYear() + "-" + opensAt.getMonth() + "-" + opensAt.getDate();
            var bucket = opensByDay[dayKey];
            if (!bucket) bucket = opensByDay[dayKey] = { date: opensAt, events: [], cells: [] };
            var evLabel = parts.event + " (" + (eventDate.getMonth() + 1) + "/" + eventDate.getDate() + ")" +
              (est ? " — est." : "");
            if (bucket.events.indexOf(evLabel) === -1) bucket.events.push(evLabel);
            bucket.cells.push(cell);
            if (!cell.classList.contains(IND_CLASS)) {
              cell.classList.add(IND_CLASS);
            }
            cell.title = "Registration opens " + CRLib.fmtDateTime(opensAt) +
              (est ? " (estimated — run Get settings from CourtReserve)" : "") +
              " — be ready to register.";
            // Event → date direction: hovering the event cell flashes the
            // opening date number bright green (the bolded date's own hover
            // already frames the event cells — this is the reverse link).
            var openLbl = dayLabelAt ? dayLabelAt(opensAt) : null;
            if (openLbl) {
              cell._crxOpenLabel = openLbl;
              cell.onmouseenter = function () { this._crxOpenLabel.classList.add(HOT_CLASS); };
              cell.onmouseleave = function () { this._crxOpenLabel.classList.remove(HOT_CLASS); };
            }
          } else {
            clearOpenHover(cell); // opening moment has passed
          }
        }

        if (cell.querySelector("." + BTN_CLASS)) { scanBtns++; continue; } // already injected — counts as present

        var href = cellHref(cell);
        var instanceId = instanceIdFromHref(href);
        if (!instanceId) {
          skipNoLink++;
          sampleOf("no-link");
          continue;
        }
        // Schedulable until 1 minute before opening.
        var cutoff = CRLib.scheduleCutoff(eventDate, settings, catName).getTime();
        if (cutoff <= Date.now()) {
          skipCutoff++;
          sampleOf("cutoff " + CRLib.fmtDateTime(new Date(cutoff)));
          continue;
        }
        // Anyone can hide the buttons in Calendar options. When the user has
        // never touched the toggle (null), visibility follows the trial:
        // shown while Premium/trial is active (a working feature), hidden
        // for expired free users — no non-dismissible promo UI injected into
        // a third-party page (a CWS policy gray area).
        var showBtns = settings.showAutoRegButtons === null || settings.showAutoRegButtons === undefined
          ? premium
          : settings.showAutoRegButtons === true;
        if (!showBtns) { skipHidden++; continue; }
        var rule = CRLib.windowRuleFor(settings, catName);
        var ruleEst = !CRLib.windowRuleKnown(settings, catName);
        var fireAt = CRLib.fireTime(eventDate, settings, catName).getTime();

        // key/entry were resolved up front (before the filter check) so a
        // stored entry keeps its Remove button even off-filter.
        if (entry) {
          // Self-heal: the link token rotated (or the rule changed) since
          // this event was scheduled — refresh identity/link/fire time in
          // place rather than letting a second entry coexist with the first.
          var absUrl = new URL(href, location.origin).href;
          if (entry.id !== key || entry.instanceId !== instanceId ||
              entry.detailsUrl !== absUrl || entry.fireAt !== fireAt) {
            var healed = {};
            for (var field in entry) healed[field] = entry[field];
            healed.id = key;
            healed.instanceId = instanceId;
            healed.detailsUrl = absUrl;
            healed.fireAt = fireAt;
            send({ type: "heal", oldId: entry.id, entry: healed });
            entry = healed;
            byKey[key] = healed;
          }
        }
        var btn = document.createElement("button");
        btn.type = "button";
        if (!premium) {
          // Free tier: visible-but-locked — the upgrade path, not the feature.
          btn.className = BTN_CLASS + " crx-lock";
          btn.textContent = "🔒 Auto-Register — Premium";
          btn.title = "Auto-registration is a Premium feature — click to upgrade.";
          btn.addEventListener("click", function (ev) {
            ev.stopPropagation();
            ev.preventDefault();
            window.open(CRLib.UPGRADE_URL, "_blank", "noopener");
          });
        } else {
        btn.className = BTN_CLASS + (entry ? " crx-remove" : "");
        btn.textContent = entry ? "⏰ Remove Auto-Register" : "⏰ Auto-Register";
        btn.title = entry
          ? "Auto-register scheduled — fires " + CRLib.fmtDateTime(new Date(entry.fireAt)) + ". Click to cancel."
          : "Schedule auto-register for " + parts.event + " — fires " + CRLib.fmtDateTime(new Date(fireAt)) +
            " (" + fmtFireDelay(settings.fireDelaySeconds) + ", " + rule.daysBefore + " days before the event at " + rule.openTime +
            (catName ? ", " + catName + " rule" : "") + (ruleEst ? " — estimated" : "") + ").";

        (function (entryRef, entryId, entryParts, entryHref, entryFireAt, entryCat) {
          btn.addEventListener("click", function (ev) {
            ev.stopPropagation();
            ev.preventDefault();
            if (entryRef) {
              send({ type: "cancel", id: entryId });
            } else {
              var newEntry = {
                id: entryId,
                orgId: orgId,
                instanceId: instanceIdFromHref(entryHref),
                event: entryParts.event,
                date: entryParts.date,
                time: entryParts.time,
                category: entryCat || "", // drives per-category rule validation
                detailsUrl: new URL(entryHref, location.origin).href,
                fireAt: entryFireAt,
                status: "scheduled",
                retryCount: 0,
                createdAt: new Date().toISOString(),
              };
              send({ type: "schedule", entry: newEntry });
            }
          });
        })(entry, key, parts, href, fireAt, catName);
        } // end premium / free-tier button branch

        // Append inside the reservation container so it sits under the status line.
        var container = cell.querySelector(".reservation-container") || cell;
        container.appendChild(btn);
        scanBtns++;
      }
      // Scan summary → Log tab: throttled to a change in counts or 5 minutes,
      // so a missing ⏰ is debuggable without DevTools.
      var scanSig = cells.length + "/" + scanNotOpen + "/" + scanMatched + "/" + scanBtns + "/" + premium;
      if (scanSig !== lastScanSig || Date.now() - lastScanLogAt > 5 * 60 * 1000) {
        lastScanSig = scanSig;
        lastScanLogAt = Date.now();
        var pickNames = (settings.eventFilterCategories || []).map(function (c) { return c.name; }).join(", ") || "none picked";
        var gateNote = (scanMatched > 0 && scanBtns === 0)
          ? " — gates stopped: restricted " + skipElig + ", rating rule " + skipRating + ", no link " + skipNoLink +
            ", past date " + skipPast + ", window past " + skipCutoff + ", hidden by setting " + skipHidden +
            (skipSamples.length ? " · " + skipSamples.join(" | ") : "")
          : "";
        CRLib.log("info", "Calendar scan",
          cells.length + " events · " + scanNotOpen + " not open · " + scanMatched +
          " match [" + pickNames + "] · " + scanBtns + " ⏰ buttons" + (premium ? "" : " · premium NOT active") + gateNote,
          scanBtns ? "Buttons on" : "No buttons");
      }
      // Apply the collected "opens" markers to the OPEN-day date numbers.
      // Several events can open on the same day — the tooltip lists them all.
      // Hovering a marked date turns it green and frames its event cells in
      // the same green; leaving restores the plain bold-black marker.
      if (settings.showOpensIndicator === true && dayLabelAt) {
        for (var dk in opensByDay) {
          var bucket2 = opensByDay[dk];
          var openLabel = dayLabelAt(bucket2.date);
          if (!openLabel) continue; // open day not visible in this view
          openLabel.classList.add(DAY_CLASS);
          openLabel.title = "Registration opens " + CRLib.fmtDateTime(bucket2.date) +
            " for:\n• " + bucket2.events.join("\n• ");
          openLabel._crxCells = bucket2.cells; // refresh: Kendo re-renders pills
          if (!openLabel._crxHoverBound) {
            openLabel._crxHoverBound = true;
            openLabel.addEventListener("mouseenter", function () {
              this.classList.add(HOT_CLASS);
              var cs = this._crxCells || [];
              for (var k = 0; k < cs.length; k++) cs[k].classList.add(TARGET_CLASS);
            });
            openLabel.addEventListener("mouseleave", function () {
              this.classList.remove(HOT_CLASS);
              var cs = this._crxCells || [];
              for (var k = 0; k < cs.length; k++) cs[k].classList.remove(TARGET_CLASS);
            });
          }
        }
      }
      });
    });
  }

  // Kendo re-renders the calendar on every navigation — observe and re-scan
  // (debounced), and re-scan whenever the stored entries or settings change.
  var timer = null;
  var lastScanSig = "", lastScanLogAt = 0; // scan-summary log throttle
  var lastCatLearnAt = 0; // category-learn throttle (mutation-driven)
  var observer = new MutationObserver(function () {
    clearTimeout(timer);
    timer = setTimeout(scan, 400);
    // Some orgs render the FILTER panel lazily — the initial 0/3/8s learning
    // attempts find nothing. Mutations fire when the panel finally renders
    // (or the user opens FILTER): retry, throttled. No-op when nothing new.
    var now = Date.now();
    if (now - lastCatLearnAt > 3000) {
      lastCatLearnAt = now;
      learnCategoriesFromPage();
    }
  });

  // --- Auto Fill: pick a not-yet-open event matching the keyword filter and
  // follow its Details link so content-details.js can read the countdown.
  // Registration windows differ PER CATEGORY, so one run loops: derive a rule
  // for each selected category that doesn't have one yet, then finish. ---
  function findAutofillCandidate(settings, tried, neededCats) {
    var today = new Date();
    today = new Date(today.getFullYear(), today.getMonth(), today.getDate());
    var best = null; // furthest-future candidate — most likely still pre-registration
    var cells = collectEventCells();
    for (var i = 0; i < cells.length; i++) {
      var cell = cells[i];
      var parts = CRLib.parseEventLabel(cellLabel(cell));
      if (!parts) continue;
      var cellBg = cellBgColor(cell);
      if (!CRLib.eventMatchesScoped(parts.event, cellBg, settings)) continue;
      // Only not-yet-open cells show the "Details" link with the countdown.
      // Past AND same-day events look identical here but their countdown is
      // gone — so we require a future date and then prefer the latest one.
      if (CRLib.cellStatus(cleanCellText(cell)) !== "not-open") continue;
      var eventDate = CRLib.parseLongDate(parts.date);
      if (!eventDate || eventDate.getTime() <= today.getTime()) continue;
      var href = cellHref(cell);
      if (!href) continue;
      if (tried && tried.indexOf(instanceIdFromHref(href)) !== -1) continue; // already attempted
      var catName = CRLib.categoryNameForColor(settings, cellBg);
      // When specific categories still need a rule, only their events qualify.
      if (neededCats && neededCats.length && neededCats.indexOf(catName) === -1) continue;
      if (!best || eventDate.getTime() > best.eventDate.getTime()) {
        best = { parts: parts, href: href, eventDate: eventDate, category: catName };
      }
    }
    return best;
  }

  // The "next month" navigation control, whichever UI rendered it: Kendo's
  // .k-nav-next, else the new UI's calendar-nav-group. The new UI's arrows
  // are icon-only buttons (no text, maybe no aria-label) — layout is
  // [Today] [<] [>] [Month Year], so the explicit markers win first and the
  // fallback is the SECOND textless button.
  function nextMonthButton() {
    var k = document.querySelector(".k-nav-next");
    if (k) return k;
    var nav = document.querySelector('[data-testid="calendar-nav-group"]');
    if (!nav) return null;
    var all = nav.querySelectorAll("button, a, [role='button']");
    var btns = [];
    for (var i = 0; i < all.length; i++) {
      if (all[i].offsetParent !== null) btns.push(all[i]);
    }
    for (var j = 0; j < btns.length; j++) {
      var t = (btns[j].textContent || "").trim();
      var aria = (btns[j].getAttribute("aria-label") || "").toLowerCase();
      var title = (btns[j].getAttribute("title") || "").toLowerCase();
      if (/^(>|›|»|→|next)$/.test(t) || /next|forward/.test(aria) || /next|forward/.test(title)) return btns[j];
    }
    // Icon-only fallback: textless buttons in order are [prev, next].
    var icons = btns.filter(function (b) { return !(b.textContent || "").trim(); });
    return icons.length >= 2 ? icons[1] : null;
  }

  // Selected categories still missing a per-category window rule. Categories
  // known to have no countdown (event type never shows one) are skipped. In
  // revalidate mode, categories whose rule is STALE (validated >24h ago) are
  // included too — the daily rule check re-verifies them against a live
  // countdown so a club's rule change is caught before the next fire.
  // Categories already known to be rating-ineligible for the user are skipped
  // — they never fire, so their rule is not worth investigating.
  function categoriesNeedingRules(settings, pa) {
    var cats = settings.eventFilterCategories || [];
    if (!cats.length) return null; // text mode / no picks: legacy single-shot
    var windows = settings.categoryWindows || {};
    var noCd = settings.noCountdownCategories || [];
    var eligMap = settings.categoryEligibility || {};
    var skipped = (pa && pa.catTried) || [];
    var revalidate = !!(pa && pa.revalidate);
    var out = [];
    for (var i = 0; i < cats.length; i++) {
      var n = cats[i].name;
      if (noCd.indexOf(n) !== -1 || skipped.indexOf(n) !== -1) continue;
      if (eligMap[n] && eligMap[n].eligible === false) continue;
      var r = windows[n];
      if (!r) { out.push(n); continue; }
      if (revalidate &&
          (typeof r.validatedAt !== "number" || Date.now() - r.validatedAt > CRLib.RULE_STALE_MS)) {
        out.push(n);
      }
    }
    return out;
  }

  function autofillSummary(pa) {
    var saves = pa.saves || [];
    if (!saves.length) return "";
    var bits = saves.map(function (sv) {
      return (sv.category ? sv.category + ": " : "") + sv.daysBefore + " day(s) before at " + sv.openTime;
    });
    var out = "Detected on " + pa.orgId + "'s calendar — " + bits.join("; ") + ". Saved per category.";
    // Categories whose restriction blocks exclude the user get named — they
    // are hidden from the selectable list, so say why.
    var restricted = saves.filter(function (sv) { return sv.eligible === false; });
    if (restricted.length) {
      out += " Restricted for you (hidden from the list): " +
        restricted.map(function (sv) {
          return (sv.category || "events") + (sv.ineligibleReason ? " — " + sv.ineligibleReason : "");
        }).join(", ") + ".";
    }
    return out;
  }

  // Categories whose event pages showed no countdown get named, so a missing
  // rule tag in the list is explained rather than mysterious.
  function autofillMissedNote(pa) {
    var missed = (pa.catTried || []);
    if (!missed.length) return "";
    return " No countdown found for: " + missed.join(", ") + ".";
  }

  // v1.6.6: before scanning, make sure the calendar FILTER isn't hiding a
  // selected category. The FILTER selection is remembered by CourtReserve
  // (server-side, shared across tabs), so when the user filtered their
  // calendar down to a few categories, that same filter applies in this
  // detection tab — a newly selected category's events never render and the
  // run ends with "No countdown found for …". ADDITIVE ONLY: check the
  // extension-selected categories that are missing; never uncheck others.
  function ensureFilterCoversSelection(settings) {
    var want = (settings.eventFilterCategories || []).map(function (c) { return c.name; });
    if (!want.length) return Promise.resolve({ added: 0 });
    return ensureFilterChecked(want);
  }

  // DOM worker for ensureFilterCoversSelection. Adapted from the popup's
  // applyCalendarCategories (which REPLACES the filter) — this one only ADDS
  // the wanted categories. Handles both the old Kendo drawer (real
  // checkboxes, apply-on-click) and the new React drawer (custom rows, an
  // Apply button). Runs in the content script's isolated world, so the old
  // UI's drawer is opened by clicking its FILTER button (the page's
  // openLeftNav() function is not reachable here).
  async function ensureFilterChecked(wantNames) {
    var sleep = function (ms) { return new Promise(function (r) { setTimeout(r, ms); }); };
    try {
      // OLD (Kendo) UI: real checkboxes; checking applies immediately.
      var rows = document.querySelectorAll(".custom-checkbox.rowCheckbox");
      if (!rows.length) {
        var oldBtn = document.querySelector("button.btn-filter");
        if (oldBtn && oldBtn.offsetParent !== null) {
          oldBtn.click(); // drawer was closed (no rows rendered) — open it
          var dOld = Date.now() + 5000;
          while (!rows.length && Date.now() < dOld) {
            await sleep(400);
            rows = document.querySelectorAll(".custom-checkbox.rowCheckbox");
          }
        }
      }
      if (rows.length) {
        var addedOld = 0;
        for (var i = 0; i < rows.length; i++) {
          var label = rows[i].querySelector("label.k-checkbox-label");
          var box = rows[i].querySelector("input.category-chk");
          if (!label || !box) continue;
          if (wantNames.indexOf((label.innerText || "").trim()) >= 0 && !box.checked) { box.click(); addedOld++; }
        }
        var nav = document.querySelector(".left-filter-nav");
        var closeBtn = nav ? nav.querySelector(".closebtn") : null;
        if (closeBtn) closeBtn.click();
        return { added: addedOld };
      }
      // NEW React/Ant "Filter Events" drawer. Rows are custom elements —
      // NOT input[type=checkbox] — discovered generically as leaf
      // cursor:pointer divs in the Categories section (works even when this
      // org's stored category list is stale). Checked = the row's square
      // holds an inline check svg (verified live Oct 5). Rows live inside
      // the .ant-drawer, so calendar event TITLES that equal category names
      // (Sep 24, PZB) can never be matched by mistake.
      var textOf = function (el) { return (el && el.textContent || "").replace(/\s+/g, " ").trim(); };
      var drawer = function () { return document.querySelector(".ant-drawer-open") || document.querySelector(".ant-drawer"); };
      // Ensure the drawer is OPEN. Poll up to 12 s for the header to appear
      // — the FILTER button itself renders late on a fresh page (Oct 5: the
      // widen ran 1 s BEFORE the header painted, found no button, and failed
      // instantly). The button TOGGLES the drawer, so re-click no more than
      // every 2 s and only while no header is visible (a click that landed
      // but hasn't rendered yet must not be "retried" into a close).
      var hdr = document.querySelector('[data-testid*="filter-categories-header"]');
      var openDeadline = Date.now() + 12000, lastClick = 0;
      while ((!hdr || hdr.offsetParent === null) && Date.now() < openDeadline) {
        if (Date.now() - lastClick > 2000) {
          var fbtn = null;
          var bc = document.querySelectorAll('button, a, [role="button"]');
          for (var f = 0; f < bc.length; f++) {
            var ft = (bc[f].textContent || "").trim();
            // "Filter", or "Filter (N)" once a filter is active (Oct 5: the
            // count badge made the exact-match regex miss the button).
            if (/^filters?(\s*\(\s*\d+\s*\))?$/i.test(ft) && bc[f].offsetParent !== null) { fbtn = bc[f]; break; }
          }
          if (fbtn) { fbtn.click(); lastClick = Date.now(); }
        }
        await sleep(500);
        hdr = document.querySelector('[data-testid*="filter-categories-header"]');
      }
      if (!hdr || hdr.offsetParent === null) return { added: 0, error: "FILTER panel not found" };
      var section = hdr.parentElement && hdr.parentElement.parentElement ? hdr.parentElement.parentElement : null;
      var findRows = function () {
        var map = {};
        var roots = section ? [section, drawer()] : [drawer()];
        for (var r2 = 0; r2 < roots.length; r2++) {
          if (!roots[r2]) continue;
          var els = roots[r2].querySelectorAll("div[style*=cursor]");
          for (var i2 = 0; i2 < els.length; i2++) {
            var el = els[i2];
            if (el.offsetParent === null) continue;
            if (el.querySelector("div[style*=cursor]")) continue;
            var t = textOf(el);
            if (!t || t.length > 60) continue;
            map[t] = el;
          }
          if (Object.keys(map).length) break;
        }
        return map;
      };
      var isChecked = function (row) {
        var inp = row.querySelector('input[type="checkbox"]');
        if (inp) return !!inp.checked;
        var aria = (row.matches && row.matches('[aria-checked]')) ? row : row.querySelector('[aria-checked]');
        if (aria) return aria.getAttribute('aria-checked') === 'true';
        var sq = row.firstElementChild;
        if (sq && sq.querySelector("svg")) return true;
        return /checked|selected|is-active/i.test(String(row.className || ""));
      };
      var clickRow = function (row) {
        var t = row.querySelector('input[type="checkbox"], [role="checkbox"]') || row;
        t.click();
      };
      // Expand the Categories dropdown ONLY when no rows are showing — the
      // header click toggles, so clicking an expanded one would collapse it.
      var map = findRows();
      if (Object.keys(map).length === 0) {
        hdr.click();
        var d2 = Date.now() + 5000;
        while (Date.now() < d2 && Object.keys(map).length === 0) {
          await sleep(400);
          map = findRows();
        }
      }
      // Cascading reveal: "Show all (N)" — click while the row count grows.
      for (var round = 0; round < 5; round++) {
        var reveal = null;
        var dr2 = drawer();
        if (!dr2) break;
        var cands = dr2.querySelectorAll("button, a, span, div, p");
        for (var i3 = 0; i3 < cands.length; i3++) {
          if (/^show\s+all\s*\(\s*\d+\s*\)\s*$/i.test((cands[i3].textContent || "").trim()) &&
              cands[i3].offsetParent !== null) { reveal = cands[i3]; break; }
        }
        if (!reveal) break;
        var before = Object.keys(map).length;
        reveal.click();
        await sleep(900);
        map = findRows();
        if (Object.keys(map).length <= before) break;
      }
      map = findRows();
      var added = 0;
      for (var w = 0; w < wantNames.length; w++) {
        var row = map[wantNames[w]];
        if (!row) continue; // not in this club's panel — detection will report it
        if (isChecked(row)) continue; // already visible on the calendar
        clickRow(row);
        added++;
        await sleep(150); // let React stage each toggle
      }
      if (!added) return { added: 0 };
      // New-UI changes stage until "Apply" is clicked.
      var applyBtn = null;
      var dr3 = drawer();
      if (dr3) {
        var bs = dr3.querySelectorAll("button");
        for (var b = 0; b < bs.length; b++) {
          if ((bs[b].textContent || "").trim() === "Apply" && bs[b].offsetParent !== null) { applyBtn = bs[b]; break; }
        }
      }
      await sleep(300); // let React enable the button after the toggles
      if (applyBtn && !applyBtn.disabled) applyBtn.click();
      await sleep(1500); // let the grid refetch + re-render with the widened filter
      return { added: added };
    } catch (e) {
      return { added: 0, error: String(e) };
    }
  }

  // Re-entrancy guard (Sep 24 runaway-paging bug): maybeAutofill is entered
  // from several triggers (start, visibilitychange, internal continuations)
  // and each invocation's 25 s candidate poll outlives it — overlapping
  // chains both paged from the same pendingAutofill snapshot, and a stale
  // catTried write dropped monthHops back to 0, so one run paged forward
  // without end (reached August 2027). One chain at a time: external
  // triggers are ignored while a chain is live; continuations pass `true`.
  var afChainBusy = false;
  // Sticky per-page flag, set by scan(): once the new-UI grid has rendered
  // even once, the tab no longer needs to be visible to drive a run.
  var gridHasRendered = false;
  function maybeAutofill(continuation) {
    if (!CRLib.ctxAlive()) return;
    // The new-UI grid's FIRST render needs a visible tab (rAF/observer work
    // is suspended in hidden ones — the page sits on calendar-grid-skeleton
    // forever), so a hidden tab that has never rendered can't drive. But once
    // rendered, the DOM persists and hops/fetches finish hidden — lifting the
    // gate then keeps the run alive when the user clicks back to their own
    // tab mid-run (Sep 25: the run stalled on "Detecting registration rules"
    // for minutes until the user returned to the run's tab). Old-UI (Kendo)
    // pages render fine hidden and were never gated. The visibilitychange
    // listener (start()) still restarts a paused chain on return.
    var newUiPage = !!document.querySelector('[data-testid*="events-calendar-page"]') &&
      !document.querySelector(".k-scheduler");
    if (newUiPage && !gridHasRendered && document.visibilityState !== "visible") {
      // Release the chain lock so the visibilitychange listener can restart
      // the run when the tab becomes visible again (pendingAutofill persists).
      afChainBusy = false;
      return;
    }
    chrome.storage.local.get("pendingAutofill").then(function (data) {
      var pa = data.pendingAutofill;
      if (!pa || pa.stage !== "scan") { afChainBusy = false; return; }
      if (pa.orgId !== orgIdFromLocation()) { afChainBusy = false; return; }
      if (Date.now() - pa.startedAt > 5 * 60 * 1000) { afChainBusy = false; return; } // stale — watchdog reports
      // Only the tab startAutofill CREATED may drive the run (see below).
      iAmAutofillTab(function (mine) {
        if (!mine) { afChainBusy = false; return; }
        maybeAutofillDrive(pa, continuation);
      });
    });
  }

  // pendingAutofill is global storage, so EVERY calendar tab can see it, and
  // the per-page chain lock doesn't span tabs: when the user clicked back to
  // their own calendar mid-run, THAT tab became the visible one and took
  // over the month-paging (Sep 24: "the beginning tab also started to look
  // at future months"). Content scripts can't read their own tab id, so ask
  // the service worker once and cache it.
  var myTabId = null, myTabIdFailed = false;
  function iAmAutofillTab(cb) {
    chrome.storage.local.get("autofillTabId").then(function (d) {
      var want = d.autofillTabId;
      if (!want) return cb(true); // nothing designated (legacy flow) — allow
      if (myTabId !== null) return cb(myTabId === want);
      if (myTabIdFailed) return cb(true); // can't find out — don't block the run
      try {
        chrome.runtime.sendMessage({ type: "whoami" }, function (res) {
          if (chrome.runtime.lastError || !res || res.tabId == null) {
            myTabIdFailed = true;
            cb(true);
            return;
          }
          myTabId = res.tabId;
          cb(myTabId === want);
        });
      } catch (e) { myTabIdFailed = true; cb(true); }
    });
  }

  function maybeAutofillDrive(pa, continuation) {
      if (afChainBusy && !continuation) return;
      afChainBusy = true;
      // CourtReserve remembers the last-viewed month SERVER-SIDE: a fresh
      // calendar tab opens on whatever month a previous run paged to (Sep 24:
      // runs opened on October, then December, …). Detection only pages
      // FORWARD, so a late start skips the current month — where the next
      // registration windows usually are. Reset to the current month once
      // per run before scanning.
      if (!pa.monthReset) {
        var view = newUiMonthYear(); // null on the old (Kendo) UI
        var nowD = new Date();
        var offMonth = view && (view.month !== nowD.getMonth() || view.year !== nowD.getFullYear());
        var tBtn = offMonth ? todayButton() : null;
        if (offMonth && !tBtn) {
          // Nav button not rendered yet — retry shortly WITHOUT consuming the
          // one-time reset, so we never scan a stale month by accident.
          setTimeout(function () { maybeAutofill(true); }, 1500);
          return;
        }
        var label = view ? (MONTHS[view.month].charAt(0).toUpperCase() + MONTHS[view.month].slice(1) + " " + view.year) : "";
        if (offMonth && tBtn) {
          CRLib.log("info", "Detect registration window",
            "This calendar opened on " + label + " — resetting to the current month before scanning.",
            "Searching");
        }
        chrome.storage.local.set({ pendingAutofill: Object.assign({}, pa, { monthReset: true }) })
          .then(function () {
            if (!offMonth || !tBtn) { maybeAutofill(true); return; }
            tBtn.click();
            // Wait for the current month to actually RENDER before scanning —
            // positive day-number signal, not skeleton absence (which never
            // clears; the testid stays mounted but hidden).
            CRLib.waitFor(gridReadyForScan, 20000, 800)
              .then(function () { setTimeout(function () { maybeAutofill(true); }, 1500); })
              .catch(function () { maybeAutofill(true); }); // wedged grid — recoverWedgedGrid handles it
          });
        return;
      }
      // v1.6.6: widen the calendar FILTER to cover the selected categories
      // once per run, before any scanning. The FILTER is remembered by
      // CourtReserve across tabs, so a user-side filter that hides a newly
      // selected category would otherwise make detection fail with "No
      // countdown found". Additive only — never unchecks anything. The
      // filterEnsured flag survives the details-page round-trip because
      // content-details.js rewrites pendingAutofill with a {...pa} spread.
      if (!pa.filterEnsured) {
        chrome.storage.local.set({ pendingAutofill: Object.assign({}, pa, { filterEnsured: true }) })
          .then(function () {
            return CRLib.settings.forOrg(pa.orgId).then(function (st) { return ensureFilterCoversSelection(st); });
          })
          .then(function (r) {
            if (r && r.added) {
              CRLib.log("info", "Detect registration window",
                "Added " + r.added + " selected categor" + (r.added === 1 ? "y" : "ies") +
                " to the calendar FILTER so detection can see " + (r.added === 1 ? "it" : "them") + ".",
                "FILTER");
            }
            if (r && r.error) {
              CRLib.log("warn", "Detect registration window",
                "Could not widen the calendar FILTER (" + r.error + ") — scanning anyway.", "FILTER");
            }
            maybeAutofill(true);
          })
          .catch(function () { maybeAutofill(true); }); // FILTER step failed — scan anyway
        return;
      }
      // Use the ORG-SCOPED keyword filter: the user tells us which event to
      // look for on this organization's calendar (e.g. "3.5+ Mixed Round
      // Robin" for Sunriver), and that may differ per organization.
      CRLib.settings.forOrg(pa.orgId).then(function (settings) {
        var needed = categoriesNeedingRules(settings, pa);
        // True when any derived rule in this run differs from what was stored
        // — silent validations only notify (and heal schedules) on a change.
        var anyChanged = (pa.saves || []).some(function (sv) { return sv.changed; });
        // Every selected category already has a rule (or had no candidate) —
        // the run is done. Report what was learned (or why nothing changed).
        if (needed && needed.length === 0 && pa.saveAs !== "global") {
          afChainBusy = false; // run is reporting out — chain ends here
          var summary = autofillSummary(pa);
          if (summary) {
            send({ type: "autofillResult", ok: true, orgId: pa.orgId, message: summary + autofillMissedNote(pa), changed: anyChanged });
          } else if ((pa.catTried || []).length) {
            send({
              type: "autofillResult", ok: false, orgId: pa.orgId,
              message: "No countdown found for: " + (pa.catTried || []).join(", ") + ".",
              changed: false,
            });
          } else {
            send({
              type: "autofillResult", ok: true, orgId: pa.orgId,
              message: "All selected categories already have a detected rule — nothing to do.",
              changed: false,
            });
          }
          return;
        }
        CRLib.waitFor(function () { return findAutofillCandidate(settings, pa.tried || [], needed); }, 25000, 800)
          .then(function (cand) {
            var url = new URL(cand.href, location.origin).href;
            chrome.storage.local
              .set({
                pendingAutofill: {
                  orgId: pa.orgId,
                  saveAs: pa.saveAs,
                  stage: "details",
                  startedAt: pa.startedAt,
                  tried: pa.tried || [],
                  catTried: pa.catTried || [],
                  saves: pa.saves || [],
                  revalidate: pa.revalidate === true,
                  silent: pa.silent === true,
                  // v1.6.7: preserve the one-time per-run step flags across
                  // the details round-trip — this fresh object previously
                  // DROPPED them, so after the first Details visit the run
                  // re-clicked Today (undoing month hops, resetting
                  // monthHops to 0) and re-ran the FILTER widen on a
                  // mid-navigation page, which failed "FILTER panel not
                  // found" (Oct 5 log).
                  monthReset: pa.monthReset === true,
                  monthHops: pa.monthHops || 0,
                  filterEnsured: pa.filterEnsured === true,
                  category: cand.category,
                  event: cand.parts.event,
                  date: cand.parts.date,
                  time: cand.parts.time,
                  detailsUrl: url,
                },
              })
              .then(function () { location.assign(url); });
          })
          .catch(function () {
            // No candidate in the CURRENT month view — before giving up,
            // page forward: a matching event's pre-registration window may
            // sit entirely inside next month (e.g. detection run late in the
            // month). Up to 2 hops (~3 months of horizon), then proceed.
            var hops = pa.monthHops || 0;
            // Hops exhausted or no Next button even after waiting: no
            // candidate among the needed categories — skip them and loop
            // once more (another category may still have a readable event),
            // else report out.
            var giveUp = function () {
              if (needed && needed.length && pa.saveAs !== "global") {
                var catTried = (pa.catTried || []).concat(needed);
                chrome.storage.local.set({ pendingAutofill: Object.assign({}, pa, { catTried: catTried }) })
                  .then(function () { maybeAutofill(true); });
                return;
              }
              var done = autofillSummary(pa);
              afChainBusy = false; // run is reporting out — chain ends here
              send({
                type: "autofillResult",
                ok: !!done,
                orgId: pa.orgId,
                changed: anyChanged,
                message: (done ? done + autofillMissedNote(pa) : null) ||
                  'No upcoming, not-yet-open event matching your keyword filter ("' +
                  (settings.eventFilter || "all events") +
                  '") was found on this month\'s calendar. The "Details" link and its countdown only appear before registration opens.',
              });
            };
            if (hops >= 2) { giveUp(); return; }
            // Don't decide on a single null reading of the Next button: right
            // after a month switch the nav bar can be mid-rerender, and a
            // one-shot null here killed a Sep 25 run — it reported "No
            // countdown found" without ever trying the next month, where
            // candidates existed. Wait up to 6 s for the button first.
            CRLib.waitFor(nextMonthButton, 6000, 400)
              .then(function (nextBtn) {
                CRLib.log("info", "Detect registration window",
                  "No candidate on this month's view — paging to next month (hop " + (hops + 1) + " of 2).",
                  "Searching");
                chrome.storage.local.set({ pendingAutofill: Object.assign({}, pa, { monthHops: hops + 1 }) })
                  .then(function () {
                    nextBtn.click();
                    // Wait for the new month's grid to actually RENDER — the
                    // nav label updates instantly but the data fetch + paint
                    // take longer, and scanning early finds zero events.
                    // Positive day-number signal (the skeleton testid never
                    // leaves the DOM, so absence checks time out uselessly).
                    CRLib.waitFor(gridReadyForScan, 20000, 800)
                      .then(function () { setTimeout(function () { maybeAutofill(true); }, 1500); })
                      .catch(function () {
                        // Still not rendered after 20s — the month may be
                        // wedged; kick the recovery now rather than waiting
                        // for the 30s interval (old UI has no skeleton).
                        recoverWedgedGrid();
                        maybeAutofill(true);
                      });
                  });
              })
              .catch(giveUp);
          });
      });
  }

  // The "Today" nav button, either UI: Kendo's button.k-nav-today, else the
  // new UI's plain "Today" button in the calendar nav group.
  function todayButton() {
    var k = document.querySelector("button.k-nav-today");
    if (k) return k;
    var btns = document.querySelectorAll("button, a, [role='button']");
    for (var i = 0; i < btns.length; i++) {
      if ((btns[i].textContent || "").trim() === "Today" && btns[i].offsetParent !== null) return btns[i];
    }
    return null;
  }

  // --- Fire-time hop 1: a scheduled run lands here first (stage 'calendar').
  // Click the Kendo scheduler's TODAY button to force a fresh data read, then
  // forward the tab to the event's details page for content-details.js. ---
  function maybeRunTaskCalendar() {
    if (!CRLib.ctxAlive()) return;
    chrome.storage.local.get("pendingTask").then(function (data) {
      var task = data.pendingTask;
      if (!task || task.stage !== "calendar") return;
      if (Date.now() - task.startedAt > 5 * 60 * 1000) return; // stale — watchdog reports
      if (task.orgId && task.orgId !== orgIdFromLocation()) return; // wrong org's calendar
      var forward = function () {
        task.stage = "details";
        task.progressAt = Date.now(); // heartbeat: forwarding to details page
        chrome.storage.local.set({ pendingTask: task }).then(function () {
          location.assign(task.detailsUrl);
        });
      };
      CRLib.waitFor(todayButton, 20000, 500)
        .then(function (btn) {
          btn.click(); // "Today" re-reads the scheduler data from the server
          return CRLib.sleep(2000).then(forward); // let the refresh land
        })
        .catch(forward); // no Today button — still proceed rather than stall
    });
  }

  // --- LRU: report user-driven calendar visits so the popup can sync to the
  // org being viewed and reopen the most recently used org's calendar. Tabs
  // opened by the extension's own automation (auto-register runs, Auto Fill
  // scans) are excluded — background activity is not "use". ---
  function reportOrgVisit() {
    if (!CRLib.ctxAlive()) return;
    if (/^#crh-activate/.test(location.hash || "")) return; // activation bounce — not "use"
    var orgId = orgIdFromLocation();
    if (!orgId) return;
    chrome.storage.local.get(["pendingTask", "pendingAutofill"]).then(function (data) {
      var now = Date.now();
      var pt = data.pendingTask;
      if (pt && pt.orgId === orgId && now - pt.startedAt < 5 * 60 * 1000) return;
      var pa = data.pendingAutofill;
      if (pa && pa.orgId === orgId && now - pa.startedAt < 5 * 60 * 1000) return;
      send({ type: "orgVisited", orgId: orgId });
    });
  }

  // --- Learn the user's organizations from the "My Clubs" account menu so the
  // popup's Organization dropdown can list them by name. ---
  function learnOrgsFromPage() {
    var out = [];
    var items = document.querySelectorAll('li[data-testid^="MyAccountMyClubsItem"]');
    for (var i = 0; i < items.length; i++) {
      var el = items[i];
      var m = /MyAccountMyClubsItem(\d+)/.exec(el.getAttribute("data-testid") || "");
      if (!m) continue;
      var nameEl = el.querySelector(".flex-between-100");
      var name = String((nameEl ? nameEl.textContent : el.textContent) || "")
        .replace(/\s+/g, " ").replace(/Primary\s*$/, "").trim();
      var badge = el.querySelector(".badge");
      out.push({ id: m[1], name: name, primary: !!(badge && /primary/i.test(badge.textContent || "")) });
    }
    var orgId = orgIdFromLocation();
    if (orgId) out.push({ id: orgId, name: "" }); // current org at least by id
    if (out.length) CRLib.orgs.learn(out);
  }

  // --- Learn the calendar's FILTER categories on every visit so the Settings
  // checklist stays fresh without a manual "Refresh Categories". Two FILTER
  // UIs: OLD — .custom-checkbox.rowCheckbox rows with .categ-line-color
  // swatches; NEW (React "Filter Events" drawer) — plain checkbox rows under
  // [data-testid="calendar-filter-categories-header"], only present once the
  // user expands the dropdown, and WITHOUT swatches (colors then come from a
  // Refresh read, which recovers them from the page's category API). Passive:
  // never clicks page controls — the mutation observer catches the rows when
  // they appear. A swatch-less read never erases colors already stored. ---
  function readCategoryRowsFromPage() {
    var out = [];
    var rows = document.querySelectorAll(".custom-checkbox.rowCheckbox");
    if (rows.length) {
      for (var i = 0; i < rows.length; i++) {
        var label = rows[i].querySelector("label.k-checkbox-label");
        var swatch = rows[i].querySelector(".categ-line-color");
        if (!label) continue;
        out.push({ name: label.innerText.trim(), color: swatch ? swatch.style.backgroundColor : "" });
      }
      return out;
    }
    var hdr = document.querySelector('[data-testid*="filter-categories-header"]');
    if (!hdr) return out;
    var card = hdr.parentElement || hdr;
    var boxes = card.querySelectorAll('input[type="checkbox"]');
    var seen = {};
    for (var m = 0; m < boxes.length; m++) {
      var rowEl = boxes[m].closest("label") || boxes[m].parentElement;
      var name = (rowEl && rowEl.textContent || "").replace(/\s+/g, " ").trim();
      if (!name || name.length > 60 || seen[name]) continue;
      seen[name] = 1;
      var sw = rowEl.querySelector('[style*="background"]') ||
        (rowEl.parentElement && rowEl.parentElement.querySelector('[style*="background"]'));
      out.push({ name: name, color: sw ? sw.style.backgroundColor || "" : "" });
    }
    return out;
  }

  function learnCategoriesFromPage() {
    var orgId = orgIdFromLocation();
    if (!orgId || !CRLib.ctxAlive()) return;
    var out = readCategoryRowsFromPage();
    if (!out.length) return;
    out.sort(function (a, b) { return a.name.localeCompare(b.name); });
    chrome.storage.local.get("orgCategories", function (res) {
      if (!CRLib.ctxAlive()) return;
      var oc = res.orgCategories || {};
      var existing = oc[orgId] || [];
      // Preserve colors: a swatch-less read (new UI) must not wipe colors a
      // Refresh recovered from the category API.
      var byName = {};
      existing.forEach(function (c) { if (c && c.name) byName[c.name] = c; });
      out = out.map(function (c) {
        return !c.color && byName[c.name] && byName[c.name].color
          ? { name: c.name, color: byName[c.name].color }
          : c;
      });
      if (JSON.stringify(existing) === JSON.stringify(out)) return; // no churn
      oc[orgId] = out;
      chrome.storage.local.set({ orgCategories: oc });
      CRLib.log("info", "Learn categories",
        "Learned " + out.length + " categor" + (out.length === 1 ? "y" : "ies") +
        " from this org's calendar page: " + out.map(function (c) { return c.name; }).join(", "),
        "Learned");
    });
  }

  // --- Activation landing reroute --------------------------------------------
  // The post-purchase success page links to a FIXED org's calendar carrying
  // #crh-activate=<key> (a static page can't know the user's club). If this
  // landing org isn't the user's most recently used org, reroute to the LRU
  // org's calendar — hash preserved, so the activation card still pre-fills
  // there. Runs before reportOrgVisit (which skips activation bounces) so the
  // fixed org never becomes the LRU through this flow.
  function maybeActivationRedirect() {
    if (!/^#crh-activate/.test(location.hash || "")) return;
    if (!CRLib.ctxAlive()) return;
    chrome.storage.local.get("lruOrg").then(function (data) {
      var lru = data.lruOrg && /^\d+$/.test(String(data.lruOrg.id || "")) ? String(data.lruOrg.id) : "";
      var cur = orgIdFromLocation();
      if (lru && cur && lru !== cur) {
        location.replace(
          "https://app.courtreserve.com/Online/Calendar/Events/" + lru + "/Month" + location.hash
        );
      }
    });
  }

  // --- Premium activation card ------------------------------------------------
  // The post-purchase success page (dkitzmiller.github.io/success.html) links
  // here as .../Month#crh-activate=<license_key>. Chrome forbids web pages
  // from opening the extension popup, so instead a card appears right on the
  // calendar — key pre-filled, one click to activate. The hash never reaches
  // any server, and is stripped from the URL after a successful activation.
  function maybeActivationCard() {
    // CourtReserve's SPA strips the URL fragment while the page boots, so by
    // document_idle location.hash is usually empty. The document_start
    // capture script (content-activate-capture.js) parks it in sessionStorage.
    var raw = location.hash || "";
    if (!/^#crh-activate/.test(raw)) {
      try { raw = sessionStorage.getItem("crh-activate-hash") || ""; } catch (e) { raw = ""; }
    }
    var m = /^#crh-activate(?:=(.*))?$/.exec(raw);
    if (!m) return;
    try { sessionStorage.removeItem("crh-activate-hash"); } catch (e) {}
    var keyFromHash = m[1] ? decodeURIComponent(m[1]) : "";
    CRLib.license.get().then(function (lic) {
      if (CRLib.license.isPremium(lic)) return; // already active — nothing to do
      if (document.getElementById("crx-activate-card")) return;
      var card = document.createElement("div");
      card.id = "crx-activate-card";
      card.style.cssText =
        "position:fixed;top:14px;right:14px;z-index:99999;width:300px;" +
        "background:#fff;border:1px solid #e7e5e4;border-radius:12px;padding:16px;" +
        "box-shadow:0 12px 32px rgba(0,0,0,.18);" +
        "font:13px/1.5 -apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;color:#1c1917;";
      card.innerHTML =
        '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px;">' +
        '<b style="font-size:14px;">🎉 Activate Premium</b>' +
        '<button type="button" data-x style="border:none;background:none;font-size:17px;cursor:pointer;color:#78716c;line-height:1;">×</button></div>' +
        '<div style="color:#57534e;font-size:12px;margin-bottom:8px;">Unlock ⏰ Auto-Register with your license key.</div>' +
        '<input type="text" placeholder="XXXX-XXXX-XXXX-XXXX" style="width:100%;box-sizing:border-box;padding:6px 9px;font-size:13px;border:1px solid #e7e5e4;border-radius:7px;margin-bottom:8px;">' +
        '<button type="button" data-go style="width:100%;padding:6px 0;font-size:12.5px;font-weight:700;border:none;border-radius:8px;background:#0d9488;color:#fff;cursor:pointer;">Activate license</button>' +
        '<div data-msg style="font-size:11.5px;margin-top:6px;color:#78716c;"></div>';
      (document.body || document.documentElement).appendChild(card);
      var input = card.querySelector("input");
      var msg = card.querySelector("[data-msg]");
      if (keyFromHash) {
        input.value = keyFromHash;
        msg.textContent = "Key pre-filled from your purchase — just click Activate.";
      }
      card.querySelector("[data-x]").addEventListener("click", function () { card.remove(); });
      card.querySelector("[data-go]").addEventListener("click", function () {
        if (!CRLib.ctxAlive()) { staleNotice(); return; }
        msg.style.color = "#78716c";
        msg.textContent = "Activating…";
        try {
          chrome.runtime.sendMessage(
            { type: "licenseActivate", key: input.value.trim(), deviceName: "Calendar card" },
            function (r) {
              if (chrome.runtime.lastError) {
                msg.style.color = "#b91c1c";
                msg.textContent = "⚠ " + chrome.runtime.lastError.message;
                return;
              }
              if (r && r.ok) {
                card.innerHTML =
                  '<div style="color:#15803d;font-weight:700;">✅ Premium active — ⏰ Auto-Register unlocked.</div>';
                // Drop the hash so a refresh doesn't re-show the card.
                history.replaceState(null, "", location.pathname + location.search);
                setTimeout(function () { card.remove(); }, 6000);
              } else {
                msg.style.color = "#b91c1c";
                msg.textContent = "⚠ " + ((r && r.message) || "Activation failed.");
              }
            }
          );
        } catch (e) { staleNotice(); }
      });
    });
  }

  function start() {
    maybeActivationRedirect(); // may bounce this page to the LRU org's calendar
    scan();
    maybeAutofill();
    maybeRunTaskCalendar();
    maybeActivationCard();
    reportOrgVisit();
    // The account menu renders asynchronously — try now and again shortly.
    learnOrgsFromPage();
    setTimeout(learnOrgsFromPage, 3000);
    // FILTER categories: same lazy-render caveat — try now, then twice more.
    learnCategoriesFromPage();
    setTimeout(learnCategoriesFromPage, 3000);
    setTimeout(learnCategoriesFromPage, 8000);
    // If STILL nothing after 12s, say so once in the Log pane — otherwise a
    // club with an empty/lazy/unfamiliar FILTER panel is indistinguishable
    // from a bug. (Later renders are still caught by the mutation observer.)
    setTimeout(function () {
      if (!CRLib.ctxAlive()) return;
      if (readCategoryRowsFromPage().length) return;
      CRLib.log("info", "Learn categories",
        "No FILTER category rows on this calendar page (org " + (orgIdFromLocation() || "?") +
        ") after 12s — the club may use no categories, the FILTER panel may still be closed " +
        "(categories appear once its Categories dropdown is expanded), or its markup differs.",
        "None found");
    }, 12000);
    observer.observe(document.body, { childList: true, subtree: true });
    // The autofill scanner only runs on the VISIBLE tab (hidden tabs can't
    // render the new-UI grid) — when this tab becomes visible mid-run, pick
    // up the pending work.
    document.addEventListener("visibilitychange", function () {
      if (document.visibilityState === "visible") {
        maybeAutofill();
        setTimeout(recoverWedgedGrid, 8000);
      }
    });
    // New-UI grids can wedge on the loading skeleton — check once the page
    // has had time to settle (and again on each return to this tab, above).
    setTimeout(recoverWedgedGrid, 15000);
    // …and keep checking: month HOPS can strand the new month on the skeleton
    // long after load (Sep 24: run hopped Sept→Oct, October never rendered,
    // no candidate, run failed). Cheap DOM probe, self-guarding (one reload
    // per tab), so a light interval covers every path.
    setInterval(recoverWedgedGrid, 30000);
    // Belt-and-suspenders for the trigger race: start()'s initial read can
    // miss a pendingAutofill write that lands microseconds later (before the
    // onChanged listener below is registered). Delayed re-reads close that
    // gap — no-ops when no run is pending.
    setTimeout(maybeAutofill, 2000);
    setTimeout(maybeAutofill, 6000);
    chrome.storage.onChanged.addListener(function (changes, area) {
      if (area === "local" && changes.pendingAutofill) {
        // The run's trigger write can land AFTER this page's start() already
        // read storage (tab opens and renders while the service worker is
        // still mid-write — Sep 25: run tab sat idle on October with the
        // chain never started). Re-kick maybeAutofill on every change.
        maybeAutofill();
      }
      if (area === "local" && (changes.entries || changes.settings || changes.license)) {
        // Entries/settings/license changed — drop injected buttons and
        // indicators so labels flip (Auto-Register ↔ Remove ↔ locked Premium)
        // and the bold date markers toggle on the re-scan.
        var old = document.querySelectorAll("." + BTN_CLASS);
        for (var i = 0; i < old.length; i++) old[i].remove();
        var oldCells = document.querySelectorAll(".k-event");
        for (var oc = 0; oc < oldCells.length; oc++) clearOpenHover(oldCells[oc]);
        var marked = document.querySelectorAll("." + DAY_CLASS + ", ." + IND_CLASS);
        for (var j = 0; j < marked.length; j++) {
          marked[j].classList.remove(DAY_CLASS);
          marked[j].classList.remove(IND_CLASS);
          marked[j].removeAttribute("title");
        }
        scan();
      }
    });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", start);
  } else {
    start();
  }
})();
