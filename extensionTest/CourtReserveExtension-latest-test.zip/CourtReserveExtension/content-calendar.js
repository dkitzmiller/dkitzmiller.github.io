/**
 * Content script: CourtReserve calendar pages.
 *
 * Scans every .k-event cell and injects an "⏰ Auto-Register" button into
 * events whose registration window has NOT opened yet (per-category rule,
 * falling back to the org's days-before/opening-time rule). If an
 * auto-register entry already exists for that event instance, the button
 * reads "Remove Auto-Register" instead and cancels the schedule on click.
 *
 * Cell anatomy (Kendo scheduler):
 *   <div class="k-event" aria-label="Name on Friday, August 14, 2026 at 10:00 AM to 12:00 PM">
 *     <div class="link-k-event" data-href="/Online/Events/Details/2319/AEN4ZEW2319474">…
 * Not-yet-open cells show availability + a "Details" link but no REGISTER /
 * FULL / EDIT REGISTRATION action label.
 */
(function () {
  "use strict";

  var BTN_CLASS = "crx-autoreg-btn";
  var DAY_CLASS = "crx-opens-day";      // bold date-number marker (visual)
  var IND_CLASS = "crx-opens-pill";     // event-pill marker (tooltip + cleanup)
  var HOT_CLASS = "crx-opens-hot";      // date number while hovered (green)
  var TARGET_CLASS = "crx-opens-target";// event cells linked to a hovered date

  // Inject our stylesheet once.
  function ensureStyle() {
    if (document.getElementById("crx-autoreg-style")) return;
    var style = document.createElement("style");
    style.id = "crx-autoreg-style";
    style.textContent =
      "." + BTN_CLASS + "{" +
      "display:inline-block;margin-top:3px;padding:1px 8px;font-size:10.5px;font-weight:600;" +
      "line-height:1.5;border:none;border-radius:8px;cursor:pointer;" +
      "background:#0d9488;color:#fff;box-shadow:0 1px 2px rgba(0,0,0,.35);z-index:50;position:relative;}" +
      "." + BTN_CLASS + ":hover{background:#0f766e;}" +
      "." + BTN_CLASS + ".crx-remove{background:#b91c1c;}" +
      "." + BTN_CLASS + ".crx-remove:hover{background:#991b1b;}" +
      "." + BTN_CLASS + ".crx-lock{background:#7c3aed;}" +
      "." + BTN_CLASS + ".crx-lock:hover{background:#6d28d9;}" +
      // Date-number marker on the day registration OPENS: bold + black.
      "." + DAY_CLASS + "{font-weight:700 !important;color:#000 !important;cursor:pointer;}" +
      // While hovered, the date goes bright green and the matching event
      // cells light up in the same green — the link is unmistakable.
      "." + DAY_CLASS + "." + HOT_CLASS + "{color:#16a34a !important;}" +
      "." + TARGET_CLASS + "{box-shadow:0 0 0 3px #16a34a !important;background:rgba(34,197,94,.22) !important;}";
    document.head.appendChild(style);
  }

  function orgIdFromLocation() {
    var m = /\/Online\/Calendar\/Events\/(\d+)/.exec(location.pathname);
    return m ? m[1] : "";
  }

  function instanceIdFromHref(href) {
    var m = /\/Online\/Events\/Details\/\d+\/([A-Za-z0-9]+)/.exec(href || "");
    return m ? m[1] : "";
  }

  // The event cell's category color: CourtReserve colors every event by its
  // category (the same colors shown in the FILTER panel), carried on an inner
  // div's inline background. Used for category-mode filter matching.
  function cellBgColor(cell) {
    var inner = cell.querySelector("[style*=background]");
    return inner && inner.style ? inner.style.background : "";
  }

  // If the extension was reloaded/updated, this page's copy of the script is
  // orphaned — chrome.* calls would throw "Extension context invalidated".
  // Fail quietly (storage is guarded inside CRLib); only user clicks explain.
  var staleNotified = false;
  function staleNotice() {
    if (staleNotified) return;
    staleNotified = true;
    alert("The CourtReserve extension was reloaded or updated.\nRefresh this page to keep using it.");
  }
  function send(msg) {
    if (!CRLib.ctxAlive()) { staleNotice(); return; }
    try { chrome.runtime.sendMessage(msg); } catch (e) { staleNotice(); }
  }

  /** Cell text without our injected button (its label contains "Register"). */
  function cleanCellText(cell) {
    var clone = cell.cloneNode(true);
    var injected = clone.querySelectorAll("." + BTN_CLASS);
    for (var i = 0; i < injected.length; i++) injected[i].remove();
    return (clone.textContent || "").replace(/\s+/g, " ").trim();
  }

  /** Drop the event→opening-date hover link (window passed, event opened). */
  function clearOpenHover(cell) {
    if (cell._crxOpenLabel) {
      cell._crxOpenLabel.classList.remove(HOT_CLASS);
      cell._crxOpenLabel = null;
    }
    cell.onmouseenter = null;
    cell.onmouseleave = null;
  }

  /**
   * Map a date to its visible day-number label (the .k-nav-day span). The
   * event pills live in an overlay (.k-scheduler-content), NOT inside the
   * day cells, so DOM ancestry can't find the day — map by date instead:
   * the .k-nav-day spans form the 6x7 grid in row-major order; the first
   * in-month cell is the "01" whose TD lacks k-other-month; the view
   * month/year comes from the "August 2026" label. Returns a lookup
   * function (null-safe).
   */
  function dayLabelFor() {
    var none = function () { return null; };
    var labelEl = document.querySelector(".k-lg-date-format, .k-sm-date-format");
    var m = /^([A-Za-z]+)\s+(\d{4})$/.exec((labelEl ? labelEl.textContent : "").trim());
    if (!m) return none;
    var first = new Date(m[1] + " 1, " + m[2] + " 12:00"); // noon: DST-safe
    if (isNaN(first)) return none;
    var spans = document.querySelectorAll(".k-nav-day");
    if (spans.length < 35) return none; // grid still rendering — retry next scan
    var i0 = -1;
    for (var i = 0; i < spans.length; i++) {
      var td = spans[i].closest("td");
      if ((spans[i].textContent || "").trim() === "01" && td && !td.classList.contains("k-other-month")) {
        i0 = i;
        break;
      }
    }
    if (i0 === -1) return none;
    return function (date) {
      var noon = new Date(date.getFullYear(), date.getMonth(), date.getDate(), 12);
      var idx = i0 + Math.round((noon - first) / 86400000);
      if (idx < 0 || idx >= spans.length) return null;
      // sanity: the grid cell's day number must match the event's day
      if (Number((spans[idx].textContent || "").trim()) !== date.getDate()) return null;
      return spans[idx];
    };
  }

  function scan() {
    if (!CRLib.ctxAlive()) { observer.disconnect(); return; } // orphaned by extension reload
    ensureStyle();
    var orgId = orgIdFromLocation();
    CRLib.settings.forOrg(orgId).then(function (settings) {
      var dayLabelAt = settings.showOpensIndicator === true ? dayLabelFor() : null;
      // Reconcile date-number markers from scratch every scan: Kendo builds
      // the grid asynchronously, so a mark made during a mid-render pass
      // could otherwise stick to the wrong label.
      var oldMarks = document.querySelectorAll("." + DAY_CLASS);
      for (var om = 0; om < oldMarks.length; om++) {
        oldMarks[om].classList.remove(DAY_CLASS);
        oldMarks[om].removeAttribute("title");
      }
      var oldPills = document.querySelectorAll("." + IND_CLASS);
      for (var op = 0; op < oldPills.length; op++) {
        oldPills[op].classList.remove(IND_CLASS);
        oldPills[op].removeAttribute("title");
      }
      var oldTargets = document.querySelectorAll("." + TARGET_CLASS);
      for (var ot = 0; ot < oldTargets.length; ot++) oldTargets[ot].classList.remove(TARGET_CLASS);
      Promise.all([CRLib.store.list(), CRLib.license.get()]).then(function (res) {
      var entries = res[0];
      var premium = CRLib.license.isPremium(res[1]);
      // One entry per occurrence: identity is org + event + date + time.
      // (CourtReserve rotates the Details-link token, so it can't be the key.)
      var byKey = {};
      entries.forEach(function (e) { byKey[CRLib.entryKey(e.orgId, e)] = e; });

      var cells = document.querySelectorAll(".k-event");
      // "Registration opens" indicator: collected for EVERY matching not-open
      // cell — including ones whose button was already injected — and applied
      // to the date numbers after the loop. The marker lands on the day
      // registration OPENS (e.g. Aug 23), not the event's own day (e.g. Aug 31).
      var opensByDay = {}; // "y-m-d" -> { date: Date, events: [label], cells: [el] }
      for (var i = 0; i < cells.length; i++) {
        var cell = cells[i];

        var label = cell.getAttribute("aria-label") || "";
        var parts = CRLib.parseEventLabel(label);
        if (!parts) continue;
        // Category/keyword allowlist (e.g. the "4.0+ RR" category). A cell
        // that fails the filter is skipped — UNLESS an entry already exists
        // for it: the Remove Auto-Register button must stay reachable even
        // when the event no longer matches the current picks. (Nothing
        // picked at all → nothing matches → no new ⏰ buttons anywhere.)
        var key = CRLib.entryKey(orgId, parts);
        var entry = byKey[key];
        var cellBg = cellBgColor(cell);
        // The category this cell belongs to (by color) drives which window
        // rule applies — registration windows can differ per category.
        var catName = CRLib.categoryNameForColor(settings, cellBg);
        if (!entry && !CRLib.eventMatchesScoped(parts.event, cellBg, settings)) continue;

        // Only events whose registration has NOT opened yet get a button.
        var status = CRLib.cellStatus(cleanCellText(cell));
        if (status !== "not-open") {
          clearOpenHover(cell); // window now open — hover link is obsolete
          continue;
        }
        var eventDate = CRLib.parseLongDate(parts.date);
        if (!eventDate) continue;

        if (settings.showOpensIndicator === true) {
          var opensAt = CRLib.registrationOpens(eventDate, settings, catName);
          // Fallback rules are guesses — label them so a wrong opening time
          // is never mistaken for a detected one.
          var est = !CRLib.windowRuleKnown(settings, catName);
          if (opensAt.getTime() > Date.now()) { // only while still closed
            var dayKey = opensAt.getFullYear() + "-" + opensAt.getMonth() + "-" + opensAt.getDate();
            var bucket = opensByDay[dayKey];
            if (!bucket) bucket = opensByDay[dayKey] = { date: opensAt, events: [], cells: [] };
            var evLabel = parts.event + " (" + (eventDate.getMonth() + 1) + "/" + eventDate.getDate() + ")" +
              (est ? " — est." : "");
            if (bucket.events.indexOf(evLabel) === -1) bucket.events.push(evLabel);
            bucket.cells.push(cell);
            if (!cell.classList.contains(IND_CLASS)) {
              cell.classList.add(IND_CLASS);
            }
            cell.title = "Registration opens " + CRLib.fmtDateTime(opensAt) +
              (est ? " (estimated — run Get settings from CourtReserve)" : "") +
              " — be ready to register.";
            // Event → date direction: hovering the event cell flashes the
            // opening date number bright green (the bolded date's own hover
            // already frames the event cells — this is the reverse link).
            var openLbl = dayLabelAt ? dayLabelAt(opensAt) : null;
            if (openLbl) {
              cell._crxOpenLabel = openLbl;
              cell.onmouseenter = function () { this._crxOpenLabel.classList.add(HOT_CLASS); };
              cell.onmouseleave = function () { this._crxOpenLabel.classList.remove(HOT_CLASS); };
            }
          } else {
            clearOpenHover(cell); // opening moment has passed
          }
        }

        if (cell.querySelector("." + BTN_CLASS)) continue; // already injected

        var link = cell.querySelector(".link-k-event");
        var href = link ? link.getAttribute("data-href") : null;
        var instanceId = instanceIdFromHref(href);
        if (!instanceId) continue;
        // Schedulable only until 1 hour before opening (the "limbo" hour).
        var cutoff = CRLib.scheduleCutoff(eventDate, settings, catName).getTime();
        if (cutoff <= Date.now()) continue;
        // Anyone can hide the buttons in Calendar options (default: shown) —
        // for free users that hides the 🔒 upgrade button too. Non-dismissible
        // promotional UI injected into a third-party page is a store-policy
        // gray area, so the toggle is honored for both tiers.
        if (settings.showAutoRegButtons === false) continue;
        var rule = CRLib.windowRuleFor(settings, catName);
        var ruleEst = !CRLib.windowRuleKnown(settings, catName);
        var fireAt = CRLib.fireTime(eventDate, settings, catName).getTime();

        // key/entry were resolved up front (before the filter check) so a
        // stored entry keeps its Remove button even off-filter.
        if (entry) {
          // Self-heal: the link token rotated (or the rule changed) since
          // this event was scheduled — refresh identity/link/fire time in
          // place rather than letting a second entry coexist with the first.
          var absUrl = new URL(href, location.origin).href;
          if (entry.id !== key || entry.instanceId !== instanceId ||
              entry.detailsUrl !== absUrl || entry.fireAt !== fireAt) {
            var healed = {};
            for (var field in entry) healed[field] = entry[field];
            healed.id = key;
            healed.instanceId = instanceId;
            healed.detailsUrl = absUrl;
            healed.fireAt = fireAt;
            send({ type: "heal", oldId: entry.id, entry: healed });
            entry = healed;
            byKey[key] = healed;
          }
        }
        var btn = document.createElement("button");
        btn.type = "button";
        if (!premium) {
          // Free tier: visible-but-locked — the upgrade path, not the feature.
          btn.className = BTN_CLASS + " crx-lock";
          btn.textContent = "🔒 Auto-Register — Premium";
          btn.title = "Auto-registration is a Premium feature — click to upgrade.";
          btn.addEventListener("click", function (ev) {
            ev.stopPropagation();
            ev.preventDefault();
            window.open(CRLib.UPGRADE_URL, "_blank", "noopener");
          });
        } else {
        btn.className = BTN_CLASS + (entry ? " crx-remove" : "");
        btn.textContent = entry ? "⏰ Remove Auto-Register" : "⏰ Auto-Register";
        btn.title = entry
          ? "Auto-register scheduled — fires " + CRLib.fmtDateTime(new Date(entry.fireAt)) + ". Click to cancel."
          : "Schedule auto-register for " + parts.event + " — fires " + CRLib.fmtDateTime(new Date(fireAt)) +
            " (" + settings.fireDelayMinutes + " min after registration opens, " + rule.daysBefore + " days before the event at " + rule.openTime +
            (catName ? ", " + catName + " rule" : "") + (ruleEst ? " — estimated" : "") + ").";

        (function (entryRef, entryId, entryParts, entryHref, entryFireAt) {
          btn.addEventListener("click", function (ev) {
            ev.stopPropagation();
            ev.preventDefault();
            if (entryRef) {
              send({ type: "cancel", id: entryId });
            } else {
              var newEntry = {
                id: entryId,
                orgId: orgId,
                instanceId: instanceIdFromHref(entryHref),
                event: entryParts.event,
                date: entryParts.date,
                time: entryParts.time,
                detailsUrl: new URL(entryHref, location.origin).href,
                fireAt: entryFireAt,
                status: "scheduled",
                retryCount: 0,
                createdAt: new Date().toISOString(),
              };
              send({ type: "schedule", entry: newEntry });
            }
          });
        })(entry, key, parts, href, fireAt);
        } // end premium / free-tier button branch

        // Append inside the reservation container so it sits under the status line.
        var container = cell.querySelector(".reservation-container") || cell;
        container.appendChild(btn);
      }
      // Apply the collected "opens" markers to the OPEN-day date numbers.
      // Several events can open on the same day — the tooltip lists them all.
      // Hovering a marked date turns it green and frames its event cells in
      // the same green; leaving restores the plain bold-black marker.
      if (settings.showOpensIndicator === true && dayLabelAt) {
        for (var dk in opensByDay) {
          var bucket2 = opensByDay[dk];
          var openLabel = dayLabelAt(bucket2.date);
          if (!openLabel) continue; // open day not visible in this view
          openLabel.classList.add(DAY_CLASS);
          openLabel.title = "Registration opens " + CRLib.fmtDateTime(bucket2.date) +
            " for:\n• " + bucket2.events.join("\n• ");
          openLabel._crxCells = bucket2.cells; // refresh: Kendo re-renders pills
          if (!openLabel._crxHoverBound) {
            openLabel._crxHoverBound = true;
            openLabel.addEventListener("mouseenter", function () {
              this.classList.add(HOT_CLASS);
              var cs = this._crxCells || [];
              for (var k = 0; k < cs.length; k++) cs[k].classList.add(TARGET_CLASS);
            });
            openLabel.addEventListener("mouseleave", function () {
              this.classList.remove(HOT_CLASS);
              var cs = this._crxCells || [];
              for (var k = 0; k < cs.length; k++) cs[k].classList.remove(TARGET_CLASS);
            });
          }
        }
      }
      });
    });
  }

  // Kendo re-renders the calendar on every navigation — observe and re-scan
  // (debounced), and re-scan whenever the stored entries or settings change.
  var timer = null;
  var observer = new MutationObserver(function () {
    clearTimeout(timer);
    timer = setTimeout(scan, 400);
  });

  // --- Auto Fill: pick a not-yet-open event matching the keyword filter and
  // follow its Details link so content-details.js can read the countdown.
  // Registration windows differ PER CATEGORY, so one run loops: derive a rule
  // for each selected category that doesn't have one yet, then finish. ---
  function findAutofillCandidate(settings, tried, neededCats) {
    var today = new Date();
    today = new Date(today.getFullYear(), today.getMonth(), today.getDate());
    var best = null; // furthest-future candidate — most likely still pre-registration
    var cells = document.querySelectorAll(".k-event");
    for (var i = 0; i < cells.length; i++) {
      var cell = cells[i];
      var parts = CRLib.parseEventLabel(cell.getAttribute("aria-label") || "");
      if (!parts) continue;
      var cellBg = cellBgColor(cell);
      if (!CRLib.eventMatchesScoped(parts.event, cellBg, settings)) continue;
      // Only not-yet-open cells show the "Details" link with the countdown.
      // Past AND same-day events look identical here but their countdown is
      // gone — so we require a future date and then prefer the latest one.
      if (CRLib.cellStatus(cleanCellText(cell)) !== "not-open") continue;
      var eventDate = CRLib.parseLongDate(parts.date);
      if (!eventDate || eventDate.getTime() <= today.getTime()) continue;
      var link = cell.querySelector(".link-k-event");
      var href = link ? link.getAttribute("data-href") : null;
      if (!href) continue;
      if (tried && tried.indexOf(instanceIdFromHref(href)) !== -1) continue; // already attempted
      var catName = CRLib.categoryNameForColor(settings, cellBg);
      // When specific categories still need a rule, only their events qualify.
      if (neededCats && neededCats.length && neededCats.indexOf(catName) === -1) continue;
      if (!best || eventDate.getTime() > best.eventDate.getTime()) {
        best = { parts: parts, href: href, eventDate: eventDate, category: catName };
      }
    }
    return best;
  }

  // Selected categories still missing a per-category window rule. Categories
  // known to have no countdown (event type never shows one) are skipped.
  function categoriesNeedingRules(settings, pa) {
    var cats = settings.eventFilterCategories || [];
    if (!cats.length) return null; // text mode / no picks: legacy single-shot
    var windows = settings.categoryWindows || {};
    var noCd = settings.noCountdownCategories || [];
    var skipped = (pa && pa.catTried) || [];
    var out = [];
    for (var i = 0; i < cats.length; i++) {
      var n = cats[i].name;
      if (!windows[n] && noCd.indexOf(n) === -1 && skipped.indexOf(n) === -1) out.push(n);
    }
    return out;
  }

  function autofillSummary(pa) {
    var saves = pa.saves || [];
    if (!saves.length) return "";
    var bits = saves.map(function (sv) {
      return (sv.category ? sv.category + ": " : "") + sv.daysBefore + " day(s) before at " + sv.openTime;
    });
    return "Detected on " + pa.orgId + "'s calendar — " + bits.join("; ") + ". Saved per category.";
  }

  // Categories whose event pages showed no countdown get named, so a missing
  // rule tag in the list is explained rather than mysterious.
  function autofillMissedNote(pa) {
    var missed = (pa.catTried || []);
    if (!missed.length) return "";
    return " No countdown found for: " + missed.join(", ") + ".";
  }

  function maybeAutofill() {
    if (!CRLib.ctxAlive()) return;
    chrome.storage.local.get("pendingAutofill").then(function (data) {
      var pa = data.pendingAutofill;
      if (!pa || pa.stage !== "scan") return;
      if (pa.orgId !== orgIdFromLocation()) return;
      if (Date.now() - pa.startedAt > 5 * 60 * 1000) return; // stale — watchdog reports
      // Use the ORG-SCOPED keyword filter: the user tells us which event to
      // look for on this organization's calendar (e.g. "3.5+ Mixed Round
      // Robin" for Sunriver), and that may differ per organization.
      CRLib.settings.forOrg(pa.orgId).then(function (settings) {
        var needed = categoriesNeedingRules(settings, pa);
        // Every selected category already has a rule (or had no candidate) —
        // the run is done. Report what was learned (or why nothing changed).
        if (needed && needed.length === 0 && pa.saveAs !== "global") {
          var summary = autofillSummary(pa);
          if (summary) {
            send({ type: "autofillResult", ok: true, orgId: pa.orgId, message: summary + autofillMissedNote(pa) });
          } else if ((pa.catTried || []).length) {
            send({
              type: "autofillResult", ok: false, orgId: pa.orgId,
              message: "No countdown found for: " + (pa.catTried || []).join(", ") + ".",
            });
          } else {
            send({
              type: "autofillResult", ok: true, orgId: pa.orgId,
              message: "All selected categories already have a detected rule — nothing to do.",
            });
          }
          return;
        }
        CRLib.waitFor(function () { return findAutofillCandidate(settings, pa.tried || [], needed); }, 25000, 800)
          .then(function (cand) {
            var url = new URL(cand.href, location.origin).href;
            chrome.storage.local
              .set({
                pendingAutofill: {
                  orgId: pa.orgId,
                  saveAs: pa.saveAs,
                  stage: "details",
                  startedAt: pa.startedAt,
                  tried: pa.tried || [],
                  catTried: pa.catTried || [],
                  saves: pa.saves || [],
                  category: cand.category,
                  event: cand.parts.event,
                  date: cand.parts.date,
                  time: cand.parts.time,
                  detailsUrl: url,
                },
              })
              .then(function () { location.assign(url); });
          })
          .catch(function () {
            // No candidate among the needed categories — skip them and loop
            // once more (another category may still have a readable event).
            if (needed && needed.length && pa.saveAs !== "global") {
              var catTried = (pa.catTried || []).concat(needed);
              chrome.storage.local.set({ pendingAutofill: Object.assign({}, pa, { catTried: catTried }) })
                .then(function () { maybeAutofill(); });
              return;
            }
            var done = autofillSummary(pa);
            send({
              type: "autofillResult",
              ok: !!done,
              orgId: pa.orgId,
              message: (done ? done + autofillMissedNote(pa) : null) ||
                'No upcoming, not-yet-open event matching your keyword filter ("' +
                (settings.eventFilter || "all events") +
                '") was found on this month\'s calendar. The "Details" link and its countdown only appear before registration opens.',
            });
          });
      });
    });
  }

  // --- Fire-time hop 1: a scheduled run lands here first (stage 'calendar').
  // Click the Kendo scheduler's TODAY button to force a fresh data read, then
  // forward the tab to the event's details page for content-details.js. ---
  function maybeRunTaskCalendar() {
    if (!CRLib.ctxAlive()) return;
    chrome.storage.local.get("pendingTask").then(function (data) {
      var task = data.pendingTask;
      if (!task || task.stage !== "calendar") return;
      if (Date.now() - task.startedAt > 5 * 60 * 1000) return; // stale — watchdog reports
      if (task.orgId && task.orgId !== orgIdFromLocation()) return; // wrong org's calendar
      var forward = function () {
        task.stage = "details";
        chrome.storage.local.set({ pendingTask: task }).then(function () {
          location.assign(task.detailsUrl);
        });
      };
      CRLib.waitFor(function () { return document.querySelector("button.k-nav-today"); }, 20000, 500)
        .then(function (btn) {
          btn.click(); // "Today" re-reads the scheduler data from the server
          return CRLib.sleep(2000).then(forward); // let the refresh land
        })
        .catch(forward); // no Today button — still proceed rather than stall
    });
  }

  // --- LRU: report user-driven calendar visits so the popup can sync to the
  // org being viewed and reopen the most recently used org's calendar. Tabs
  // opened by the extension's own automation (auto-register runs, Auto Fill
  // scans) are excluded — background activity is not "use". ---
  function reportOrgVisit() {
    if (!CRLib.ctxAlive()) return;
    if (/^#crh-activate/.test(location.hash || "")) return; // activation bounce — not "use"
    var orgId = orgIdFromLocation();
    if (!orgId) return;
    chrome.storage.local.get(["pendingTask", "pendingAutofill"]).then(function (data) {
      var now = Date.now();
      var pt = data.pendingTask;
      if (pt && pt.orgId === orgId && now - pt.startedAt < 5 * 60 * 1000) return;
      var pa = data.pendingAutofill;
      if (pa && pa.orgId === orgId && now - pa.startedAt < 5 * 60 * 1000) return;
      send({ type: "orgVisited", orgId: orgId });
    });
  }

  // --- Learn the user's organizations from the "My Clubs" account menu so the
  // popup's Organization dropdown can list them by name. ---
  function learnOrgsFromPage() {
    var out = [];
    var items = document.querySelectorAll('li[data-testid^="MyAccountMyClubsItem"]');
    for (var i = 0; i < items.length; i++) {
      var el = items[i];
      var m = /MyAccountMyClubsItem(\d+)/.exec(el.getAttribute("data-testid") || "");
      if (!m) continue;
      var nameEl = el.querySelector(".flex-between-100");
      var name = String((nameEl ? nameEl.textContent : el.textContent) || "")
        .replace(/\s+/g, " ").replace(/Primary\s*$/, "").trim();
      var badge = el.querySelector(".badge");
      out.push({ id: m[1], name: name, primary: !!(badge && /primary/i.test(badge.textContent || "")) });
    }
    var orgId = orgIdFromLocation();
    if (orgId) out.push({ id: orgId, name: "" }); // current org at least by id
    if (out.length) CRLib.orgs.learn(out);
  }

  // --- Activation landing reroute --------------------------------------------
  // The post-purchase success page links to a FIXED org's calendar carrying
  // #crh-activate=<key> (a static page can't know the user's club). If this
  // landing org isn't the user's most recently used org, reroute to the LRU
  // org's calendar — hash preserved, so the activation card still pre-fills
  // there. Runs before reportOrgVisit (which skips activation bounces) so the
  // fixed org never becomes the LRU through this flow.
  function maybeActivationRedirect() {
    if (!/^#crh-activate/.test(location.hash || "")) return;
    if (!CRLib.ctxAlive()) return;
    chrome.storage.local.get("lruOrg").then(function (data) {
      var lru = data.lruOrg && /^\d+$/.test(String(data.lruOrg.id || "")) ? String(data.lruOrg.id) : "";
      var cur = orgIdFromLocation();
      if (lru && cur && lru !== cur) {
        location.replace(
          "https://app.courtreserve.com/Online/Calendar/Events/" + lru + "/Month" + location.hash
        );
      }
    });
  }

  // --- Premium activation card ------------------------------------------------
  // The post-purchase success page (dkitzmiller.github.io/success.html) links
  // here as .../Month#crh-activate=<license_key>. Chrome forbids web pages
  // from opening the extension popup, so instead a card appears right on the
  // calendar — key pre-filled, one click to activate. The hash never reaches
  // any server, and is stripped from the URL after a successful activation.
  function maybeActivationCard() {
    // CourtReserve's SPA strips the URL fragment while the page boots, so by
    // document_idle location.hash is usually empty. The document_start
    // capture script (content-activate-capture.js) parks it in sessionStorage.
    var raw = location.hash || "";
    if (!/^#crh-activate/.test(raw)) {
      try { raw = sessionStorage.getItem("crh-activate-hash") || ""; } catch (e) { raw = ""; }
    }
    var m = /^#crh-activate(?:=(.*))?$/.exec(raw);
    if (!m) return;
    try { sessionStorage.removeItem("crh-activate-hash"); } catch (e) {}
    var keyFromHash = m[1] ? decodeURIComponent(m[1]) : "";
    CRLib.license.get().then(function (lic) {
      if (CRLib.license.isPremium(lic)) return; // already active — nothing to do
      if (document.getElementById("crx-activate-card")) return;
      var card = document.createElement("div");
      card.id = "crx-activate-card";
      card.style.cssText =
        "position:fixed;top:14px;right:14px;z-index:99999;width:300px;" +
        "background:#fff;border:1px solid #e7e5e4;border-radius:12px;padding:16px;" +
        "box-shadow:0 12px 32px rgba(0,0,0,.18);" +
        "font:13px/1.5 -apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;color:#1c1917;";
      card.innerHTML =
        '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px;">' +
        '<b style="font-size:14px;">🎉 Activate Premium</b>' +
        '<button type="button" data-x style="border:none;background:none;font-size:17px;cursor:pointer;color:#78716c;line-height:1;">×</button></div>' +
        '<div style="color:#57534e;font-size:12px;margin-bottom:8px;">Unlock ⏰ Auto-Register with your license key.</div>' +
        '<input type="text" placeholder="XXXX-XXXX-XXXX-XXXX" style="width:100%;box-sizing:border-box;padding:6px 9px;font-size:13px;border:1px solid #e7e5e4;border-radius:7px;margin-bottom:8px;">' +
        '<button type="button" data-go style="width:100%;padding:6px 0;font-size:12.5px;font-weight:700;border:none;border-radius:8px;background:#0d9488;color:#fff;cursor:pointer;">Activate license</button>' +
        '<div data-msg style="font-size:11.5px;margin-top:6px;color:#78716c;"></div>';
      (document.body || document.documentElement).appendChild(card);
      var input = card.querySelector("input");
      var msg = card.querySelector("[data-msg]");
      if (keyFromHash) {
        input.value = keyFromHash;
        msg.textContent = "Key pre-filled from your purchase — just click Activate.";
      }
      card.querySelector("[data-x]").addEventListener("click", function () { card.remove(); });
      card.querySelector("[data-go]").addEventListener("click", function () {
        if (!CRLib.ctxAlive()) { staleNotice(); return; }
        msg.style.color = "#78716c";
        msg.textContent = "Activating…";
        try {
          chrome.runtime.sendMessage(
            { type: "licenseActivate", key: input.value.trim(), deviceName: "Calendar card" },
            function (r) {
              if (chrome.runtime.lastError) {
                msg.style.color = "#b91c1c";
                msg.textContent = "⚠ " + chrome.runtime.lastError.message;
                return;
              }
              if (r && r.ok) {
                card.innerHTML =
                  '<div style="color:#15803d;font-weight:700;">✅ Premium active — ⏰ Auto-Register unlocked.</div>';
                // Drop the hash so a refresh doesn't re-show the card.
                history.replaceState(null, "", location.pathname + location.search);
                setTimeout(function () { card.remove(); }, 6000);
              } else {
                msg.style.color = "#b91c1c";
                msg.textContent = "⚠ " + ((r && r.message) || "Activation failed.");
              }
            }
          );
        } catch (e) { staleNotice(); }
      });
    });
  }

  function start() {
    maybeActivationRedirect(); // may bounce this page to the LRU org's calendar
    scan();
    maybeAutofill();
    maybeRunTaskCalendar();
    maybeActivationCard();
    reportOrgVisit();
    // The account menu renders asynchronously — try now and again shortly.
    learnOrgsFromPage();
    setTimeout(learnOrgsFromPage, 3000);
    observer.observe(document.body, { childList: true, subtree: true });
    chrome.storage.onChanged.addListener(function (changes, area) {
      if (area === "local" && (changes.entries || changes.settings || changes.license)) {
        // Entries/settings/license changed — drop injected buttons and
        // indicators so labels flip (Auto-Register ↔ Remove ↔ locked Premium)
        // and the bold date markers toggle on the re-scan.
        var old = document.querySelectorAll("." + BTN_CLASS);
        for (var i = 0; i < old.length; i++) old[i].remove();
        var oldCells = document.querySelectorAll(".k-event");
        for (var oc = 0; oc < oldCells.length; oc++) clearOpenHover(oldCells[oc]);
        var marked = document.querySelectorAll("." + DAY_CLASS + ", ." + IND_CLASS);
        for (var j = 0; j < marked.length; j++) {
          marked[j].classList.remove(DAY_CLASS);
          marked[j].classList.remove(IND_CLASS);
          marked[j].removeAttribute("title");
        }
        scan();
      }
    });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", start);
  } else {
    start();
  }
})();
