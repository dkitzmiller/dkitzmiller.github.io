/* Court Helper for CourtReserve — registration editor (SignUpToEvent) handler.
   Clicking "Register" on a details page NAVIGATES here; the editor with the
   "Finalize Registration" button lives on THIS page. This script completes
   the flow started by content-details.js. Success is then reported by
   content-details.js when CourtReserve returns to the details page (which
   shows EDIT REGISTRATION), with the background watchdog as the backstop. */

(() => {
  // v1.7.33: re-injection guard — see content-details.js / Oct 22-23 stalls.
  // v1.7.41: version-stamped marker — see content-calendar.js.
  const CRX_VER = chrome.runtime.getManifest().version;
  if (window.__crxSignupLoaded === CRX_VER) return;
  window.__crxSignupLoaded = CRX_VER;
  const MAX_TASK_AGE = 5 * 60 * 1000;
  const RATING_RE = /not (allowed|eligible)[\s\S]{0,80}?rating|rating[\s\S]{0,40}(requirement|restricted|not met)|do(es)? not meet[\s\S]{0,40}(rating|eligibility)/i;
  const ratingBlocked = (body) => RATING_RE.test(body);

  async function pollFor(fn, timeout) {
    try { return await CRLib.waitFor(fn, timeout, 700); } catch { return null; }
  }

  // v1.7.57: Required Disclosure(s) — clubs can gate Finalize Registration
  // behind agreement toggles (PZB: "24 Hour Cancellation — Required",
  // "Check to agree to above disclosure"; Finalize stays disabled with
  // "Agree to the disclosure to continue"). Clicking Finalize without
  // agreeing does NOTHING and the run died on the watchdog (Oct 27).
  // Agree to every required disclosure before finalizing. Each agreement is
  // logged — an automated legal acknowledgment must never be invisible.
  function findDisclosureControls() {
    const controls = [];
    const seen = new Set();
    document.querySelectorAll('label, span, div, p').forEach((el) => {
      const t = (el.textContent || '').replace(/\s+/g, ' ').trim();
      if (t.length > 60 || !/check to agree|agree to (the )?(above )?disclosure/i.test(t)) return;
      // Smallest ancestor holding both the text and a switch/checkbox.
      let scope = el;
      for (let up = 0; up < 4 && scope; up++) {
        const ctl = scope.querySelector('[role="switch"], [role="checkbox"], input[type="checkbox"], button[aria-checked]');
        if (ctl) { if (!seen.has(ctl)) { seen.add(ctl); controls.push(ctl); } return; }
        scope = scope.parentElement;
      }
      // No control nearby — the text element itself may be the label/toggle.
      if (!seen.has(el)) { seen.add(el); controls.push(el); }
    });
    return controls;
  }
  async function agreeToDisclosures() {
    let agreed = 0;
    for (const ctl of findDisclosureControls()) {
      const on = ctl.getAttribute && ctl.getAttribute('aria-checked') === 'true' || ctl.checked === true;
      if (on) continue;
      ctl.click();
      agreed++;
      await CRLib.sleep(300);
    }
    return agreed;
  }

  async function run(task) {
    const report = (ok, state, message) =>
      chrome.runtime.sendMessage({ type: 'taskResult', entryId: task.entryId, ok, state, message });

    // Heartbeat + marker helper: persist progress so the watchdog knows this
    // run is alive, and (before a confirm click) mark that WE submitted — so
    // the details page landing after navigation can word its report as the
    // confirmation of our own click, not a mysterious "already registered".
    const beat = async (extra) => {
      task.progressAt = Date.now();
      if (extra) Object.assign(task, extra);
      try { await chrome.storage.local.set({ pendingTask: task }); } catch { /* best-effort */ }
    };
    await beat();

    await CRLib.sleep(1000);
    await pollFor(() => (document.body && document.body.innerText.length > 150) ? true : null, 15000);

    const body = CRLib.bodyText();

    if (ratingBlocked(body)) {
      return report(false, 'ineligible', 'Not eligible by rating — CourtReserve blocked the registration.');
    }

    // Already registered (e.g. a retry landing here after success)?
    if (/edit registration|already registered|you are registered/i.test(body)) {
      return report(true, 'registered', 'Registered ✓');
    }

    // The editor: finalize the pending reservation.
    const fin = await pollFor(() =>
      CRLib.findButton([/finalize registration/i, /complete registration/i, /confirm registration/i, /^save$/i, /^submit$/i]), 10000);
    if (fin) {
      // Required disclosures gate Finalize — agree first (v1.7.57).
      const agreed = await agreeToDisclosures();
      if (agreed) {
        CRLib.log('info', 'Auto-Register',
          `Agreed to ${agreed} required disclosure(s) on the registration editor (e.g. cancellation policy) — required before Finalize Registration works.`,
          'Disclosure');
        await CRLib.sleep(400);
      }
      await beat({ confirmClicked: true }); // mark BEFORE clicking
      fin.el.click();
      await CRLib.sleep(800);
      // Optional confirmation dialog.
      const c = await pollFor(() =>
        CRLib.findButton([/^confirm$/i, /^ok$/i, /^yes$/i, /^submit$/i]), 3000);
      if (c) { c.el.click(); await CRLib.sleep(600); }
      // The disclosure toggle may not have taken on the first pass (a switch
      // that needs its own hit area) — if the page still says so, agree again
      // and re-click Finalize once.
      if (/agree to (the )?(above )?disclosure/i.test(CRLib.bodyText())) {
        const again = await agreeToDisclosures();
        if (again) {
          CRLib.log('info', 'Auto-Register',
            'Finalize Registration was still disclosure-gated — agreed to the disclosure and retrying Finalize.',
            'Disclosure retry');
          await CRLib.sleep(400);
          const fin2 = CRLib.findButton([/finalize registration/i, /complete registration/i, /confirm registration/i]);
          if (fin2) { fin2.el.click(); await CRLib.sleep(800); }
        }
      }
      // CourtReserve typically returns to the details page, where
      // content-details.js sees EDIT REGISTRATION and reports success.
      // If we stay here and the page itself confirms, report directly.
      await CRLib.sleep(2500);
      const after = CRLib.bodyText();
      if (/edit registration|you are registered|registration (confirmed|complete)/i.test(after)) {
        return report(true, 'registered', 'Registered ✓');
      }
      // Slow server at the opening minute: keep watching a little longer for
      // an on-page confirmation (success only — the watchdog owns failure).
      // If the page navigates back to the details page meanwhile, this
      // context dies and content-details.js reports there instead.
      const late = await pollFor(() =>
        /edit registration|you are registered|registration (confirmed|complete)/i.test(CRLib.bodyText()) ? true : null,
        10000);
      if (late) return report(true, 'registered', 'Registered ✓');
      return; // details page or the watchdog will settle the outcome
    }

    // No finalize control — is this a waitlist-style editor instead?
    const save = CRLib.findButton([/join( the)? waitlist/i, /^save$/i]);
    if (save) {
      const agreedW = await agreeToDisclosures(); // disclosures can gate waitlist joins too
      if (agreedW) await CRLib.sleep(400);
      await beat({ confirmClicked: true }); // mark BEFORE clicking
      save.el.click();
      await CRLib.sleep(1500);
      const after = CRLib.bodyText();
      if (/unsubscribe from waitlist|#\d+\s*on waitlist|waitlisted on:/i.test(after)) {
        const m = after.match(/#(\d+)\s*on waitlist/i);
        return report(true, 'waitlisted', `Waitlisted${m ? ' #' + m[1] : ''}`);
      }
    }

    return report(false, 'failed', 'Registration editor showed no Finalize Registration button.');
  }

  (async () => {
    // Orphaned by an extension reload — stay silent until the page reloads.
    if (!CRLib.ctxAlive()) return;
    try {
      const data = await chrome.storage.local.get('pendingTask');
      const task = data.pendingTask;
      if (!task) return; // user browsing an editor manually — stay out of the way
      if (Date.now() - task.startedAt > MAX_TASK_AGE) {
        await chrome.storage.local.remove('pendingTask');
        return;
      }
      await run(task);
    } catch (err) {
      try {
        const data = await chrome.storage.local.get('pendingTask');
        if (data.pendingTask) {
          chrome.runtime.sendMessage({
            type: 'taskResult', entryId: data.pendingTask.entryId,
            ok: false, state: 'failed', message: 'Editor error: ' + err.message,
          });
        }
      } catch { /* nothing more we can do */ }
    }
  })();
})();
