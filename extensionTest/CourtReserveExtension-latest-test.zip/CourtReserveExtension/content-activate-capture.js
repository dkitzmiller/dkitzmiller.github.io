/**
 * Capture script: runs at document_start on CourtReserve calendar pages.
 *
 * The post-purchase hand-off delivers the license key as a URL fragment
 * (.../Month#crh-activate=<key>) so it never reaches a server. But
 * CourtReserve's SPA strips the fragment while the page boots — by
 * document_idle (when the main content script runs) location.hash is empty.
 * This script runs BEFORE any page script and parks the fragment in
 * sessionStorage; content-calendar.js picks it up from there.
 */
(function () {
  "use strict";
  if (/^#crh-activate/.test(location.hash || "")) {
    try { sessionStorage.setItem("crh-activate-hash", location.hash); } catch (e) {}
  }
})();
