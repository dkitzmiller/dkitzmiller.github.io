/**
 * Content script: CourtReserve "My Profile" pages.
 *
 * Learns the user's Gender and rating(s) for THIS organization (ratings are
 * per-club) and stores them under the `profiles` storage key. Event details
 * pages carry "Rating Restriction" / "Gender Restriction" blocks; the saved
 * profile is what those restrictions are compared against — the extension
 * then hides categories the user can't play and pre-checks eligibility at
 * fire time.
 *
 * The profile form is Ant Design: Gender and the rating pickers are
 * `.ant-select` widgets (selected value rendered in
 * `.ant-select-selection-item`), while custom fields like "Player Rating"
 * are plain text inputs. Labels carry `for` attributes pointing at the
 * inputs, so we resolve every rating-ish label generically.
 */
(function () {
  "use strict";

  function orgIdFromLocation() {
    var m = /\/Online\/MyProfile\/MyProfile\/(\d+)/.exec(location.pathname);
    return m ? m[1] : "";
  }

  /** Selected value of the .ant-select widget wrapping an input id. */
  function antSelectValue(inputId) {
    var inp = document.getElementById(inputId);
    if (!inp) return "";
    var wrap = inp.closest(".ant-select");
    if (!wrap) return inp.value || "";
    var item = wrap.querySelector(".ant-select-selection-item");
    return item ? (item.getAttribute("title") || item.textContent || "").trim() : "";
  }

  function readProfile() {
    var gender = antSelectValue("Gender");
    // Three rating fields exist on My Profile: "Rating" (club-given — the
    // restriction yardstick), "CORE Rating System" (tested/external), and
    // "Player Rating" (self-declared custom field, any value). Use the
    // club's "Rating"; fall back to CORE, then to the self-declared value
    // only when neither of the other two is set.
    var byLabel = {};
    var labels = document.querySelectorAll("label.form-label[for]");
    for (var i = 0; i < labels.length; i++) {
      var text = (labels[i].textContent || "").trim();
      if (!/rating/i.test(text)) continue;
      var forId = labels[i].getAttribute("for");
      var target = forId && document.getElementById(forId);
      if (!target) continue;
      var val = target.closest(".ant-select")
        ? antSelectValue(forId)
        : String(target.value || "").trim();
      if (val) byLabel[text.toLowerCase()] = val;
    }
    var ratings = [];
    var core = "";
    Object.keys(byLabel).forEach(function (k) { if (/core/.test(k) && !core) core = byLabel[k]; });
    if (byLabel["rating"]) ratings.push(byLabel["rating"]);
    else if (core) ratings.push(core);
    else if (byLabel["player rating"]) ratings.push(byLabel["player rating"]);
    return { gender: gender, ratings: ratings };
  }

  function save() {
    if (!CRLib.ctxAlive()) return;
    var orgId = orgIdFromLocation();
    if (!orgId) return;
    var profile = readProfile();
    if (!profile.gender && !profile.ratings.length) return; // form not rendered yet
    CRLib.profiles.put(orgId, {
      gender: profile.gender,
      ratings: profile.ratings,
      at: Date.now(),
    });
  }

  // The form renders asynchronously, and the rating selects populate via a
  // separate async call AFTER the base form — read several times over the
  // first seconds. profilePut merges partial reads, never clobbers.
  function scheduleSaves() {
    [1000, 2500, 4500, 7000].forEach(function (ms) { setTimeout(save, ms); });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", scheduleSaves);
  } else {
    scheduleSaves();
  }
})();
